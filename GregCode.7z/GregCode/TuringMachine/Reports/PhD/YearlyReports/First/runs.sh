latex firstYearReport.tex
bibtex firstYearReport.aux
latex firstYearReport.tex
latex firstYearReport.tex

dvipdf firstYearReport.dvi

