#include <stdio.h>

#define VERSION "0.0"

struct node {  short token; char *pname; struct node *left,*right;  };

struct cell { struct cell * left, * right;
              char symbol; };

typedef struct cell * CELL;

struct tuple {int state;
              char oldsymb,newsymb,dir;
              int newstate;
              struct tuple * next; };

typedef struct tuple * TUPLE;

#define TAPE 0x01
#define TUPLES 0x02
#define PTAPE 0x03
#define PTUPLES 0x04
#define RUN 0x05
#define STEP 0x06
#define LOAD 0x07
#define SAVE 0x08
#define NUMB 0x09
#define EDIT 0x0a
#define END 0x00b
#define RESET 0x0c

#define MAXSTATES 20

#define NAMESIZE 20
#define FNLENGTH 80
#define CLENGTH 80
