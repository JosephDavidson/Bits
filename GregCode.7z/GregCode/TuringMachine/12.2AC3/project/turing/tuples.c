#include <stdio.h>
#include "defs.h"

extern int ch;

TUPLE tuples[MAXSTATES];

inittuples()
{  int i;
   for(i=0;i<MAXSTATES;i++)
    tuples[i]=NULL;
}

TUPLE newtuple(state,oldsymb,newsymb,dir,newstate)
int state,newstate;
char oldsymb,newsymb,dir;
{  TUPLE t;
   t=(TUPLE)malloc(sizeof(struct tuple));
   t->state=state;
   t->oldsymb=oldsymb;
   t->newsymb=newsymb;
   t->dir=dir;
   t->newstate=newstate;
   t->next=NULL;
   return t;
}

printtuple(t)
TUPLE t;
{  fprint("%d,%c,%d,%c,%c",
          t->state,t->oldsymb, t->newstate, t->newsymb,t->dir);  }

printtuples()
{  int i;
   TUPLE t;
   for(i=0;i<MAXSTATES;i++)
    if(tuples[i]!=NULL)
    {  t=tuples[i];
       while(t!=NULL)
       {  printtuple(t);
          putch('\n');
          t=t->next;
       }
    }
}

skipspace()
{  while(ch==' ' || ch=='\n')
    ch=getch();
}

getint()
{  int i;
   if(ch<'0' || ch>'9')
    return -1;
   i=0;
   while(ch>='0' && ch<='9')
   {  i=10*i+ch-'0';
      ch=getch();
   }
   return i;
}

gettuple()
{  int state,newstate;
   char oldsymb,newsymb,dir;
   skipspace();
   state=getint();
   if(state==-1)
   {  fprint("STATE EXPECTED\n");
      return 0;
   }
   if(state>=MAXSTATES)
   {  fprint("STATE %d TOO BIG\n",state);
      return 0;
   }
   if(ch!=',')
   {  printf("comma expected\n"); return 0;  }
   else
    oldsymb=getch();
   ch=getch();
   if(ch!=',')
   {  printf("comma expected\n"); return 0;  }
   else
    ch=getch();
   newstate=getint();
   if(newstate==-1)
   {  fprint("NEW STATE EXPECTED\n");
      return 0;
   }
   if(newstate>=MAXSTATES)
   {  fprint("NEW STATE %d TOO BIG\n",newstate);
      return 0;
   }
   if(ch!=',')
   {  printf("comma expected\n"); return 0;  }
   else
    newsymb=getch();
   ch=getch();
   if(ch!=',')
   {  printf("comma expected\n"); return 0;  }
   else
    dir=getch();
   if(dir!='L' && dir!='R' && dir!='S')
   {  fprint("DIRECTION EXPECTED\n");
      return 0;
   }
   ch=getch();
   placetuple(state,oldsymb,newsymb,dir,newstate);
   return 1;
}

placetuple(state,oldsymb,newsymb,dir,newstate)
int state,newstate;
char oldsymb,newsymb,dir;
{  TUPLE t;
   if(tuples[state]==NULL)
   {  tuples[state]=newtuple(state,oldsymb,newsymb,dir,newstate);
      return;
   }
   t=tuples[state];
   while(1)
   {  if(t->oldsymb==oldsymb)
      {  t->newsymb=newsymb;
         t->dir=dir;
         t->newstate=newstate;
         return;
      }
      if(t->next==NULL)
      {  t->next=newtuple(state,oldsymb,newsymb,dir,newstate);
         return;
      }
      t=t->next;
   }
}

gettuples()
{  while(ch!=';')
   {  if(!gettuple())
      {  while(ch!=';')
          ch=getch();
         break;
      }
      skipspace();
   }
   ch=getch();
}

freetuples()
{  TUPLE t,tt;
   int i;
   for(i=0;i<MAXSTATES;i++)
    if(tuples[i]!=NULL)
    {  t=tuples[i];
       tuples[i]=NULL;
       while(t!=NULL)
       {  tt=t->next;
          free(t);
          t=tt;
       }
    }
}
