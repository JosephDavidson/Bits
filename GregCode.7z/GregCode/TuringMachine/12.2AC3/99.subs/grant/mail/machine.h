// machine.h

#ifndef __MACHINE_H__
#define __MACHINE_H__

#include <fstream.h>
#include "tape.h"
#include "rule.h"

class machine {
  public:
    machine();
    ~machine();

    int load(char* filename);
    int run(ostream& out);

    int state;

		void rule_add(rule new_rule);
		int rule_find(int state, char symbol);
		void tape_display(ostream& out);
  private:
    tape* tape_data;
		rule rule_data[100];
		int rule_count;
  };

#endif // __MACHINE_H__
