// tape.cpp

#include <stddef.h>
#include "tape.h"
#include "node.h"

tape::tape()
{
  Current = new node();
	Stored = Current;
}

tape::~tape()
{
  // delete current node... others should cascade from destructor
  delete Current;
}

void tape::AccessNext()
{
	if (AtNode()) {
		if (Current->Next != NULL) {
			// just move to next node
			Current = Current->Next;
		} else {
			// no next node... allocate one...
			Current->Next = new node();
			Current->Next->Prev = Current;
			Current = Current->Next;
		}
  }
}

void tape::AccessPrev()
{
	if (AtNode()) {
		if (Current->Prev != NULL) {
			// just move to prev node
			Current = Current->Prev;
		} else {
			// no prev node... allocate one...
			Current->Prev = new node();
			Current->Prev->Next = Current;
			Current = Current->Prev;
		}
  }
}

char tape::GetValue()
{
  return Current->Value;
}

void tape::SetValue(char Value)
{
  if (AtNode()) Current->Value = Value;
}

void tape::Memorize()
{
	// remember where we are
	Stored = Current;
}

void tape::Remember()
{
	// remember where we were
	Current = Stored;
}

bool tape::AtNode()
{
	// are we at a node? (should always be true)
  return (Current != NULL);
}
