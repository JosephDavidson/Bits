// machine.cpp

#include <stdlib.h>
#include <fstream.h>
#include "machine.h"
#include "rule.h"

machine::machine()
{
	state = 1;
  tape_data = new tape();
	rule_count = 0;
}

machine::~machine()
{
  delete tape_data;
}

int machine::load(char* filename)
{
	int expect = 0;
	bool done = false;
	char input = '\0';
	rule myrule;
	ifstream in(filename, ios::in | ios::nocreate);

	// expect table:
	//   0 = old state
	//   1 = old symbol
	//   2 = new state
	//   3 = new symbol
	//   4 = direction

  myrule.old_state = 0; myrule.new_state = 0; expect = 0;

	// get the transition rules

	while (!in.eof() && !done) {
		in.get(input);

		switch (input) {
			case ',':  // expect the next type
				expect++;
				break;
			case ';':	 // end of transition rules
				done = true;
			case '\n': // end of line
				rule_add(myrule);
				myrule.old_state = 0; myrule.new_state = 0; expect = 0;
				break;
			default:   // must be some data
				switch (expect) {
					case 0:
						myrule.old_state = (myrule.old_state * 10) + input - '0'; // to allow for multiple-digit states
						break;
					case 1:	
						myrule.old_symbol = input; // only accepts one char at this time
						break;
					case 2:	
						myrule.new_state = (myrule.new_state * 10) + input - '0'; // to allow for multiple-digit states
						break;
					case 3:	
						myrule.new_symbol = input; // only accepts one char at this time
						break;
					case 4:
						switch (input) {
							case 'l': case 'L':
								myrule.dir = left;
								break;
							case 'r': case 'R':
								myrule.dir = right;
								break;
							default:
								myrule.dir = stop;
								break;
						}
						break;
				}
		}

	}

	// skip newline

	in.get(input);

	// get the tape

	tape_data->Memorize();

	done = false;
	while (!in.eof() && !done) {
		in.get(input);

		if (input == '^') {
			tape_data->Memorize();
			continue;
		}

		if (input == ';') {
			done = true;
			continue;
		}

		tape_data->SetValue(input);
		tape_data->AccessNext();

	}

	tape_data->Remember();

	in.close();

	return 0;
}

int machine::run(ostream& out)
{
	int the_rule;
	bool stop = false;

	do {

		// display state/tape
		out << state << ": ";
		tape_display(out);

		the_rule = rule_find(state, tape_data->GetValue());
		if (the_rule != -1) {
			// change the state
			state = rule_data[the_rule].new_state;
			// change the symbol, unless we have '-', in which case, leave it
			if (rule_data[the_rule].new_symbol != '-') tape_data->SetValue(rule_data[the_rule].new_symbol);
			// move along the tape or stop
			switch (rule_data[the_rule].dir) {
				case left:  tape_data->AccessPrev(); break; // move left
				case right: tape_data->AccessNext(); break; // move right
				default: stop = true; break;                // finished
			}
		} else {
			// no rule found so show error and stop
			cerr << "No matching rule found for state " << state << " and symbol " << tape_data->GetValue() << ".\n";
			return -1;
		}

	} while (!stop);

	return 0;
}

void machine::tape_display(ostream& out)
{
	int i;

	// store where we are
	tape_data->Memorize();

	// move back 20
	for (i = 0; i < 20; i++) { tape_data->AccessPrev();	}

	// display previous 20
	for (i = 0; i < 20; i++) { out << tape_data->GetValue(); tape_data->AccessNext();	}

	// display current symbol, contained in ()'s
	out << "(" << tape_data->GetValue() << ")";
	tape_data->AccessNext();

	// display next 20
	for (i = 0; i < 20; i++) { out << tape_data->GetValue(); tape_data->AccessNext();	}

	// new line
	out << "\n";

	// move back to where we started
	tape_data->Remember();
}

void machine::rule_add(rule new_rule)
{
	// add the given rule to the rules table
	rule_data[rule_count] = new_rule;
	rule_count++;
}

int machine::rule_find(int state, char symbol)
{
	// find and return the number of matching rule
	for (int i = 0; i < rule_count; i++) {
		if (rule_data[i].old_state == state) {
			if ((rule_data[i].old_symbol == '.') || (rule_data[i].old_symbol == symbol)) {
				return i;
			}
		}
	}

	// ...or -1 if no matches are found
	return -1;
}