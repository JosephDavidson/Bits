// node.cpp

#include "stddef.h"
#include "node.h"

node::node(char Initial)
{
  Value = Initial;
	Next = NULL; Prev = NULL;
}

node::~node()
{
	if (Next != NULL) delete Next;
	if (Prev != NULL) delete Prev;
}