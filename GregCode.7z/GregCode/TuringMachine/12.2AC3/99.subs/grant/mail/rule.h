// rule.h

#ifndef __RULE_H__
#define __RULE_H__

typedef enum _direction { left = -1, stop = 0, right = 1 } direction;

class rule {
	public:
		int old_state, new_state;
		char old_symbol, new_symbol;
		direction dir;
	};

#endif // __RULE_H__