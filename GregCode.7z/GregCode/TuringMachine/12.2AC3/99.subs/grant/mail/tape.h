// tape.h

#ifndef __TAPE_H__
#define __TAPE_H__

#include "node.h"

class tape {
  public:
    tape();
    ~tape();

    void AccessNext();
    void AccessPrev();
    char GetValue();
    void SetValue(char Value);
		void Memorize(); // store current position
		void Remember(); // load previously stored position
    bool AtNode();
  private:
    node *Current, *Stored;
  };

#endif // __TAPE_H__
