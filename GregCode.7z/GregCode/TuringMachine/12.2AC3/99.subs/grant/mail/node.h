// node.h

#ifndef __NODE_H__
#define __NODE_H__

class node {
  public:
    node(char Initial = '_');
		~node();

    char Value;
    node *Next, *Prev;
  };

#endif // __NODE_H__
