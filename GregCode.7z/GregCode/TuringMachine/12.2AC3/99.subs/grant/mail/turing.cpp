#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include "machine.h"

void main(int argc, char *argv[])
{
	char *file_input = "", *file_output = "";
	ofstream output;
	machine* tm = new machine();

	if (argc >= 2) {
		file_input = argv[1];
		if (argc >= 3) {
			file_output = argv[2];
		}
	}	else {
		cout << "Usage: TURING [input file]\n"
			   << "       TURING [input file] [output file]\n"
				 << "\n";

		exit(1);
	}

	cout << "Turing Machine Simulator\n"
		   << "----------------------------------------\n";

	cout << "Loading tape from " << file_input << "...\n";

	// load it
	tm->load(file_input);

	// run the machine
	if (strlen(file_output) != 0) {
		// open output file and run there
		cout << "Sending output to " << file_output << "...\n";

		output.open(file_output);

		tm->run(output);

		output.close();
	} else {
		// run to screen
		cout << "Running machine...\n\n";
		tm->run(cout);
	}

	cout << "\nDone, press a key to exit.\n";
	cin.get();

	delete tm;

	return;
}
 