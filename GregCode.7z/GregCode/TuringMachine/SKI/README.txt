^<(exp)>

{ } == region

START:
find next region
if no region then HALT
remove left most nested brackets in region
find combinator
if no 1st arg then
 goto REMREG
mark 1st arg
if first combinator is I then 
 delete I
 goto CLOSE
if no 2nd arg then
 goto CLOSE
if first combinator is K then
 delete K
 delete 2nd arg
 goto CLOSE
mark 2nd arg
if no 3rd arg then
 unmark 2nd arg
 goto CLOSE
if first combinator is S then
 delete S
 copy 2nd arg to end, deleting
 copy 3rd arg to end
 add ) at end
 copy all after 3rd arg up end
 replace old > with (
 add > at end
unmark 3rd arg
CLOSE:
 unmark 1st arg
 close up
REMREG:
 remove region
 goto START
