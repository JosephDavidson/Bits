#include <stdio.h>
#include <stdlib.h>

#define MAXTAPE 100
char * tape;
long tp,fp,lp,rp;

int length(char * s)
{  int i;
   i = 0;
   while(s[i]!='\0')
    i++;
   return i;
}

initTape()
{  int i;
   tape = (char *)malloc(sizeof(char)*MAXTAPE);
   for(i=0;i<MAXTAPE;i++)
    tape[i] = ' ';
}

setExp(char * e)
{  int i,l;
   l = length(e);
   if(l+2>MAXTAPE)
   {   printf("expression too long\n");
       exit(0);
   }
   tp = MAXTAPE/2-l/2-1;
   tape[tp] = '*';
   lp = tp;
   tp++;
   for(i=0;i<l;i++)
   {  tape[tp] = e[i];
      tp++;
   }
   tape[tp] = '*';
   rp = tp;
}

showTape()
{  int l,r;
   l = 0;
   while(tape[l]==' ' && l<MAXTAPE)
    l++;
   r = MAXTAPE-1;
   while(tape[r]==' ' && r>=0)
    r--;
   while(l<=r)
   {  putchar(tape[l]);
      l++;
   }
   putchar('\n');
}

move()
{  int bc;
   switch(tape[fp])
   {  case '*':
      case 'I':
      case 'K':
      case 'S': tape[tp] = tape[fp];
                tape[fp] = ' ';
                tp++; fp++;
              return;
      case '(': bc =1;
                tape[tp] = tape[fp];
                tape[fp] = ' ';   
                tp++; fp++;
                while(1)
                {  tape[tp] = tape[fp];
                   tape[fp] = ' ';
                   if(tape[tp]=='(')
                    bc++;
                   else
                   if(tape[tp]==')')
                    bc--;
                   tp++; fp++;
                   if(bc==0)
                    return;
                }
   }
}

copy()
{  int bc;
   switch(tape[fp])
   {  case '*':
      case 'I':
      case 'K':
      case 'S': tape[tp] = tape[fp];
                tp++; fp++;
              return;
      case '(': bc =1;
                tape[tp] = tape[fp];
                tp++; fp++;
                while(1)
                {  tape[tp] = tape[fp];
                   if(tape[tp]=='(')
                    bc++;
                   else
                   if(tape[tp]==')')
                    bc--;
                   tp++; fp++;
                   if(bc==0)
                    return;
                }
   }
}

erase()
{  int bc;
   switch(tape[fp])
   {  case 'I':
      case 'K':
      case 'S': tape[fp] = ' ';
                fp++;
                return;
      case '(': bc = 1;
                tape[fp] = ' ';
                fp++;
                while(1)
                {  if(tape[fp]=='(')
                    bc++;
                   else
                   if(tape[fp]==')')
                    bc--;
                   tape[fp] = ' ';
                   fp++;
                   if(bc==0)
                    return;
                }
       
   }
}

skip()
{  int bc;
   switch(tape[fp])
   {  case '*':
      case 'I':
      case 'K':
      case 'S': fp++;
                return;
      case '(': bc =1;
                fp++;
                while(1)
                {  if(tape[fp]=='(')
                    bc++;
                   else
                   if(tape[fp]==')')
                    bc--;
                   fp++;
                   if(bc==0)
                    return;
                }
   }
}

moveAll()
{  while(1)
   {  tape[tp] = tape[fp];
      if(tape[tp]=='*')
       return;
      tp++; fp++;
   }
}

shiftAll()
{  while(1)
   {  tape[tp] = tape[fp];
      if(tape[tp] == '*')
       return;
      tp--; fp--;
   }
}

clearBack()
{  tape[lp] = ' ';
   lp++;
   while(tape[lp]!='*')
   {  tape[lp] = ' ';
      lp++;
   }
}

reduce()
{  int p1,p2;
   switch(tape[tp])
   {  case 'I': fp = tp+1;
                move();
                moveAll();
                return;
      case 'K': fp=tp+1;
                move();
                erase();
                moveAll();
                return;
      case 'S': fp = tp+1;
                skip();
                p1 = fp-1;
                tp = rp+1;
                copy();
                showTape();
                p2 = fp-1;
                copy();
                showTape();
                tape[tp] = ')';
                showTape();
                tp++;
                moveAll();
                showTape();
                tape[rp] = '(';
                showTape();
                rp = tp-1;
                fp = p1;
                tp = p2;
                shiftAll();
                clearBack();
                break;
   }
}

main()
{  initTape();
   setExp("S(SS)(II)(KK)");
   showTape();
   printf("----------\n");
   tp = lp+1;
   reduce();
   tape[lp] = ' ';
   tape[lp+1] = '*';
   lp++;
   showTape();
}
