#include <stdio.h>
#include <stdlib.h>
#include "defs.h"

extern int ch;

extern skipspace();

CELL tape;

inittape()
{  tape=NULL;  }

CELL newcell()
{  CELL c;
   c=(CELL)malloc(sizeof(struct cell));
   c->left=NULL;
   c->right=NULL;
   c->symbol='0';
   return c;
}

gettape()
{  CELL p;
   ch=getch();
   skipspace();
   if(ch==';')
   {  ch=getch();return;  }
   p=newcell();
   if(ch=='^')
   {  tape=p;
      ch=getch();
      skipspace();
      if(ch==';')
      {  ch=getch();return;  }
   }
   p->symbol=ch;
   ch=getch();
   skipspace();
   while(ch!=';')
   {  p->right=newcell();
      p->right->left=p;
      p=p->right;
      if(ch=='^')
      {  tape=p;
         ch=getch();
         skipspace();
         if(ch==';')
          break;
      }
      p->symbol=ch;
      ch=getch();
      skipspace();
   }
   ch=getch();
}

printcell(c)
CELL c;
{  fprint("%lx %lx %c %lx",c,c->left,c->symbol,c->right);  }

printtape(t)
CELL t;
{  CELL tt;
   int i;
   if(t==NULL)
     return;
   tt=t;
   i=0;
   while(t->left!=NULL && i<80000000)
   {  t=t->left;
      i++;
   }
   i=0;
   while(t!=NULL && i<800000000)
   {  if(t==tt)
       putch('{');
      putch(t->symbol);
      if(t==tt)
       putch('}');
      t=t->right;
      i++;
   }
}
