#include<stdlib.h>

#include "defs.h"


struct node *nametree;

int ch;
char symb;

char namebuff[NAMESIZE];

extern int getch();
extern putch(),nl();

extern isfile,endload();
extern short loading;

struct node * objname;

initnames()
{  extern struct node *add();

   nametree=NULL;

   add(LOAD,"load");
   add(SAVE,"save");
   add(END,"end");
   add(RUN,"run");
   add(STEP,"step");
   add(TAPE,"tape");
   add(TUPLES,"tuples");
   add(PTAPE,"ptape");
   add(PTUPLES,"ptuples");
   add(EDIT,"edit");
   add(RESET,"reset");
   add(TOTAPE,"totape");

}

char *addname(n)
char *n;
{  char *nn;
   short i;

   i=0;
   while(n[i++]!='\0')
    ;
   nn=malloc(i);
   if(nn==0)
   {   printf("SYSTEM ERROR - NO MORE NAME SPACE\n");
       exit(0);
   }
   while(--i>=0)
    nn[i]=n[i];
   return nn;
}

struct node *newnode(t,n)
short t;
char *n;
{  struct node *nn;

   nn=(struct node *)malloc(sizeof(struct node));
   if(nn==0)
   {  printf("SYSTEM ERROR - NO MORE NODE SPACE\n");
      exit(0);
   }
   nn->token=t;
   nn->pname=addname(n);
   nn->left=NULL;
   nn->right=NULL;
   return nn;
}

short comp(s1,s2)
char *s1,*s2;
{  while(*s1==*s2)
    if(*s1=='\0')
     return 0;
    else
    { ++s1;++s2;  }
   return *s1-*s2;
}

struct node *add(t,n)
short t;
char *n;
{  struct node *nn;
   short c;

   if(nametree==NULL)
    return nametree=newnode(t,n);
   nn=nametree;
   while(1)
    if((c=comp(n,nn->pname))==0)
     return nn;
    else
    if(c<0)
     if(nn->left==NULL)
      return nn->left=newnode(t,n);
     else
      nn=nn->left;
    else
    if(nn->right==NULL)
     return nn->right=newnode(t,n);
    else
     nn=nn->right;
}

readname()
{  short bp;

   bp=0;
   while(((ch>='a' && ch<='z') ||
          (ch>='A' && ch<='Z') ||
          (ch>='0' && ch<='9') || ch=='_') && bp<NAMESIZE-1)
   {  namebuff[bp++]=ch;
      ch=getch();
   }
   namebuff[bp]='\0';
   while((ch>='a' && ch<='z') ||
         (ch>='A' && ch<='Z') ||
         (ch>='0' && ch<='9') || ch=='_')
    ch=getch();
}

lex()
{  while(1)
    switch(ch)
    { case ' ':
      case '	':
      case '\n':ch=getch();
                break;
      case '!':symb='!';
               ch=getch();
               return;
      case EOF:return;
      default:if((ch>='a' && ch<='z') ||
                 (ch>='A' && ch<='Z'))
              {  readname();
                 objname=add(0,namebuff);
                 symb=objname->token;
                 return;
              }
              printf("UNKNOWN CHARACTER %x %c\n",ch,ch);
              ch=getch();
    }
}
