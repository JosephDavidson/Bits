#include "defs.h"
#include <stdlib.h>
#include <signal.h>
#include <setjmp.h>
#include <sys/types.h>

jmp_buf env;

extern int ch;
extern char symb;
extern struct node *objname;

extern initnames();

extern ptree();
extern struct node nametree;

FILE *cinput,*coutput;
short isfile;
char filename[FNLENGTH];

char command[CLENGTH];
short iscomm;

short step;
short print;

extern CELL tape;
extern inittape();
extern freetuples(),inittuples();
extern char* convertToTape();

int parseArgs(int argc, char **argv);

int(*charin)();

void reset(){}
/* {  longjmp(env);  } */


int getch()
{  return (*charin)();  }

int termcharin()
{  return getc(cinput);  }

int filecharin()
{  extern int putch();
   int c;
   c=getc(cinput);
   if(c!=EOF)
    putch(c);
   return c;
}

int putch(c)
int c;
{  return putc(c,coutput);  }

nl()
{  putch('\n');  }

fprint(f,a,b,c,d,e)
char *f;
long a,b,c,d,e;
{ fprintf(coutput,f,a,b,c,d,e);  }

initio()
{  cinput=stdin;
   coutput=stdout;
   charin=termcharin;
}

initstep()
{  step=0;
}

main(argc,argv)
int argc;
char * argv[];
{ 
   int menuFlag = 0;
 
   extern sysinterpreter();

   initnames();
   initfile();
   initnsyscall();
   inittuples();
   inittape();

   printf("\nTURING MACHINE SIMULATOR %s\n\n",VERSION);

/* RETURN HERE AFTER SYSTEM ERROR OR ^C */

   initio();
   initstep();
   print = 0;
 //  sload(&argc,argv);

   //printf("ok\n");

   if(argc > 1){   
     menuFlag = parseArgs(argc, argv);
   }else{
     printf("Usage %s [-m] [-f <file>] [-p]\n", argc[0]);
     exit(EXIT_SUCCESS);
   }

   ch=getch();
   while(!menuFlag){
     sysinterpreter();
     printf("ok\n");
   }
   exit(0);
}


sysinterpreter(){
  lex();
  if(ch==EOF)
    return;
  switch(symb){
    case TAPE:gettape();return;
    case TUPLES: gettuples();return;
    case RESET: freetuples();return;
    case PTAPE:
      if(tape!=NULL){
        printtape(tape);
        putch('\n');
      }
      return;
    case PTUPLES:printtuples();return;
    case RUN:machine();return;
    case STEP:flip(&step,"step");return;
    case END:unlink("editfile");
               printf("\ncheerio\n\n");
               exit(0);
    case EDIT:edit();return;
    case LOAD:fload();return;
    case SAVE:save();return;
    case TOTAPE:printf("%s\n", convertToTape()); return;
    case '!':nsyscall();return;
    default:
      printf("COMMAND EXPECTED\n");
      while(ch!='\n')
        ch=getchar();
  }
}

initfile()
{  isfile=0;
}

fload()
{  if(!getfilename())
    return;
   load(filename);
}

load(filename)
char * filename;
{  FILE *f,*oldcinput;
   int (*oldcharin)();
   extern sysinterpreter();
   f=fopen(filename,"r");
   if(!f)
   {  printf("CAN'T OPEN %s\n",filename);
      return;
   }
   oldcinput=cinput;
   cinput=f;
   oldcharin=charin;
   charin=filecharin;
   ch=' ';
   while(ch!=EOF)
    sysinterpreter();
   fclose(f);
   cinput=oldcinput;
   charin=oldcharin;
   ch=' ';
}

save()
{  FILE *f;
   if(!getfilename())
    return;
   f=fopen(filename,"w");
   if(!f)
   {  printf("CAN'T OPEN %s\n",filename);
      return;
   }
   coutput=f;
   fprint("tuples\n");
   printtuples();
   fprint(";\n");
   fclose(f);
   coutput=stdout;
}

edit()
{  FILE *f;

   f=fopen("editfile","w");
   if(!f)
   {  printf("CAN'T OPEN EDIT FILE\n");
      return;
   }
   coutput=f;
   fprint("tuples\n");
   printtuples();
   fprint(";\n");
   fclose(f);
   coutput=stdout;
   system("vi editfile");
   freetuples();
   load("editfile");
}

getfilename()
{  short i;
   while(ch==' ')
    ch=getch();
   i=0;
   while(i<FNLENGTH-1 && ch!='\n')
   {  filename[i++]=ch;
      ch=getch();
   }
   if(i==0 && !isfile)
   {  printf("NO FILE NAME\n");
      return 0;
   }
   if(i>0)
   { filename[i]='\0';
     isfile=1;
   }
   if(i==0)
    printf("using %s\n",filename);
   return 1;
}

initnsyscall()
{ iscomm=0; }

nsyscall()
{  short i;

   i=0;
   if(ch=='!' && !iscomm)
   {  printf("NO PREVIOUS COMMAND\n");
      ch=getch();
      return;
   }
   if(ch=='!')
    ch=getch();
   else
   {  while(i<CLENGTH-1 && ch!='\n')
      {  command[i++]=ch;
         ch=getch();
      }
      command[i]='\0';
      while(ch!='\n')
       ch=getch();
      iscomm=1;
   }
   if(i==0)
    printf("%s\n",command);
   system(command);
}

flip(flag,flagname)
short *flag;
char * flagname;
{  (*flag)=(!(*flag));
   pstatus(*flag,flagname);
}

pstatus(flag,flagname)
short flag;
char * flagname;
{  printf("%s %s\n",flagname,flag?"on":"off");  }

sreset()
{  printf("SYSTEM RESET\n");
   reset();
}

sload(argc,argv)
int * argc;
char * argv[];
{  short i;
   if(*argc!=2)
    return;
   *argc=(-2);
   isfile=1;
   i=0;
   while(i<FNLENGTH-1)
    if(argv[1][i]=='\0')
     break;
    else
    {  filename[i]=argv[1][i];
       ++i;
    }
   filename[i]='\0';
   load(filename);
}

int
parseArgs(int argc, char **argv){
  int y,
      x,
      menu;

  menu = 0;
 
  for(y = 1;y < argc;y++){
    if(argv[y][0] == '-'){
      switch(argv[y][1]){
   
        case 'm': 
          menu = 1;
          break;
        case 'f':
          y+= 1;
          load(argv[y]);
          machine();
          break;
        case 'p':
          print = 1;
          break;        
      }
    }
    
  }
  return menu;
}
