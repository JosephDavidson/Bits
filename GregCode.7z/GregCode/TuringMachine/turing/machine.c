#include <stdio.h>
#include "defs.h"

extern CELL tape;

extern CELL newcell();

extern TUPLE tuples[];

extern printtape();

extern printtuple();

extern step;

extern print;

machine(){  
  int state,
      steps;

  TUPLE t;

   if(tape==NULL)
    return;
   state=1;
   steps=0;
   while(1){
     if(print == 1){
       printtape(tape);
       fprint("   ");
     }
     t=tuples[state];
     while(t!=NULL)
       if(t->oldsymb=='?' || t->oldsymb==tape->symbol)
         break;
       else
         t=t->next;
       if(t==NULL){
         fprint("NO TUPLE FOR %c IN STATE %d\n",tape->symbol,state);
         return;
       }
       if(print == 1){
         printtuple(t);
       }
      if(print == 1){ 
        if(step == 1)
          getch();
        else
        putch('\n');
      }
      if(t->newsymb!='!')
       tape->symbol=t->newsymb;

      state=t->newstate;
      steps+= 1;

      if(t->dir=='S')
       break;

      if(t->dir=='L')
      {  if(tape->left==NULL)
         {  tape->left=newcell();
            tape->left->right=tape;
         }
         tape=tape->left;
      }
      else
      {  if(tape->right==NULL)
         {  tape->right=newcell();
            tape->right->left=tape;
         }
         tape=tape->right;
      }
   }
   printf("Steps Taken: %d\n", steps);
   printtape(tape);
   putch('\n');
}
