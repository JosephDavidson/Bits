#include "defs.h"

extern OBJ ilazy(),iexp(),isusp();

extern OBJ newatom(),new();

extern push(),tpush();
extern OBJ pop();

extern OBJ * sb,* sp;

extern entenv(),lenv();

extern pexp(),nl();

/* extern short etrace; */

extern OBJ parse();

extern OBJ gen();

extern OBJ NIL,REMPTY,RNAME,RNUMB,RFAIL,RCHARACTER,RID,RAND;

extern short lazy;

OBJ ilam(l)
OBJ l;
{  extern OBJ freezefvs();

   return new(ILAM,freezefvs(hd(l)),tl(l));
}

OBJ freezefvs(fvs)
register OBJ fvs;
{  register OBJ newfvs;
   if(fvs==NIL)
     return NIL;
/*   petrace(fvs,"before"); */
   push(newfvs=new(LIST,
                   new(LIST,hd(hd(fvs)),*(sb+value(tl(hd(fvs))))),
                   NIL));
   fvs=tl(fvs);
   while(fvs!=NIL)
   {  tl(newfvs)=new(LIST,
                     new(LIST,hd(hd(fvs)),*(sb+value(tl(hd(fvs))))),
                     NIL);
      newfvs=tl(newfvs);
      fvs=tl(fvs);
   }
/*   petrace(fvs=pop(),"after"); */
   return pop();           /* change 'pop()' to 'fvs' for 'etrace' */
}

OBJ nibp(l)
register OBJ l;
{  register OBJ fn,arg;

   push(l);
   if(hd(l)==RAND)
   {  l=gen(tl(l));
      --sp;
      return l;
   }
   push(fn=iexp(hd(l)));
   switch(tag(fn))
   {  case IRULE:
      case OREMPTY:
      case ORNAME:
      case ORNUMB:
      case ORFAIL:
      case ORID:
      case ORCHARACTER:
                  l=parse(pop(),tl(l));
                  --sp;
                  return l;
   }
   if(tag(fn)!=ILAM)
    rerror(1,hd(l),fn,"function");
   push(arg=iexp(tl(l)));         /* ilazy for normal order */
   entenv();
   pushargs(hd(tl(fn)),arg,hd(tl(fn)),arg);
   pushfvs(hd(fn));
   l=ilazy(tl(tl(fn)));
   lenv();
   --sp;
   --sp;
   --sp;
   return isusp(l);
}

pushargs(p,a,oldp,olda)
register OBJ p,a;
OBJ oldp,olda;
{  while(tag(p)==LIST)
   {  if(tag(a)!=ILIST && tag(a)!=STRING)
      {  a=iexp(a);
         if(tag(a)!=ILIST && tag(a)!=STRING)
          rerror(3,oldp,olda);
      }
      pushargs(hd(p),lazy?(hd(a)=isusp(hd(a))):hd(a),oldp,olda);
      p=tl(p);
      a=lazy?(tl(a)=isusp(tl(a))):tl(a);
   }
   if(tag(p)==ONAME)
   {  push(a);
      return;
   }
   if(p==NIL && a==NIL)
    return;
   rerror(3,oldp,olda);
}

pushfvs(fvs)
register OBJ fvs;
{  while(fvs!=NIL)
   {  push(tl(hd(fvs)));
      fvs=tl(fvs);
   }
}

OBJ ilet(l)
OBJ l;
{  extern OBJ freezefvs();
   return new(ILET,freezefvs(hd(l)),tl(l));
}

OBJ evallet(l)
OBJ l;
{  OBJ * vaddr;
   extern OBJ freezefvs();

   push(l);
   entenv();
   clearvars(hd(tl(l)));
   pushfvs(hd(l));
   vaddr=sb-1;
   setvars(hd(tl(l)),&vaddr);
   bindvars(vaddr);
   l=ilazy(tl(tl(l)));
   lenv();
   --sp;
   return isusp(l);
}
   
clearvars(vv)
OBJ vv;
{  OBJ v;
   v=vv;
   while(v!=NIL)
   {  clearvar(hd(hd(v)));
      v=tl(v);
   }
}

clearvar(v)
OBJ v;
{  while(tag(v)==LIST)
   {  clearvar(hd(v));
      v=tl(v);
   }
   if(v==NIL)
    return;
   push(NIL);
}

setvars(vv,vaddr)
OBJ vv;
OBJ ** vaddr;
{  OBJ v;
   v=vv;
   while(v!=NIL)
   {  setvar(hd(v),vaddr);
      v=tl(v);
   }
}

setvar(v,vaddr)
OBJ v;
OBJ ** vaddr;
{  OBJ n,e;
   n=hd(v);
   e=tl(v);
   if(tag(n)==ONAME)
   {  ++(*vaddr);
      if(tag(e)==LAM || tag(e)==RULE) /* add LET & BP for normal order */
       **vaddr=new(tag(e),hd(e),tl(e));
      else
       **vaddr=iexp(e);
      return;
   }
   e=iexp(e);
   evalvar(n,e,n,e,vaddr);
}

evalvar(n,e,oldn,olde,vaddr)
OBJ n,e,oldn,olde;
OBJ ** vaddr;
{  while(tag(n)==LIST)
   {  if(tag(e)!=ILIST && tag(e)!=STRING)
       rerror(3,oldn,olde);
      push(e);
      evalvar(hd(n),lazy?(hd(e)=isusp(hd(e))):hd(e),oldn,olde,vaddr);
      n=tl(n);
      e=lazy?(tl(e)=isusp(tl(e))):tl(e);
      --sp;
   }
   if(n==NIL && e==NIL)
    return;
   if(tag(n)==ONAME)
   {  ++(*vaddr);
      **vaddr=e;
      return;
   }
   rerror(3,oldn,olde);
}

bindvars(vaddr)
OBJ * vaddr;
{  OBJ * i;
   i=sb-1;
   while(i<vaddr)
   {  ++i;
      switch(tag((*i)))
      {  case LAM:
                  tag((*i))=ILAM;
                  hd((*i))=freezefvs(hd((*i)));
                  break;
         case RULE:
                   tag((*i))=IRULE;
                   hd((*i))=freezefvs(hd((*i)));
                   break; 
                 /* add LET & BP for normal order */
      }
   }
}

/* petrace(e,m) */
/* OBJ e; */
/* char *m; */
/* {  if(!etrace) */
/*     return; */
/*     printf("%s\n",m); */
/*     pexp(e); */
/*     nl(); */
/*     nl(); */
/* } */
