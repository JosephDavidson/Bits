#include "defs.h"

extern OBJ new(),newatom();
extern tpush(),push();
extern OBJ tpop(),pop();
extern OBJ * sp;

extern entenv(),lenv();
extern pushfvs();

extern OBJ iexp();

extern rerror();


extern OBJ NIL;
extern OBJ RNAME,RNUMB,REMPTY,RFAIL,RSTOP,RCHARACTER,RID;

extern short trace,tracedepth;
extern tracein();

extern OBJ iifread();

extern eq();

#define stl(s) (tag(tl(s))==IFREAD?(tl(s)=iifread(tl(s))):tl(s))

OBJ parse(rule,s)
OBJ rule,s;
{  OBJ string,ts;
   extern OBJ apply(),matchchar(),matchword(),matchnumb(),matchid();
   push(rule);
   string=iexp(s);
   if(tag(string)!=STRING)
    rerror(1,s,string,"string");
   --sp;
   push(string);
   switch(tag(rule))
   {  case ORFAIL:
      case ORSTOP:
      case OREMPTY:return new(ILIST,NIL,string);
      case ORNAME:ts=matchword(string);
                  break;
      case ORNUMB:ts=matchnumb(string);
                  break;
      case ORID:ts=matchid(string);
                break;
      case ORCHARACTER:ts=matchchar(string);
                       break;
      default:ts=apply(rule,string);
   }
   --sp;
   return ts==NIL || ts==RSTOP || ts==RFAIL ?new(ILIST,NIL,string):ts;
}

OBJ apply(rule,string)
OBJ rule,string;
{  OBJ ts,fvs;
   extern OBJ applyopt();
   push(rule);
   if((fvs=hd(rule))!=NIL)
   {  entenv();
      pushfvs(fvs);
   }
   rule=tl(rule);
   while(rule!=NIL)
   {  ts=applyopt(hd(rule),string);
      if(ts!=NIL)
       break;
      rule=tl(rule);
   }
   if(ts==RFAIL)
    ts=NIL;
   if(fvs!=NIL)
    lenv();
   --sp;
   return ts;
}

OBJ applyopt(rule,string)
OBJ rule,string;
{  OBJ tree,rt,s;
   OBJ * oldsp;
   extern OBJ applyterm();
   while(1)
   {  rt=applyterm(hd(rule),string);
      if(rt==NIL || rt==RSTOP || rt==RFAIL)
       return rt;
      if(hd(rt)!=NIL)
       break;
      rule=tl(rule);
      if(rule==NIL)
       return new(ILIST,NIL,string);
   }
   oldsp=sp;
   push(hd(rt));
   s=tl(rt);
   rule=tl(rule);
   while(rule!=NIL)
   {  rt=applyterm(hd(rule),s);
      if(rt==NIL || rt==RSTOP || rt==RFAIL)
      {  sp=oldsp;
         return rt;
      }
      if(hd(rt)!=NIL)
       push(hd(rt));
      s=tl(rt);
      rule=tl(rule);
   }
   rt=pop();
   while(sp!=oldsp)
   { if(tag((*(sp-1)))!=ILIST)
      rt=new(ILIST,pop(),rt);
     else
     {  tree=(*(sp-1));
        while(tag(tl(tree))==ILIST)
         tree=tl(tree);
        tl(tree)=new(ILIST,tl(tree),rt);
        rt=pop();
     }
   }  
   return new(ILIST,rt,s);
}

OBJ applyterm(rule,string)
OBJ rule,string;
{  OBJ r;
   extern OBJ applyt();
   if(trace)
   {  ++tracedepth;
      tracein(rule);
      tracein(string);
   }
   r=applyt(rule,string);
   if(trace)
   {  tracein(r);
      --tracedepth;
   }
   return r;
}

OBJ applyt(rule,string)
OBJ rule,string;
{  OBJ r;
   extern OBJ match(),matchchar(),matchword(),matchnumb(),matchid(),treename();
   switch(tag(rule))
   {  case STRING:return match(rule,string);
      case DEF:
      case NAME:r=iexp(rule);
                    break;
      case EXPR:switch(tag(hd(rule)))
                {  case ORNUMB:return matchnumb(string);
                   case ORNAME:return matchword(string);
                   case ORID:return matchid(string);
                   case ORCHARACTER:return matchchar(string);
                   case ORFAIL:return RFAIL;
                   case ORSTOP:return RSTOP;
                   default:return applyterm(iexp(hd(rule)),string);
                }
      case RULE:return apply(irule(rule),string);
      case IRULE:return apply(rule,string);
      case OREMPTY:return new(ILIST,NIL,string);
      case ORNUMB:return treename(RNUMB,matchnumb(string));
      case ORNAME:return treename(RNAME,matchword(string));
      case ORID:return treename(RID,matchid(string));
      case ORCHARACTER:return treename(RCHARACTER,matchchar(string));
      case ORFAIL:return RFAIL;
      case ORSTOP:return RSTOP;
      default:rerror(1,rule,rule,"rule");
   }
   switch(tag(r))
   {  case STRING:push(r);r=match(r,string);--sp;
                  break;
      case RULE:r=apply(irule(r),string);
                break;
      case IRULE:r=apply(r,string);
                 break;
      case OREMPTY:r=new(ILIST,NIL,string);
                   break;
      case ORNUMB:r=matchnumb(string);
                  break;
      case ORNAME:r=matchword(string);
                  break;
      case ORID:r=matchid(string);
                  break;
      case ORCHARACTER:r=matchchar(string);
      case ORFAIL:return RFAIL;
      case ORSTOP:return RSTOP;
      default:rerror(1,rule,r,"rule");
   }
   return r==RSTOP?RSTOP:treename(hd(rule),r);
}

OBJ match(s1,s2)
OBJ s1,s2;
{  OBJ s;
   if(s2==NIL)
    return NIL;
   if((int)value(hd(s1))!=(int)value(hd(s2)))
    while((int)value(hd(s2))==' ' || (int)value(hd(s2))=='\n')
    {  s2=stl(s2);
       if(s2==NIL)
        return NIL;
    }
   s=s1;
   while(s1!=NIL)
   {  if(s2==NIL)
       return NIL;
      if((int)value(hd(s1))!=(int)value(hd(s2)))
       return NIL;
      s1=tl(s1);
      s2=stl(s2);
   }
   return new(ILIST,s,s2);
}
   
OBJ matchword(s)
OBJ s;
{  OBJ w;
   if(s==NIL)
    return NIL;
   if(((int)value(hd(s))<'a' || (int)value(hd(s))>'z') &&
      ((int)value(hd(s))<'A' || (int)value(hd(s))>'Z'))
    while((int)value(hd(s))==' ' || (int)value(hd(s))=='\n')
    {  s=stl(s);
       if(s==NIL)
        return NIL;
    }
   if(((int)value(hd(s))<'a' || (int)value(hd(s))>'z') &&
      ((int)value(hd(s))<'A' || (int)value(hd(s))>'Z'))
    return NIL;
   push(w=new(STRING,hd(s),NIL));
   s=stl(s);
   while(s!=NIL)
   {  if(((int)value(hd(s))<'a' || (int)value(hd(s))>'z') &&
         ((int)value(hd(s))<'A' || (int)value(hd(s))>'Z'))
       break;
      tl(w)=new(STRING,hd(s),NIL);
      w=tl(w);
      s=stl(s);
   }
   return new(ILIST,pop(),s);
}
 
OBJ matchnumb(s)
OBJ s;
{  OBJ w;
   if(s==NIL)
    return NIL;
   if((int)value(hd(s))<'0' || (int)value(hd(s))>'9')
    while((int)value(hd(s))==' ' || (int)value(hd(s))=='\n')
    {  s=stl(s);
       if(s==NIL)
        return NIL;
    }
   if((int)value(hd(s))<'0' || (int)value(hd(s))>'9')
    return NIL;
   push(w=new(STRING,hd(s),NIL));
   s=stl(s);
   while(s!=NIL)
   {  if((int)value(hd(s))<'0' || (int)value(hd(s))>'9')
       break;
      tl(w)=new(STRING,hd(s),NIL);
      w=tl(w);
      s=stl(s);
   }
   return new(ILIST,pop(),s);
}

OBJ matchid(s)
OBJ s;
{  OBJ w;
   if(s==NIL)
    return NIL;
   if(((int)value(hd(s))<'a' || (int)value(hd(s))>'z') &&
      ((int)value(hd(s))<'A' || (int)value(hd(s))>'Z'))
    while((int)value(hd(s))==' ' || (int)value(hd(s))=='\n')
    {  s=stl(s);
       if(s==NIL)
        return NIL;
    }
   if(((int)value(hd(s))<'a' || (int)value(hd(s))>'z') &&
      ((int)value(hd(s))<'A' || (int)value(hd(s))>'Z'))
    return NIL;
   push(w=new(STRING,hd(s),NIL));
   s=stl(s);
   while(s!=NIL)
   {  if(((int)value(hd(s))<'0' || (int)value(hd(s))>'9') &&
         ((int)value(hd(s))<'a' || (int)value(hd(s))>'z') &&
         ((int)value(hd(s))<'A' || (int)value(hd(s))>'Z'))
       break;
      tl(w)=new(STRING,hd(s),NIL);
      w=tl(w);
      s=stl(s);
   }
   return new(ILIST,pop(),s);
}

OBJ matchchar(s)
OBJ s;
{  if(s==NIL)
    return NIL;
   if((char)value(hd(s))=='\\')
   {  s=stl(s);
      if(s==NIL)
       return NIL;
   }
   push(new(STRING,hd(s),NIL));
   s=stl(s);
   return new(ILIST,pop(),s);
}


OBJ treename(n,ts)
OBJ n,ts;
{  if(ts==NIL)
    return NIL;
   return new(ILIST,new(IFIELD,n,hd(ts)),tl(ts));
}

#define MAXNONTERMS 200
char * nontermstack[MAXNONTERMS];
char ** nontermp;

initnonterm()
{  nontermp=nontermstack;  }

nontermpush(n)
char * n;
{  if(nontermp>nontermstack+MAXNONTERMS-1)
    serror(10);
   (*nontermp)=n;
    ++nontermp;
}

char * nontermpop()
{  if(nontermp==nontermstack)
    serror(11);
   --nontermp;
   return (*nontermp);
}

nontermlook(n)
char * n;
{  char ** ntp;
   ntp=nontermstack;
   while(ntp<nontermp)
    if((*ntp)==n)
     return 1;
    else
     ntp++;
   return 0;
}

OBJ addterminal(t,tlist)
OBJ t,tlist;
{  OBJ p;
   if(tlist==NIL)
    return new(ILIST,t,NIL);
   p=tlist;
   while(p!=NIL)
    if(eq(hd(p),t))
     return tlist;
    else
     p=tl(p);
   return new(ILIST,t,tlist);
}

OBJ iterminals(r)
OBJ r;
{  extern OBJ getandterm();

   initnonterm();
   return getandterm(r,NIL);
}

OBJ getterminals(r,tlist)
OBJ r,tlist;
{  OBJ ts,fvs;
   extern OBJ getorterms();

   push(r);
   if((fvs=hd(r))!=NIL)
   {  entenv();
      pushfvs(fvs);
   }
   r=tl(r);
   ts=tlist;
   while(r!=NIL)
   {  ts=getorterms(hd(r),ts);
      r=tl(r);
   }
   if(fvs!=NIL)
    lenv();
   --sp;
   return ts;
}

OBJ getorterms(r,tlist)
OBJ r,tlist;
{  OBJ ts;
   extern OBJ getandterm();
   ts=tlist;
   while(r!=NIL)
   {  ts=getandterm(hd(r),ts);
      r=tl(r);
   }
   return ts;
}

OBJ getandterm(r,tlist)
OBJ r,tlist;
{  while(1)
    switch(tag(r))
    {  case DEF:if(nontermlook(name(hd(r))))
                 return tlist;
               nontermpush(name(hd(r)));
                r=iexp(r);
                break;
       case NAME:if(nontermlook(name(r)))
                      return tlist;
                     nontermpush(name(r));
                     r=iexp(r);
                     break;
       case EXPR:r=iexp(hd(r));
                 break;
       case RULE:return getterminals(irule(r),tlist);
       case IRULE:return getterminals(r,tlist);
       case STRING:
       case ORNUMB:
       case ORNAME:
       case ORID:
       case ORCHARACTER:
       case ORFAIL:
       case ORSTOP:return addterminal(r,tlist);
       case OREMPTY:return tlist;
       default:rerror(1,r,r,"rule");
    }
}
