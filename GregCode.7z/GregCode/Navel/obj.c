#include "defs.h"

#include <signal.h>

OBJ objs;

OBJ ofree;

long objno,objcount;

OBJ * stack;
OBJ * sb,* sp,* STOP;

OBJ * tstack;
OBJ * tp,* TTOP;

OBJ ** rstack;
OBJ ** rp,** RTOP;

short sysobjno;

OBJ NIL,TRUEO,FALSEO,REMPTY,RNUMB,RNAME,READ,READLN,RFAIL,RAND,RID,RCHARACTER;
OBJ RSTOP;

short interrupt;
extern reset();

extern struct node * add();

extern serror();

/* extern short strace; */
extern pexp(),nl();
extern putch(),fprint();
extern OBJ defs,progtree;

initobjs(first)
int first;
{  OBJ i;

   if(first)
   {  objs = (OBJ)malloc(sizeof(struct obj)*OBJNO);
      stack = (OBJ *)malloc(sizeof(OBJ)*SLENGTH);
      tstack = (OBJ *)malloc(sizeof(OBJ)*TLENGTH);
      rstack = (OBJ **)malloc(sizeof(OBJ *)*RLENGTH);

      NIL=objs;
      tag(NIL)=ONIL;
      hd(NIL)=NIL;
      tl(NIL)=NIL;
   }

   objno=OBJNO-1;
   ofree=NIL;
   objcount=1;
   i=objs+1;
   while(objcount<objno)
   { objcount++;
     i->ot=FREE;
     i->ov.c.head=ofree;
     ofree=i;
     ++i;
   }

   sysobjno=1;
   addsysobj(&TRUEO,OTRUE,"true");
   addsysobj(&FALSEO,OFALSE,"false");
   addsysobj(&RNAME,ORNAME,"word");
   addsysobj(&RNUMB,ORNUMB,"number");
   addsysobj(&REMPTY,OREMPTY,NULL);
   addsysobj(&READ,OREAD,"read");
   addsysobj(&READLN,OREADLN,"readln");
   addsysobj(&RFAIL,ORFAIL,"fail");
   addsysobj(&RID,ORID,"identifier");
   addsysobj(&RCHARACTER,ORCHARACTER,"character");
   addsysobj(&RAND,ORAND,NULL);
   addsysobj(&RSTOP,ORSTOP,"stop");

}

addsysobj(o,t,n)
OBJ * o;
short t;
char * n;
{  extern OBJ newatom();
   *o=newatom(t,n==NULL?NULL:(long)add(t,n)->pname);
   ++sysobjno;
}

/*VARARGS1*/
OBJ new(ntag,nhead,ntail)
register short ntag;
register OBJ nhead,ntail;
{  register OBJ newn;
   if(ofree==NIL)
   {  garb(nhead,ntail);
      if(ofree==NIL)
       serror(3);
   }
   newn=ofree;
   ofree=hd(ofree);
   tag(newn)=ntag;
   hd(newn)=nhead;
   tl(newn)=ntail;
   return newn;
}

OBJ newatom(t,n)
short t;
long n;
{  OBJ newn;
   newn=new(t,NIL,NIL);
   value(newn)=n;
   return newn;
}

greset()
{  interrupt=1;  }

garb(nhead,ntail)
OBJ nhead,ntail;
{  register long j;
   register OBJ * i,o;

   interrupt=0;
   signal(SIGINT,greset);

   printf("\nGARBAGE COLLECTION ");

   j=objno-sysobjno;
   while(j<objno)
    mark(&(objs[j++]));

   mark(defs);

   mark(progtree);

   mark(nhead);

   mark(ntail);

   i=tstack;
   while(i<tp)
    mark(*(i++));

   i=stack;
   while(i<sp)
    mark(*(i++));

   ofree=NIL;
   objcount=0;
   j=0;
   o=objs;
   while(j<objno)
   {  if((o->ot)&MARK)
       o->ot=(o->ot)&UNMARK;
      else
      {  ++objcount;
         o->ot=FREE;
         o->ov.c.head=ofree;
         ofree=o;
      }
      ++o;
      ++j;
   }

   printf("%d CELL%c\n\n",objcount,objcount==1?' ':'S');

   signal(SIGINT,reset);
   if(interrupt)
    reset();

}

mark(l)
OBJ l;
{  while(!(tag(l)&MARK))
   {  tag(l)=tag(l)|MARK;
      if((tag(l)&UNMARK)<MAXOBJ)
       return;
      mark(hd(l));
      l=tl(l);
   }
}

pobj(l)
OBJ l;
{  printf("%lx %x ",l,tag(l));
   pexp(l);
   nl();
}

pobjs()
{  short i;
   i=0;
   while(i<objno)
    pobj(&(objs[i++]));
   nl();
}

initstacks()
{  tp=tstack;
   TTOP=tstack+TLENGTH;
   sp=stack;
   sb=stack;
   STOP=stack+SLENGTH;
   rp=rstack;
   RTOP=rstack+RLENGTH;
}

tpush(o)
OBJ o;
{ if(tp==TTOP)
   serror(4);
  *(tp++)=o;
}

OBJ tpop()
{  if(tp==tstack)
    serror(5);
   return *(--tp);
}

push(o)
register OBJ o;
{  if(sp==STOP)
    serror(6);
   *(sp++)=o;
/*   if(strace) */
/*    pstack(1); */
}

OBJ pop()
{  if(sp==stack)
    serror(7);
   return *(--sp);
}

npush(n,o)
OBJ n,o;
{  if(sp+1>=STOP)
    serror(6);
   *(sp++)=n;
   *(sp++)=o;
/*   if(strace) */
/*    pstack(2); */
}

pstack(n)
short n;
{  short i;
   OBJ * bot;
   bot=sp<stack+n*PDEPTH?stack:sp-n*PDEPTH;
   while(bot<sp)
   {  fprint("%d ",bot);
      i=0;
      while(i<n)
      {  pexp(*(bot++));
         putch(' ');
         ++i;
      }
      putch('\n');
   }
   putch('\n');
}

entenv()
{  if(rp==RTOP)
    serror(8);
   *(rp++)=sb;
   sb=sp;
}

lenv()
{  if(rp==rstack)
    serror(9);
   sp=sb;
   sb=(*(--rp));
}

pmark(l,m)
OBJ l;
char * m;
{  printf("%s\n",m);
   pexp(l);
   nl();
   mark(l);
   pexp(l);
   nl();
}

