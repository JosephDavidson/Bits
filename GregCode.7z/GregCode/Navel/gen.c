/* NOTE random/srandom on VAX => rand/srand ??? */

#include "defs.h"

extern OBJ iexp(),isusp(),irule();

extern rerror();

extern push();
extern OBJ pop(),* sp;
extern OBJ new(),newatom();
extern OBJ NIL,REMPTY,RFAIL;

extern entenv(),lenv();

extern pushfvs();

extern short lazy;

initrand()
{  srandom(time(0));  }

OBJ nirand()
{  return newatom(ONUMB,random());  }

OBJ gen(l)
OBJ l;
{  OBJ g;
   extern OBJ randselect(),rulegen(),chargen();
   extern int gnumb(),gword(),gid();
   push(g=iexp(l));
   switch(tag(g))
   {  case STRING:
      case ILIST:g=randselect(g);
                 break;
      case ORNUMB:g=chargen(gnumb);
                 break;
      case ORNAME:g=chargen(gword);
                 break;
      case ORID:g=chargen(gid);
                break;
      case IRULE:g=rulegen(g);
                 break;
      default:rerror(1,l,g,"rule or list for random manipulation");
   }
   --sp;
   return g;
}

OBJ randselect(l)
OBJ l;
{  OBJ ll;
   short i,r;
   i=1;
   ll=l;
   while(tag(tl(ll))==ILIST || tag(tl(ll))==STRING)
   {  ++i;
      ll=tl(ll);
   }
   if(tl(ll)!=NIL)
    ++i;
   r=random()%i;
   if(r+1==i && tl(ll)!=NIL)
   {  if(lazy)
       tl(ll)=isusp(tl(ll));
      if(tag(tl(ll))==ILIST || tag(tl(ll))==STRING)
       return lazy?hd(tl(ll))=isusp(hd(tl(ll))):hd(tl(ll));
      return tl(ll);
   }
   while(r--)
    l=tl(l);
   return lazy?hd(l)=isusp(hd(l)):hd(l);
}

OBJ chargen(f)
int (*f)();
{  OBJ l;
   push(l=new(STRING,newatom(OCHAR,(*f)()),NIL));
   while(random()%2)
   {  tl(l)=new(STRING,newatom(OCHAR,(*f)()),NIL);
      l=tl(l);
   }
   return pop();
}

int gnumb()
{  return (random()%10)+'0';  }

int gword()
{  int i;
   i=random()%2;
   return (random()%26)+(i?'a':'A');
}

int gid()
{  int i;
   i=random()%3;
   return i==0?
           (random()%10)+'0':
          i==1?
           (random()%26)+'a':
          (random()%26)+'A';
}

OBJ rulegen(l)
OBJ l;
{  short o,r;
   OBJ ll;
   extern OBJ optgen();
   ll=tl(l);
   o=0;
   while(ll!=NIL)
   {  ++o;
      ll=tl(ll);
   }
   r=random()%o;
   ll=tl(l);
   while(r--)
    ll=tl(ll);
   entenv();
   pushfvs(hd(l));
   l=optgen(hd(ll));
   lenv();
   return l;
}

OBJ optgen(l)
OBJ l;
{  extern OBJ itemgen();
   OBJ s;
   s=itemgen(hd(l));
   while(s==NIL)
   {  l=tl(l);
      if(l==NIL)
       return NIL;
      s=itemgen(hd(l));
   }
   push(s);
   while(tl(s)!=NIL)
    s=tl(s);
   l=tl(l);
   while(l!=NIL)
   {  tl(s)=itemgen(hd(l));
      while(tl(s)!=NIL)
       s=tl(s);
      l=tl(l);
   }
   return pop();
}

OBJ itemgen(l)
OBJ l;
{  OBJ ll;
   extern OBJ stringcopy();
   switch(tag(l))
   {  case ORNUMB:return chargen(gnumb);
      case ORNAME:return chargen(gword);
      case ORID:return chargen(gid);
      case ORFAIL:
      case OREMPTY:return NIL;
      case STRING:return stringcopy(l);
      case EXPR:ll=iexp(hd(l));
                break;
      default:ll=iexp(l);
   }
   switch(tag(ll))
   {  case ORNUMB:return chargen(gnumb);
      case ORNAME:return chargen(gword);
      case ORID:return chargen(gid);
      case ORFAIL:
      case OREMPTY:return NIL;
      case STRING:return stringcopy(ll);
      case IRULE:return rulegen(ll);
   }
   rerror(1,l,ll,"rule for generation");
}
   
OBJ stringcopy(l)
OBJ l;
{  OBJ ll;
   push(ll=new(STRING,NIL,NIL));
   while(1)
   {  hd(ll)=hd(l);
      l=tl(l);
      if(l==NIL)
       break;
      tl(ll)=new(STRING,NIL,NIL);
      ll=tl(ll);
   }
   return pop();
}
