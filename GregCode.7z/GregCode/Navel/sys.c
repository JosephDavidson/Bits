#include "defs.h"
#include <signal.h>
#include <setjmp.h>
#include <sys/types.h>
#include <sys/times.h>

struct tms t1,t2;

jmp_buf env;

extern int ch;
extern short symb;
extern struct node *objname;

extern initnames(),initprint(),inittrace();
extern initstacks(),initobjs(),initdefs(),initrand();

extern ptree();
extern struct node nametree;

extern pobjs();
extern OBJ new(),newatom();
extern push();
extern OBJ pop();
extern OBJ * sp;

extern OBJ NIL;

extern short errors;
extern error(),nerror();

extern pexp();

extern pdef(),pdefs();
extern def(),drop();

extern short inlet;

extern OBJ expr();

extern OBJ namepass();

extern OBJ iexp();
extern eq();

extern OBJ iwrite();

OBJ progtree;

OBJ progstring;

FILE *cinput,*coutput;
short loading,saving,isfile;
char filename[FNLENGTH];

char command[CLENGTH];
short iscomm;

short lazy,trace,timer;

/* short etrace; */
/* short strace; */

int (*charin)();

void showexp(e)
OBJ e;
{  short oldtrace;
   oldtrace=trace;
   trace=1;
   pexp(e);
   trace=oldtrace;
}

void reset()
{  longjmp(env,1);  }

int getch()
{  return (*charin)();  }

int termcharin()
{  return getc(cinput);  }

int filecharin()
{  extern int putch();
   int c;
   c=getc(cinput);
   if(c!=EOF)
    putch(c);
   return c;
}

int putch(c)
int c;
{  return putc(c,coutput);  }

nl()
{  putch('\n');  }

fprint(f,a,b,c,d,e)
char *f;
long a,b,c,d,e;
{ fprintf(coutput,f,a,b,c,d,e);  }

initio()
{  cinput=stdin;
   coutput=stdout;
   charin=termcharin;
}


inittraces()
{  trace=0;
   timer=0;
   lazy=1;
/*   strace=0; */
/*   etrace=0; */
}

main(argc,argv)
int argc;
char * argv[];
{  
   extern sysinterpreter();

   initnames();
   initobjs(1);
   initdefs();
   initfile();
   initnsyscall();
   inittraces();
   initrand();

   printf("\nNAVEL %s\n\n",VERSION);

/* RETURN HERE AFTER SYSTEM ERROR OR ^C */

   setjmp(env);
   signal(SIGINT,reset);
   
   initio();
   initfio();
   initstacks();
   initprint();
   inittrace();

   sload(&argc,argv);

   printf("ok\n");

   ch=getch();
   while(1)
   {  errors=0;
      progtree=NIL;
      sysinterpreter();
      if(errors)
       nl();
      printf("ok\n");
   }
}


sysinterpreter()
{  OBJ result;
   extern OBJ interpreter();

   inlet=0;
   lex();
   switch(symb)
   {  case DEF:
               def();
               return;
      case DROP:
                drop();return;
      case LOAD:
                fload();return;
      case SAVE:
                save();return;
      case '!':
               nsyscall();return;
/*      case ETRACE: */
/*      case STRACE: */
      case TIME:
      case TRACE:
      case DEFS:
      case TRACES:
      case END:
      case LAZY:
               envcomm();return;
      case EDIT:
                edit();return;
      case RESET:
                 sreset();
      case REPEAT:
                  srepeat();
      case ';':
               return;
      default:
              if(timer)
                times(&t1);
              result=interpreter();
              if(timer)
               times(&t2);
              if(result!=NIL)
              {  showexp(result);
                 nl();
              }
              if(timer)
               dotiming();
   }
}

OBJ interpreter()
{  OBJ result;
   push(progtree);
   progtree=NIL;
   progtree=expr();
   checksemi();
   if(!errors && inlet)
    progtree=namepass(progtree);
   if(!errors)
    result=iexp(progtree);
   else
    result=NIL;
   progtree=pop();
   return result;
}

checksemi()
{  if(symb!=';')
   {  if(!errors)
       error(1,";");
      skippast(';');
   }
}

skippast(c)
int c;
{  while(ch!=c)
    ch=getch();
   ch=' ';
}

envcomm()
{  short s;
   s=symb;
   lex();
   checksemi();
   if(errors)
    return;
   switch(s)
   {  case END:unlink("editfile");
               printf("\ncheerio\n\n");
               exit(0);
      case DEFS:pdefs();
                return;
      case TRACES:pstatus(trace,"trace");
                  pstatus(timer,"timer");
                  pstatus(lazy,"lazy lists");
/*                  pstatus(strace,"stack trace"); */
/*                  pstatus(etrace,"environment trace"); */
                  return;
      case TIME:flip(&timer,"timer");
                return;
      case TRACE:flip(&trace,"trace");
                 return;
      case LAZY:flip(&lazy,"lazy lists");
                return;
/*      case STRACE:flip(&strace,"stack trace"); */
/*                  return NIL; */
/*      case ETRACE:flip(&etrace,"environment trace"); */
/*                  return; */
   }
}

initfile()
{  isfile=0;
}

initfio()
{  loading=0;
   saving=0;
}

fload()
{  getfilename();
   if(!errors)
    load(filename);
}

load(filename)
char * filename;
{  FILE *f,*oldcinput;
   int (*oldcharin)();
   short oldloading;
   extern sysinterpreter();
   f=fopen(filename,"r");
   if(!f)
   {  error(3,filename);
      return;
   }
   oldloading=loading;
   loading=1;
   oldcinput=cinput;
   cinput=f;
   oldcharin=charin;
   charin=filecharin;
   progtree=NIL;
   ch=' ';
   while(ch!=EOF && !errors)
    sysinterpreter();
   fclose(f);
   loading=oldloading;
   cinput=oldcinput;
   charin=oldcharin;
   ch=' ';
}

save()
{  FILE *f;
   getfilename();
   if(errors)
    return;
   f=fopen(filename,"w");
   if(!f)
   {  error(3,filename);
      return;
   }
   saving=1;
   coutput=f;
   pdefs();
   fclose(f);
   coutput=stdout;
   saving=0;
}

edit()
{  OBJ a;
   FILE *f;
   extern OBJ finddef();

   lex();
   if(symb==ONAME)
   {  a=finddef(objname->pname);
      if(a==NIL)
       nerror(1,objname->pname);
      lex();
   }
   else
    a=NIL;
   checksemi();
   if(errors)
    return;
   if(a!=NIL)
   {  f=fopen("editfile","w");
      if(!f)
      {  error(3,"edit file");
         return;
      }
      saving=1;
      coutput=f;
      pdef(a);
      fclose(f);
      coutput=stdout;
      saving=0;
   }
   system("vi editfile");
   load("editfile");
}

getfilename()
{  short i;
   while(ch==' ' || ch=='\n')
    ch=getch();
   i=0;
   while(i<FNLENGTH-1 && ch!=';' && ch!='\n')
   {  filename[i++]=ch;
      ch=getch();
   }
   if(i==0 && !isfile)
    error(2);
   else
   if(i>0)
   { filename[i]='\0';
     isfile=1;
   }
   lex();
   checksemi();
   if(!errors && i==0)
    printf("using %s\n",filename);
}

initnsyscall()
{ iscomm=0; }

nsyscall()
{  short i;

   i=0;
   if(ch=='!' && !iscomm)
    error(4);
   if(ch=='!')
    ch=getch();
   else
   {  while(i<CLENGTH-1 && ch!='\n' && ch!=';')
      {  command[i++]=ch;
         ch=getch();
      }
      command[i]='\0';
      while(ch!='\n' && ch!=';')
       ch=getch();
      iscomm=1;
   }
   lex();
   checksemi();
   if(errors)
    return;
   if(i==0)
    printf("%s\n",command);
   system(command);
}

flip(flag,flagname)
short *flag;
char * flagname;
{  (*flag)=(!(*flag));
   pstatus(*flag,flagname);
}

pstatus(flag,flagname)
short flag;
char * flagname;
{  printf("%s %s\n",flagname,flag?"on":"off");  }

sreset()
{  lex();
   checksemi();
   initnames();
   initobjs(0);
   initdefs();
   inittraces();
   printf("SYSTEM RESET\n");
   reset();
}

sload(argc,argv)
int * argc;
char * argv[];
{  short i;
   if(*argc!=2)
    return;
   *argc=(-2);
   isfile=1;
   i=0;
   while(i<FNLENGTH-1)
    if(argv[1][i]=='\0')
     break;
    else
    {  filename[i]=argv[1][i];
       ++i;
    }
   filename[i]='\0';
   load(filename);
}

int llength(l)
OBJ l;
{  int ll;
   ll=0;
   while(l!=NIL)
   { l=tl(l);
     ll++;
   }
   return ll;
}

char * makestring(l)
OBJ l;
{  char * s;
   int i;
   s=(char *)malloc(1+llength(l));
   i=0;
   while(l!=NIL)
   {  s[i++]=(char)value(hd(l));
      l=tl(l);
   }
   s[i]='\0';
   return s;
}

OBJ isystem(l)
OBJ l;
{  OBJ c;
   char *scomm;
   c=iexp(hd(l));
   if(tag(c)!=STRING)
    rerror(1,hd(l),c,"command string");
   scomm=makestring(c);
   l=newatom(ONUMB,system(scomm));
   free(scomm);
   return l;
}

OBJ ifwrite(l)
OBJ l;
{  FILE * fp;
   OBJ fn;
   char * f;
   fn=iexp(hd(l));
   if(tag(fn)!=STRING)
    rerror(1,hd(l),fn,"file name string");
   fp=fopen(f=makestring(fn),"w");
   free(f);
   if(!fp)
    rerror(5,fn,NIL,"write");
   coutput=fp;
   iwrite(l=iexp(tl(l)));
   fclose(fp);
   coutput=stdout;
   return l;
}

OBJ ifread(l)
OBJ l;
{  FILE * fp;
   OBJ fn;
   char * f;
   int ch;
   fn=iexp(hd(l));
   if(tag(fn)!=STRING)
    rerror(1,hd(l),fn,"file name string");
   fp=fopen(f=makestring(fn),"r");
   free(f);
   if(!fp)
    rerror(5,fn,NIL,"read");
   ch=getc(fp);
   if(ch==EOF)
   {  fclose(fp);
      return NIL;
   }
   push(l=new(IFREAD,fn,NIL));
   tl(l)=newatom(ONUMB,fp);
   l=new(STRING,newatom(OCHAR,ch),l);
   --sp;
   return l;
}

OBJ iifread(l)
OBJ l;
{  FILE * fp;
   int ch;
   fp=(FILE *)value(tl(l));
   ch=getc(fp);
   if(ch==EOF)
   {  fclose(fp);
      return NIL;
   }
   push(l);
   l=new(STRING,newatom(OCHAR,ch),l);
   --sp;
   return l;
}

int stringcharin()
{  int c;
   OBJ t;
   if(progstring==NIL)
    return ';';
   c=(int)value(hd(progstring));
   t=tl(progstring);
   progstring=t==NIL?NIL:tag(t)==STRING?t:(tl(progstring)=iifread(t));
   return c;
}

OBJ ieval(l)
OBJ l;
{  OBJ result,oldprogstring;
   int (*oldcharin)();
   result=iexp(hd(l));
   if(tag(result)!=STRING)
    rerror(1,hd(l),result,"program string for evaluation");
   oldprogstring=progstring;
   push(progstring=result);
   oldcharin=charin;
   charin=stringcharin;
   ch=getch();
   lex();
   result=interpreter();
   charin=oldcharin;
   progstring=oldprogstring;
   ch=' ';
   --sp;
   return result;
}

srepeat()
{  OBJ l;
   lex();
   progtree=expr();
   checksemi();
   if(!errors && inlet)
    progtree=namepass(progtree);
   if(errors)
    return;
   while(1)
   {  if(timer)
       times(&t1);
      l=iexp(progtree);
      if(timer)
       times(&t2);
      showexp(l);
      nl();
      if(timer)
       dotiming();
   }
}


dotiming()
{  float ut,st;
   ut=((float)(t2.tms_utime-t1.tms_utime))/60;
   st=((float)(t2.tms_stime-t1.tms_stime))/60;
   printf("%.1f u %.1f s\n",ut,st);
}
