#include "defs.h"

struct node * nametree;

char namebuff[NAMESIZE];

int ch;
short symb;
struct node *objname;
long objval;
short space;

extern serror();

extern int getch();
extern putch(),nl();

extern isfile,endload();
extern short loading;

initnames()
{  extern struct node *add();

   nametree=NULL;

   add(LOAD,"load");
   add(SAVE,"save");
   add(DEFS,"defs");
   add(EDIT,"edit");
   add(DROP,"drop");
   add(DEF,"def");
   add(END,"end");
   add(IF,"if");
   add(THEN,"then");
   add(ELSE,"else");
   add(NOT,"not");
   add(CASE,"case");
   add(OF,"of");
   add(HD,"hd");
   add(TL,"tl");
   add(LET,"let");
   add(IN,"in");
   add(AND,"and");
   add(LAM,"lam");
   add(TRACE,"trace");
   add(TRACES,"traces");
   /* add(STRACE,"strace"); */
   /* add(ETRACE,"etrace"); */
   add(RULECASE,"rule");
   add(WRITE,"write");
   add(RESET,"reset");
   add(ISNUMB,"isnumb");
   add(ISCHAR,"ischar");
   add(ISBOOL,"isbool");
   add(ISLIST,"islist");
   add(ISSTRING,"isstring");
   add(ISRULE,"isrule");
   add(ISFUNC,"isfunc");
   add(ISFIELD,"isfield");
   add(FREAD,"fread");
   add(FWRITE,"fwrite");
   add(SYSTEM,"system");
   add(EVAL,"eval");
   add(CHAR,"char");
   add(REPEAT,"repeat");
   add(TERMINALS,"terminals");
   add(WRITELN,"writeln");
   add(TIME,"time");
   add(LAZY,"lazy");
   add(EXIT,"exit");
   add(SIZE,"osize");

}

char *addname(n)
char *n;
{  char *nn;
   short i;

   i=0;
   while(n[i++]!='\0')
    ;
   nn=malloc(i);
   if(nn==0)
    serror(2);
   while(--i>=0)
    nn[i]=n[i];
   return nn;
}

struct node *newnode(t,n)
short t;
char *n;
{  struct node *nn;

   nn=(struct node *)malloc(sizeof(struct node));
   if(nn==0)
    serror(1);
   nn->token=t;
   nn->pname=addname(n);
   nn->left=NULL;
   nn->right=NULL;
   return nn;
}

short comp(s1,s2)
char *s1,*s2;
{  while(*s1==*s2)
    if(*s1=='\0')
     return 0;
    else
    { ++s1;++s2;  }
   return *s1-*s2;
}

struct node *add(t,n)
short t;
char *n;
{  struct node *nn;
   short c;

   if(nametree==NULL)
    return nametree=newnode(t,n);
   nn=nametree;
   while(1)
    if((c=comp(n,nn->pname))==0)
     return nn;
    else
    if(c<0)
     if(nn->left==NULL)
      return nn->left=newnode(t,n);
     else
      nn=nn->left;
    else
    if(nn->right==NULL)
     return nn->right=newnode(t,n);
    else
     nn=nn->right;
}

readname()
{  short bp;

   bp=0;
   while(((ch>='a' && ch<='z') ||
          (ch>='A' && ch<='Z') ||
          (ch>='0' && ch<='9') || ch=='_') && bp<NAMESIZE-1)
   {  namebuff[bp++]=ch;
      ch=getch();
   }
   namebuff[bp]='\0';
   while((ch>='a' && ch<='z') ||
         (ch>='A' && ch<='Z') ||
         (ch>='0' && ch<='9') || ch=='_')
    ch=getch();
}

long readnumb()
{  long v;
   v=0;
   while(ch>='0' && ch<='9')
   {  v=v*10+ch-'0';
      ch=getch();
   }
   return v;
}

lex()
{  space=0;
   while(1)
    switch(ch)
    { case ' ':
      case '	':
      case '\n':ch=getch();
                space=1;
                break;
      case '#':while((ch=getch())!='#');
               ch=getch();
               break;
      case '!':
      case '(':
      case ')':
      case ',':
      case '\'':
      case '"':
      case '.':
      case '{':
      case '}':
      case '[':
      case ']':
      case '@':
      case '^':
      case '?':
      case ':':
               symb=ch;
               ch=getch();
               return;
      case '=':
               symb=EQ;
               ch=getch();
               return;
      case '+':
               symb=ADD;
               ch=getch();
               return;
      case '*':
               symb=MULT;
               ch=getch();
               return;
      case '/':
               symb=DIV;
               ch=getch();
               return;
      case '%':
               symb=MOD;
               ch=getch();
               return;
      case '-':
               ch=getch();
               if(ch=='>')
               {  ch=getch();
                  symb=COND;
               }
               else
                symb=SUB;
               return;
      case '<':
               ch=getch();
               if(ch=='>')
               {  ch=getch();
                  symb=NEQ;
               }
               else
               if(ch=='=')
               {  ch=getch();
                  symb=LE;
               }
               else
                symb=LT;
               return;
      case '>':
               ch=getch();
               if(ch=='=')
               {  ch=getch();
                  symb=GE;
               }
               else
                symb=GT;
               return;
      case ';':symb=';';
               ch=getch();
               return;
      case EOF:if(!loading)
                exit(0);
               symb=';';                  /* bodge in case of missing   */
               return;                    /* ';' before EOF in file     */
      case '&':
               ch=getch();
               symb=LAND;
               return;
      case '|':ch=getch();
               symb=LOR;
               return;
      default:if(ch>='0' && ch<='9')
              {  symb=ONUMB;
                 objval=readnumb();
                 return;
              }
              if((ch>='a' && ch<='z') ||
                 (ch>='A' && ch<='Z'))
              {  readname();
                 objname=add(ONAME,namebuff);
                 symb=objname->token;
                 return;
              }
              printf("\nILLEGAL CHARACTER - %d\n",ch);
              ch=getch();
    }
}

/* ptree(t)                           */
/* struct node *t;                    */
/* {  while(t!=NULL)                   */
/*    {  ptree(t->left);              */
/*       printf("%s\n",t->pname);     */
/*       t=t->right;                  */
/*    }                               */
/* }                                  */
