#include <stdio.h>
#include <stdlib.h>

#define VERSION "2.0.1"

#ifdef sparc
#define malloc valloc
#endif

struct node {  short token; char *pname; struct node *left,*right;  };

struct cell { struct obj *head,*tail;  };

union oval {  char *n; struct cell c; long v;  };

struct obj {  short ot; union oval ov;  };

typedef struct obj *OBJ;

#define tag(l) l->ot

#define name(l) l->ov.n

#define hd(l) l->ov.c.head
#define tl(l) l->ov.c.tail

#define value(l) l->ov.v

#define ONIL 0xf00
#define ONUMB 0x0f01
#define OCHAR 0x0f02
#define ONAME 0x0f03
#define OTRUE 0x0f04
#define OFALSE 0x0f05
#define ORNAME 0x0f07
#define ORNUMB 0x0f08
#define OREMPTY 0x0f09
#define OREAD 0x0f0a
#define ORFAIL 0x0f0b
#define ORAND 0x0f0c
#define OREADLN 0x0f0d
#define ORID 0x0f0e
#define ORCHARACTER 0x0f0f
#define FREE 0x0f10
#define ORSTOP 0x0f11

#define MAXOBJ 0x0f20

#define DEF 0x0f21
#define END 0x0f22
#define LIST 0x0f23
#define DEFS 0x0f24
#define LOAD 0x0f25
#define SAVE 0x0f26
#define EDIT 0x0f27
#define DROP 0x0f28
#define ADD 0x0f29
#define SUB 0x0f2a
#define MULT 0x0f2b
#define DIV 0x0f2c
#define NEG 0x0f2d
#define EQ 0x0f2e
#define NEQ 0x0f2f
#define LT 0x0f30
#define LE 0x0f31
#define GE 0x0f32
#define GT 0x0f33
#define COND 0x0f34
#define IF 0x0f35
#define THEN 0x0f36
#define ELSE 0x0f37
#define LAND 0x0f38
#define LOR 0x0f39
#define NOT 0x0f3a
#define CASE 0x0f3b
#define OF 0x0f3c
#define STRING 0x0f3d
#define ILIST 0x0f3e
#define HD 0x0f3f
#define TL 0x0f40
#define LET 0x0f41
#define AND 0x0f42
#define IN 0x0f43
#define LAM 0x0f44
#define ILAM 0x0f45
#define ILET 0x0f46
#define BP 0x0f47
#define IBP 0x0f48
#define NAME 0x0f49
#define TRACE 0x0f4a
#define STRACE 0x0f4b
#define TRACES 0x0f4c
#define ETRACE 0x0f4d
#define RULE 0x0f4e
#define IRULE 0x0f4f
#define EXPR 0x0f50
#define FIELD 0x0f51
#define IFIELD 0x0f52
#define INDEX 0x0f53
#define SELECT 0x0f54
#define RULECASE 0x0f55
#define WRITE 0x0f56
#define RESET 0x0f57
#define MOD 0x0f58
#define ISNUMB 0x0f59
#define ISCHAR 0x0f5a
#define ISBOOL 0x0f5b
#define ISLIST 0x0f5c
#define ISRULE 0x0f5d
#define ISFUNC 0x0f5e
#define ISSTRING 0x0f5f
#define ISFIELD 0x0f60
#define IFREAD 0x0f61
#define FREAD 0x0f62
#define FWRITE 0x0f63
#define SYSTEM 0x0f64
#define EVAL 0x0f65
#define CHAR 0x0f66
#define REPEAT 0x0f67
#define TERMINALS 0x0f69
#define WRITELN 0x0f70
#define TIME 0x0f71
#define LAZY 0x0f72
#define EXIT 0x0f73
#define SIZE 0x0f74

#define MARK 0x1000
#define UNMARK 0xefff

#define NAMESIZE 15     /* max. name length  - lex.c */

#define OBJNO  256000
#define SLENGTH 80000    /* stack length - obj.c */
#define TLENGTH 80000    /* temporary stack length - obj.c */
#define RLENGTH 80000    /* return link stack length - obj.c */

#define PDEPTH 6        /* no. of stack top items for stack trace - obj.c */

#define FNLENGTH 50     /* max. length of file name - sys.c */
#define CLENGTH  50     /* max. length of command - sys.c */
