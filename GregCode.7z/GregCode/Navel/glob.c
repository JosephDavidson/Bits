#include "defs.h"

extern error(),nerror();

extern OBJ new(),newatom();
extern OBJ *tp,tpop();
extern tpush();
extern OBJ *sp,pop();
extern push();

extern OBJ expr();

extern lex();
extern short symb;
extern struct node * objname;

extern short errors;

extern short saving;
extern putch(),nl(),fprint(),pexp(),pnames();

extern short loading;

extern OBJ iexp(),ilazy();

extern OBJ params(),namepass();
extern short inlet;

extern checksemi();

extern short trace;

extern OBJ NIL;

OBJ defs;

short indef;

initdefs()
{  defs=NIL;
}

def()
{  OBJ n,e,a;
   extern OBJ find(),defbody();

   lex();
   if(symb!=ONAME)
    error(1,"name");
   else
   {  n=newatom(ONAME,objname->pname);
      lex();  
      a=find(n);
   }
   e=defbody();
   checksemi();
   if(!errors && inlet)
   {  indef=1;
      tpush(e);
      e=namepass(e);
      tp--;
      indef=0;
   }
   if(errors)
   return;
   tpush(e);
   tl(a)=ilazy(e);
   tp--;
}

OBJ defbody()
{  OBJ b;
   if(symb!=ONAME && symb!='(')
   {  if(symb!=EQ)
       error(1,"=");
      else
       lex();
      return expr();
   }
   ++inlet;
   tpush(b=new(LAM,NIL,new(LIST,params(),NIL)));
   while(symb==ONAME || symb=='(')
   {  tl(tl(b))=new(LAM,NIL,new(LIST,params(),NIL));
      b=tl(tl(b));
   }
   if(symb!=EQ)
    error(1,"=");
   else
    lex();
   tl(tl(b))=expr();
   return tpop();
}
   
OBJ find(n)
OBJ n;
{  OBJ f,b;
   if(defs==NIL)
   {  defs=new(LIST,new(DEF,n,NIL),NIL);
      if(indef)
       printf("*** ADDING NEW EMPTY GLOBAL DEFINITION FOR %s ***\n",name(n));
      return hd(defs);
   }
   f=defs;b=defs;
   while(f!=NIL)
    if(name(hd(hd(f)))==name(n))
     return hd(f);
    else
    {  b=f;
       f=tl(f);
    }
   if(indef)
    printf("*** ADDING NEW EMPTY GLOBAL DEFINITION FOR %s ***\n",name(n));
   tl(b)=new(LIST,new(DEF,n,NIL),NIL);
   return hd(tl(b));
}

OBJ lookfor(n)
OBJ n;
{  OBJ l;

   l=defs;
   while(l!=NIL)
    if(name(hd(hd(l)))==name(n))
     return hd(l);
    else
     l=tl(l);
   if(!indef)
   {  nerror(1,name(n));
      return NIL;
   }
   return find(n);
}

pdef(l)
OBJ l;
{  fprint("def %s ",name(hd(l)));
   l=tl(l);
   if(tag(l)==ILAM)
    if(hd(l)==NIL)
    {  pnames(hd(tl(l)));
       l=tl(tl(l));
       putch(' ');
    }
   while(tag(l)==LAM)
   {  pnames(hd(tl(l)));
      l=tl(tl(l));
      putch(' ');
   }
   fprint("= ");
   pexp(l);
   fprint(";\n");
}

pdefs()
{  OBJ d;
   short t;
   t=trace;
   trace=0;
   d=defs;
   while(d!=NIL)
   {  pdef(hd(d));
      d=tl(d);
      if(d!=NIL && !saving)
       nl();
   }
   trace=t;
}

drop()
{  OBJ n,b,f;
   OBJ *oldsp;
   oldsp=sp;
   lex();
   if(symb!=ONAME)
    error(1,"name");
   else
   while(symb==ONAME)
   {  push(newatom(ONAME,objname->pname));
      lex();
   }
   checksemi();
   if(errors)
    return;
   while(sp>oldsp)
   {  n=pop();
      if(defs==NIL)
       nerror(1,name(n));
      else
      if(name(hd(hd(defs)))==name(n))
       defs=tl(defs);
      else
      {  b=defs;
         f=tl(defs);
         while(f!=NIL)
          if(name(hd(hd(f)))==name(n))
          {  tl(b)=tl(f);break;  }
          else
          {  b=f;
             f=tl(f);
          }
         if(f==NIL)
           nerror(1,name(n));
      }
   }
}

OBJ finddef(n)
char * n;
{  OBJ f;
   f=defs;
   while(f!=NIL)
    if(name(hd(hd(f)))==n)
     return hd(f);
    else
     f=tl(f);
   return NIL;
}
