#include "defs.h"

extern lex();
extern short symb;
extern struct node *objname;
extern short space;

extern OBJ new(),newatom();

extern OBJ * stack;
extern OBJ * sb,* sp,* tp;

extern push(),tpush(),npush();
extern OBJ pop(),tpop(),npop();

extern OBJ ** rp;
extern entenv(),lenv();

extern error(),nerror();

extern OBJ logexp(),expr();

extern pexp(),nl();

extern OBJ NIL;

short inlet;

/* extern short etrace; */

/* extern petrace(); */

OBJ params()
{  OBJ nl,n;
   extern OBJ paramlist();
   nl=paramlist();
   if(symb!=':')
    return nl;
   tpush(n=new(LIST,nl,NIL));
   lex();
   while(!space && (symb==ONAME || symb=='('))
   {  nl=paramlist();
      if(symb!=':')
      {  tl(n)=nl;
         break;
      }
      tl(n)=new(LIST,nl,NIL);
      n=tl(n);
      lex();
   }
   return tpop();
}

OBJ paramlist()
{  OBJ nl;
   switch(symb)
   {  case '(':
               lex();
               nl=params();
               if(symb!=')')
                error(1,")");
               else
                lex();
               return nl;
      case ONAME:
                 nl=newatom(ONAME,objname->pname);
                 lex();
                 return nl;
      default:
              error(1,"name");
              return NIL;
   }
}

OBJ lam()
{  OBJ l;

   ++inlet;
   lex();
   tpush(l=new(LAM,NIL,new(LIST,params(),NIL)));
   while(symb==ONAME || symb=='(')
   {  tl(tl(l))=new(LAM,NIL,new(LIST,params(),NIL));
      l=tl(tl(l));
   }
   if(symb=='.')
    lex();
   else
    error(1,".");
   tl(tl(l))=logexp();
   return tpop();
}

OBJ let()
{  OBJ l;
   extern OBJ letdefs();

   ++inlet;
   lex();
   tpush(letdefs());
   if(symb!=IN)
    error(1,"in");
   else
    lex();
   l=expr();
   return new(LET,NIL,new(LIST,tpop(),l));
}

OBJ letdefs()
{  extern OBJ letdef();
   OBJ l;

   tpush(l=new(LIST,letdef(),NIL));
   while(symb==AND)
   {  lex();
      tl(l)=new(LIST,letdef(),NIL);
      l=tl(l);
   }
   return tpop();
}
   
OBJ letdef()
{  OBJ d;
   tpush(d=new(LIST,params(),NIL));
   if(tag(hd(d))==ONAME)
    while(symb==ONAME || symb=='(')
    {  tl(d)=new(LAM,NIL,new(LIST,params(),NIL));
       d=tl(tl(d));
    }
   if(symb!=EQ)
    error(1,"=");
   else
    lex();
   tl(d)=expr();
   return tpop();
}

OBJ namepass(l)
OBJ l;
{  extern OBJ lookup(),checklam(),checklet(),checkrule();
   switch(tag(l))
   {  case ONUMB:
      case OCHAR:
      case STRING:
      case DEF:
      case ORNUMB:
      case ORNAME:
      case OTRUE:
      case OFALSE:
      case OREMPTY:
      case OREAD:
      case OREADLN:
      case ORFAIL:
      case ORSTOP:
      case ORID:
      case ORCHARACTER:
      case ORAND:
      case ONIL:
               return l;
      case ONAME:
                 return lookup(l);
      case LAM:
               return checklam(l);
      case LET:
               return checklet(l);
      case RULE:
                return checkrule(l);
      case SELECT:
      case FIELD:
                 tl(l)=namepass(tl(l));
                 return l;
      case HD:
      case TL:
      case NOT:
      case NEG:
      case WRITE:
      case WRITELN:
      case FREAD:
      case SYSTEM:
      case EVAL:
      case EXPR:
      case CHAR:
      case TERMINALS:
               hd(l)=namepass(hd(l));
               return l;
      default:
               hd(l)=namepass(hd(l));
               tl(l)=namepass(tl(l));
               return l;
   }
}

checknames(l)
OBJ l;
{  if(tag(l)==ONAME)
   {  checkname(l);
      return;
   }
   while(tag(l)==LIST)
   {  checknames(hd(l));
      l=tl(l);
   }
   if(l!=NIL)
    checkname(l);
}

checkname(l)
OBJ l;
{  OBJ * i;
   i=sp;
   while((i-=2)>sb)
    if(name((*i))==name(l))
    {  nerror(2,name(l));
       return;
    }
   npush(l,NIL);
}

OBJ checklam(l)
OBJ l;
{  extern OBJ getfvs();

   entenv();
   checknames(hd(tl(l)));
   tl(tl(l))=namepass(tl(tl(l)));
   hd(l)=getfvs();
   lenv();
   if(hd(l)==NIL)
    tag(l)=ILAM;
   else
    putfvs(hd(l));
   return l;
}

OBJ checkrule(l)
OBJ l;
{  extern OBJ getfvs();

   entenv();
   tl(l)=namepass(tl(l));
   hd(l)=getfvs();
   lenv();
   if(hd(l)==NIL)
    tag(l)=IRULE;
   else
    putfvs(hd(l));
   return l;
}

OBJ checklet(l)
OBJ l;
{  extern OBJ getfvs();
   OBJ d;
   
   entenv();
   d=hd(tl(l));
   while(d!=NIL)
   {  checknames(hd(hd(d)));
      d=tl(d);
   }
   d=hd(tl(l));
   while(d!=NIL)
   {  tl(hd(d))=namepass(tl(hd(d)));
      d=tl(d);
   }
   tl(tl(l))=namepass(tl(tl(l)));
   hd(l)=getfvs();
   lenv();
   if(hd(l)==NIL)
    tag(l)=ILET;
   else
    putfvs(hd(l));
   return l;
}
   
OBJ lookup(n)
OBJ n;
{  extern OBJ lookfor();
   short level;
   OBJ ** r,* i,* j;
   level=0;
   i=sb;
   while(i<sp)
    if(name(n)==name((*i)))
     return new(NAME,n,newatom(ONUMB,(i-sb)/2));
    else
     i+=2;
   j=sb-2;
   r=rp-1;
   i=(*r);
   while(j>=stack)
   {  ++level;
      while(j>=i)
       if(name(n)==name((*j)))
       {  npush(n,new(LIST,NIL,newatom(ONUMB,(j-i)/2)));
          hd((*(sp-1)))=newatom(ONUMB,level);
          return new(NAME,n,newatom(ONUMB,(sp-sb-2)/2));
       }
       else
        j-=2;
      --r;
      i=(*r);
   }
   return lookfor(n);
}
      
OBJ getfvs()
{  OBJ * i;
   OBJ fvs;
   i=sp-1;
   fvs=NIL;
   while(i>=sb)
    if(*i==NIL)
     break;
    else
    {  tpush(fvs);
       fvs=new(LIST,new(LIST,*(i-1),*i),fvs);
       --tp;
       i-=2;
    }
/*   petrace(fvs,"getfvs"); */
   return fvs;
}
   
putfvs(l)
OBJ l;
{  while(l!=NIL)
   {  if(--value(hd(tl(hd(l)))))
      {  npush(hd(hd(l)),tl(hd(l)));
         tl(hd(l))=newatom(ONUMB,(sp-sb-2)/2);
      }
      else
       tl(hd(l))=tl(tl(hd(l)));
      l=tl(l);
   }
}
