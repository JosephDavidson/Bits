#include "defs.h"

extern short symb;
extern lex();

extern OBJ new(),newatom();
extern OBJ tpop();
extern tpush();
extern OBJ * tp;

extern short space;
extern int ch;
extern int getch();

extern OBJ let(),lam();

extern error();

extern short inlet;

extern OBJ lookfor();

extern struct node *objname;
extern long objval;

extern OBJ NIL,TRUEO,FALSEO,RNAME,RNUMB,RFAIL,
           RID,READ,READLN,RAND,REMPTY,RCHARACTER,
           RSTOP;

OBJ base()
{  extern OBJ expr(),readchar();
   OBJ b;

   switch(symb)
   {  case ONAME:b=newatom(ONAME,objname->pname);
                 if(!inlet)
                  b=lookfor(b);
                 lex();
                 break;
      case ONUMB:b=newatom(ONUMB,objval);
                 lex();
                 break;
      case TERMINALS:
      case CHAR:
      case HD:
      case TL:
              tpush(b=new(symb,NIL,NIL));
              lex();
              hd(b)=base();
              --tp;
              break;
      case '(':lex();
               if(symb==')')
               {  b=NIL;
                  lex();
                  break;
               }
               b=expr();
               if(symb!=')')
                error(1,")");
               else
                lex();
               break;
      case '\'':b=readchar();
                lex();
                if(symb!='\'')
                 error(1,"'");
                else
                 lex();
                break;
      case OREAD:b=READ;
                 lex();
                 break;
      case OREADLN:b=READLN;
                   lex();
                   break;
      case '?':lex();
               b=RAND;
               break;
      default:error(1,"name or number");
              b=NIL;
   }
   return b;
}

OBJ nindex()
{  OBJ i,n;
   tpush(i=new(SELECT,NIL,NIL));
   if(symb=='^')
   {  lex();
      switch(symb)
      {  case ORNAME:
                     hd(i)=RNAME;
                     lex();
                     break;
         case ORNUMB:
                     hd(i)=RNUMB;
                     lex();
                     break;
         case ORID:
                   hd(i)=RID;
                   lex();
                   break;
         case ORCHARACTER:
                          hd(i)=RCHARACTER;
                          lex();
                          break;
         case ONAME:
                    n=newatom(ONAME,objname->pname);
                    lex();
                    hd(i)=n;
                    break;
         default:
                 error(1,"name for field selector");
      }
   }
   if(symb=='@')
   {  lex();
      switch(symb)
      {  case ONAME:
         case ONUMB:
         case '(':
                  tl(i)=base();
                  break;
         default:
                 error(1,"name or number for nindex");
      }
   }
   return tpop();
}
            

OBJ nindexes()
{  OBJ i;
   i=base();
   while(symb=='^' || symb=='@')
   {  tpush(i=new(INDEX,i,NIL));
      tl(i)=nindex();
   --tp;
   }
   return i;
}

OBJ factor()
{  if(symb==SUB)
   {  lex();
      return new(NEG,base(),NIL);
   }
   return nindexes();
}

OBJ term()
{  OBJ t;
   t=factor();
   while(symb==MULT || symb==DIV || symb==MOD)
   {  tpush(t=new(symb,t,NIL));
      lex();
      tl(t)=factor();
   --tp;
   }
   return t;
}

OBJ nexp()
{  OBJ e;
   extern OBJ readstring(),rule(),field();
   switch(symb)
   {  case OTRUE:lex();return TRUEO;
      case OFALSE:lex();return FALSEO;
      case '"':return readstring();
      case '{':return rule();
      case '[':return field();
      case ORNUMB:lex();
                  return RNUMB;
      case ORNAME:lex();
                  return RNAME;
      case ORFAIL:lex();
                  return RFAIL;
      case ORSTOP:lex();
                  return RSTOP;
      case ORID:lex();
                return RID;
      case ORCHARACTER:lex();
                       return RCHARACTER;
   }
   e=term();
   while(symb==ADD || symb==SUB)
   {  tpush(e=new(symb,e,NIL));
      lex();
      tl(e)=term();
   --tp;
   }
   return e;
}  

OBJ list()
{  OBJ l,h;
   h=nexp();
   if(symb!=':')
    return h;
   tpush(l=new(LIST,h,NIL));
   while(1)
   {  lex();
      if(space || (symb!=ONAME && symb!=ONUMB && symb!='\'' && symb!=OTRUE &&
                   symb!=ORNAME && symb!=ORNUMB && symb!='[' && symb!=OREAD &&
                   symb!=OREADLN && symb!=ORFAIL && symb!=ORID &&
                   symb!=ORSTOP && 
                   symb!=ORCHARACTER && symb!='?' &&
                   symb!=OFALSE && symb!='"' && symb!='{' && symb!='('))
       break;
      h=nexp();
      if(symb!=':')
      {  tl(l)=h;
          break;
      }
      tl(l)=new(LIST,h,NIL);
      l=tl(l);
   }
   return tpop();
}

OBJ logbase()
{  OBJ lb;
   switch(symb)
   {  case ISNUMB:
      case ISCHAR:
      case ISBOOL:
      case ISLIST:
      case ISFUNC:
      case ISRULE:
      case ISSTRING:
      case ISFIELD:
                    lb=new(symb,NIL,NIL);
                    lex();
                    hd(lb)=nexp();
                    return lb;
   }
   lb=list();
   switch(symb)
   {  case EQ:case NEQ:
      case GE:case GT:
      case LE:case LT:tpush(lb=new(symb,lb,NIL));
                      lex();
                      tl(lb)=list();
                   --tp;
   }
   return lb;
}

OBJ logfactor()
{  if(symb!=NOT)
    return logbase();
   lex();
   return new(NOT,logbase(),NIL);
}

OBJ logterm()
{  OBJ lt;
   lt=logfactor();
   while(symb==LAND)
   {  lex();
      tpush(lt=new(LAND,lt,NIL));
      tl(lt)=logfactor();
   --tp;
   }
   return lt;
}

OBJ logexp()
{  OBJ le;
   if(symb==LAM)
    return lam();
   le=logterm();
   while(symb==LOR)
   {  lex();
      tpush(le=new(LOR,le,NIL));
      tl(le)=logterm();
   --tp;
   }
   return le;
}

OBJ bpexp()
{  OBJ bp;
   bp=logexp();
   while(symb=='(' || symb==ONAME || symb=='\'' || symb==ONUMB || symb==LAM||
         symb=='{' || symb=='\'' || symb==ORNAME || symb==ORNUMB ||
         symb=='[' || symb=='"' || symb==SUB || symb==NOT || symb==OREAD ||
         symb==ORSTOP || 
         symb==OREADLN || symb==ISNUMB || symb==ISCHAR ||
         symb==ISBOOL || symb==ISLIST ||
         symb==ISSTRING || symb==ISRULE || symb==ISFUNC || symb==ISFIELD ||
         symb==ORFAIL || symb==ORID || symb==ORCHARACTER || symb=='?' ||
         symb==OTRUE || symb==OFALSE || symb==HD || symb==TL)
   {  tpush(bp=new(BP,bp,NIL));
      tl(bp)=logexp();
   --tp;
   }
   return bp;
}

OBJ ifexp()
{  extern OBJ expr();
   OBJ c;
   lex();
   tpush(c=new(IF,expr(),NIL));
   if(symb!=THEN)
    error(1,"then");
   else
    lex();
   tl(c)=new(LIST,expr(),NIL);
   if(symb!=ELSE)
    error(1,"else");
   else
    lex();
   tl(tl(c))=expr();
   return tpop();
}

OBJ caseexp(t)
short t;
{  extern OBJ cases(),expr();
   OBJ c;
   lex();
   tpush(c=new(t,expr(),NIL));
   if(symb!=OF)
    error("of");
   else
    lex();
   tl(c)=cases();
   return tpop();
}

OBJ cases()
{  OBJ c,d;
   extern OBJ expr();
   d=expr();
   if(symb!=COND)
    return d;
   tpush(c=new(OF,new(LIST,d,NIL),NIL));
   while(1)
   {  lex();
      tl(hd(c))=expr();
      if(symb!=',')
       error(1,",");
      else
       lex();
      d=expr();
      if(symb!=COND)
      {  tl(c)=d;
         break;
      }
      tl(c)=new(OF,new(LIST,d,NIL),NIL);
      c=tl(c);
   }
   return tpop();
}
      

OBJ condexp()
{  short s;
   OBJ fw;
   switch(symb)
   {  case IF:return ifexp();
      case CASE:return caseexp(CASE);
      case RULECASE:return caseexp(RULECASE);
      case LET:return let();
      case WRITE:
      case WRITELN:
      case FREAD:
      case SYSTEM:
      case EVAL:
      case EXIT:
      case SIZE:
                 s=symb;
                 lex();
                 return new(s,nexp(),NIL);
      case FWRITE:
                  lex();
                  tpush(fw=new(FWRITE,nexp(),NIL));
                  tl(fw)=nexp();
                  return tpop();
   }
   return bpexp();
}

OBJ expr()
{  return condexp();  }

OBJ readchar()
{  OBJ c;
   if(ch=='\\')
   {  ch=getch();
      if(ch=='n')
       ch='\n';
   }
   c=newatom(OCHAR,ch);
   ch=getch();
   return c;
}

OBJ readstring()
{  OBJ s;
   if(ch=='"')
   {  ch=getch();
      lex();
      return NIL;
   }
   tpush(s=new(STRING,readchar(),NIL));
   while(ch!='"' && ch!=';')
   {  tl(s)=new(STRING,readchar(),NIL);
      s=tl(s);
   }
   if(ch!='"')
    error(1,"\"");
   else
    ch=getch();
   lex();
   return tpop();
}

OBJ rule()
{  OBJ r;
   extern OBJ ruleopts();

   lex();
   if(symb=='}')
   {  lex();
      return REMPTY;
   }
   ++inlet;
   r=new(RULE,NIL,ruleopts());
   if(symb!='}')
    error(1,"}");
   else
    lex();
   return r;
}

OBJ ruleopts()
{  OBJ ro;
   extern OBJ rulebody();
   tpush(ro=new(LIST,rulebody(),NIL));
   while(symb==LOR)
   {  lex();
      tl(ro)=new(LIST,rulebody(),NIL);
      ro=tl(ro);
   }
   return tpop();
}

OBJ rulebody()
{  OBJ r;
   extern OBJ ruleterm();

   tpush(r=new(LIST,ruleterm(),NIL));
   while(symb=='(' || symb==ONAME || symb=='"' || symb=='{' ||
         symb==ORNAME || symb==ORNUMB || symb==ORFAIL || symb==ORSTOP ||
         symb==ORID || symb==ORCHARACTER)
   {  tl(r)=new(LIST,ruleterm(),NIL);
      r=tl(r);
   }
   return tpop();
}

OBJ ruleterm()
{  switch(symb)
   {  case ONAME:return base();
      case '"':return  nexp();
      case '{':return rule();
      case '(':return new(EXPR,base(),NIL);
      case ORNAME:lex();return RNAME;
      case ORNUMB:lex();return RNUMB;
      case ORFAIL:lex();return RFAIL;
      case ORSTOP:lex();return RSTOP;
      case ORID:lex();return RID;
      case ORCHARACTER:lex();return RCHARACTER;
   }
}

OBJ field()
{  OBJ n;
   lex();
   switch(symb)
   {  case ONAME:n=newatom(ONAME,objname->pname);
                 lex();
                 break;
      case ORNUMB:n=RNUMB;
                  lex();
                  break;
      case ORNAME:n=RNAME;
                  lex();
                  break;
      case ORID:n=RID;
                lex();
                break;
      case ORCHARACTER:n=RCHARACTER;
                       lex();
                       break;
      default:error(1,"name");
              n=NIL;
   }
   tpush(n=new(FIELD,n,NIL));
   tl(n)=expr();
   if(symb!=']')
    error(1,"]");
   else
    lex();
   return tpop();
}

