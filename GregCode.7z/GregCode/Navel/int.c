#include "defs.h"

extern OBJ * sb,* sp;
extern push();
extern OBJ pop();
extern tpush();

extern OBJ new(),newatom();
extern OBJ NIL,TRUEO,FALSEO,REMPTY;

extern rerror();

extern int getch();
extern pexp(),nl(),putch();

extern short trace,lazy;

extern OBJ ieval();
extern OBJ isystem();
extern OBJ ifread();
extern OBJ iifread();
extern OBJ ifwrite();

extern OBJ iterminals();

short tracedepth;
OBJ lasttraced;

#define isnumeric(l) (tag(l)==ONUMB || tag(l)==OCHAR)
#define isbool(l) (l==TRUEO || l==FALSEO)
#define islist(l) (tag(l)==ILIST)

inittrace()
{  tracedepth=0;
   lasttraced=NIL;
}

tracein(l)
OBJ l;
{  short i;
   if(eq(l,lasttraced))
    return;
   lasttraced=l;
   i=0;
   printf("%3d",tracedepth);
   while(i<tracedepth)
   {  putch('-');
      ++i;
   }
   printf("-> ");
   pexp(l);
   nl();
}

OBJ iexp(l)
OBJ l;
{  OBJ newl;
   extern OBJ intexp();
   if(!trace)
    return intexp(l);
   ++tracedepth;
   tracein(l);
   newl=intexp(l);
   if(tag(l)!=DEF)
    tracein(newl);
   --tracedepth;
   return newl;
}

OBJ intexp(l)
register OBJ l;
{  register OBJ o;
   extern OBJ ibinop();
   extern OBJ ilist();
   extern OBJ iselect();
   extern OBJ nibp();
   extern OBJ ilam();
   extern OBJ ilet();
   extern OBJ nirand();
   extern OBJ evallet();
   extern OBJ iindex();
   extern OBJ isusp();
   extern OBJ irulecase();
   extern OBJ iwrite();
   extern OBJ iwriteln();
   extern OBJ ireadln();
   extern OBJ irule();
   extern OBJ ifield();
   extern OBJ objsize();

loop:

   switch(tag(l))
   {  case ONIL:
      case ONUMB:
      case OCHAR:
      case STRING:
      case OTRUE:
      case OFALSE:
      case ILIST:
      case ILAM:
      case IRULE:
      case IFIELD:
      case ORNUMB:
      case ORNAME:
      case OREMPTY:
      case ORFAIL:
      case ORSTOP:
      case ORID:
      case ORCHARACTER:
                 return l;
      case DEF:
               return isusp(l);
      case NAME:
                return sb[value(tl(l))]; /* isusp for normal order */
      case LAM:
               return ilam(l);
      case RULE:
                return irule(l);
      case FIELD:
                 return ifield(l);
      case LET:
               return evallet(ilet(l));
      case ILET:
                return evallet(l);
      case BP:
      case IBP:
               return nibp(l);
      case LIST:
                return ilist(l,lazy);
      case HD:
      case TL:
              return iselect(l);
      case INDEX:
                 return iindex(l);
      case RULECASE:
                    return irulecase(l);
      case IF:
              o=iexp(hd(l));
              if(!isbool(o))
               rerror(1,hd(l),o,"boolean");
              l=o==TRUEO?hd(tl(l)):tl(tl(l));
              goto loop;
      case CASE:
                push(o=iexp(hd(l)));
                l=tl(l);
                while(tag(l)==OF)
                 if(!eq(iexp(hd(hd(l))),o))
                  l=tl(l);
                 else
                 {  l=tl(hd(l));
                    break;
                 }
                 --sp;
                 goto loop;
      case NEG:
               o=iexp(hd(l));
               if(!isnumeric(o))
                rerror(1,hd(l),o,"number");
               return newatom(ONUMB,-value(o));
      case CHAR:
                o=iexp(hd(l));
                if(!isnumeric(o))
                 rerror(1,hd(l),o,"number");
                return newatom(OCHAR,(int)value(o));
      case TERMINALS:
                     o=iexp(hd(l));
                     if(tag(o)!=IRULE)
                      rerror(1,hd(l),o,"rule");
                     return iterminals(o);
      case NOT:
               o=iexp(hd(l));
               if(!isbool(o))
                rerror(1,hd(l),o,"boolean");
               return o==TRUEO?FALSEO:TRUEO;
      case OREADLN:
                return ireadln();
      case OREAD:
                 return newatom(OCHAR,getch());
      case WRITE:
                 return iwrite(hd(l));
      case WRITELN:
                   return iwriteln(hd(l));
      case SIZE:
                return objsize(iexp(hd(l)));
      case FREAD:
                 return ifread(l);
      case IFREAD:
                  return iifread(l);
      case FWRITE:
                  return ifwrite(l);
      case SYSTEM:
                  return isystem(l);
      case EVAL:
                return ieval(l);
      case ORAND:
                 return nirand();
      case ISNUMB:
                  return tag(iexp(hd(l)))==ONUMB?TRUEO:FALSEO;
      case ISCHAR:
                  return tag(iexp(hd(l)))==OCHAR?TRUEO:FALSEO;
      case ISBOOL:
                  return (o=iexp(hd(l)))==TRUEO?TRUEO:
                         o==FALSEO?TRUEO:FALSEO;
      case ISLIST:
                  return tag(o=iexp(hd(l)))==ILIST?TRUEO:
                         tag(o)==STRING?TRUEO:FALSEO;
      case ISRULE:
                  o=iexp(hd(l));
                  return tag(o)==IRULE ||
                         tag(o)==ORID ||
                         tag(o)==ORCHARACTER ||
                         tag(o)==ORNAME ||
                         tag(o)==ORNUMB ?TRUEO:FALSEO;
      case ISFUNC:
                  return tag(iexp(hd(l)))==ILAM?TRUEO:FALSEO;
      case ISFIELD:
                  return tag(iexp(hd(l)))==IFIELD?TRUEO:FALSEO;
      case ISSTRING:
                    return tag(iexp(hd(l)))==STRING?TRUEO:FALSEO;
      case EXIT:
                rerror(6,iexp(hd(l)));
      default:
              return ibinop(l);
   }
}

OBJ ibinop(l)
register OBJ l;
{  register OBJ o1,o2;
   extern OBJ ordered();
   push(o1=iexp(hd(l)));
   o2=iexp(tl(l));
   --sp;
   switch(tag(l))
   {  case LAND:
      case LOR:
              if(!isbool(o1))
               rerror(1,hd(l),o1,"boolean");
              if(!isbool(o2))
               rerror(1,tl(l),o2,"boolean");
              switch(tag(l))
              {  case LAND:return o1==TRUEO && o2==TRUEO?TRUEO:FALSEO;
                 case LOR:return o1==TRUEO || o2==TRUEO?TRUEO:FALSEO;
              }
      case EQ:return eq(o1,o2)?TRUEO:FALSEO;
      case NEQ:return eq(o1,o2)?FALSEO:TRUEO;
      case LE:
      case LT:
      case GE:
      case GT: return ordered(tag(l),o1,o2);
      default:
              if(!isnumeric(o1))
               rerror(1,hd(l),o1,"number");
              if(!isnumeric(o2))
               rerror(1,tl(l),o2,"number");
              switch(tag(l))
              {  case ADD:return newatom(ONUMB,value(o1)+value(o2));
                 case SUB:return newatom(ONUMB,value(o1)-value(o2));
                 case MULT:return newatom(ONUMB,value(o1)*value(o2));
                 case DIV:if(value(o2)==0)
                           rerror(2,l);
                          return newatom(ONUMB,value(o1)/value(o2));
                 case MOD:if(value(o2)==0)
                           rerror(2,l);
                          return newatom(ONUMB,value(o1)%value(o2));
              }
   }  
}

eq(v1,v2)
register OBJ v1,v2;
{  while(1)
   {  if(v1==v2)
       return 1;
      if(v1==NIL || v2==NIL)
       return 0;
      if(tag(v1)!=tag(v2))
       return 0;
      if(tag(v1)==OCHAR || tag(v1)==ONUMB || tag(v1)==ONAME)
       return value(v1)==value(v2);
      if(!eq(hd(v1),hd(v2)))
       return 0;
      v1=tl(v1);
      v2=tl(v2);
   }
}

OBJ ordered(op,o1,o2)
short op;
OBJ o1,o2;
{  if(isnumeric(o1) && isnumeric(o2)) /* change to include OCHAR */
    switch(op)
    {  case GT: return value(o1)>value(o2)?TRUEO:FALSEO;
       case GE: return value(o1)>=value(o2)?TRUEO:FALSEO;
       case LE: return value(o1)<=value(o2)?TRUEO:FALSEO;
       case LT: return value(o1)<value(o2)?TRUEO:FALSEO;
    }
    if(tag(o1)!=STRING || tag(o2)!=STRING)
     rerror(7,o1,o2,"\n");
    while(o1!=NIL && o2!=NIL)
     if(value(hd(o1))==value(hd(o2)))
     {  o1=tl(o1);
        o2=tl(o2);
     }
     else
      break;
   switch(op)
   {  case GE: if(o1==NIL && o2==NIL)
                return TRUEO;
      case GT: if(o1==NIL)
                 return FALSEO;
               if(o2==NIL)
                return TRUEO;
               return value(hd(o1))>value(hd(o2))?TRUEO:FALSEO;
      case LE: if(o1==NIL && o2==NIL)
                return TRUEO;
      case LT: if(o2==NIL)
                 return FALSEO;
               if(o1==NIL)
                return TRUEO;
               return value(hd(o1))<value(hd(o2))?TRUEO:FALSEO;
   }
}
               

OBJ ilist(l,lazy)
OBJ l;
short lazy;
{  register OBJ newl;
   extern OBJ ilazy();

   push(newl=new(ILIST,NIL,NIL));
   if(lazy)
   {  hd(newl)=ilazy(hd(l));
      tl(newl)=ilazy(tl(l));
   }
   else
   {  hd(newl)=iexp(hd(l));
      tl(newl)=iexp(tl(l));
   }
   --sp;
   if(tag(hd(newl))==OCHAR)
    if(tl(newl)==NIL)
     tag(newl)=STRING;
    else
    if(tag(tl(newl))==STRING)
     tag(newl)=STRING;
   return newl;
}

OBJ ilazy(l)
OBJ l;
{  OBJ newl;
   extern OBJ intlazy();
   if(!trace)
    return intlazy(l);
   ++tracedepth;
   tracein(l);
   newl=intlazy(l);
   if(tag(l)!=DEF)
    tracein(newl);
   --tracedepth;
   return newl;
}

OBJ intlazy(l)
register OBJ l;
{  register OBJ b;
   extern OBJ ilet();
   while(1)
    switch(tag(l))
    {  case ONIL:
       case ONUMB:
       case OCHAR:
       case STRING:
       case ILIST:
       case ILAM:
       case IRULE:
       case IBP:
       case DEF:
       case ORNAME:
       case ORNUMB:
       case ORFAIL:
       case ORSTOP:
       case ORID:
       case ORCHARACTER:
       case OREMPTY:
       case IFIELD:
       case OTRUE:
       case OFALSE:
       case ILET:
       case ORAND:
       case IFREAD:
                   return l;
       case IF:
               b=iexp(hd(l));
               if(b==TRUEO)
                l=hd(tl(l));
               else
               if(b==FALSEO)
                l=tl(tl(l));
               else
                rerror(1,hd(l),b,"boolean");
               break;
       case BP:
               push(b=new(IBP,ilazy(hd(l)),NIL));
               tl(b)=ilazy(tl(l));
               return pop();
       case LET:
                return ilet(l);
       case CASE:
                push(b=iexp(hd(l)));
                l=tl(l);
                while(tag(l)==OF)
                 if(!eq(iexp(hd(hd(l))),b))
                  l=tl(l);
                 else
                 {  l=tl(hd(l));
                    break;
                 }
                 --sp;
                 break;
/* ADD RULECASE? */
       default:
               return iexp(l);
    }
}

OBJ iselect(l)
OBJ l;
{  OBJ newl;
   extern OBJ isusp();

   newl=iexp(hd(l));
   if(!islist(newl) && tag(newl)!=STRING)
    rerror(1,hd(l),newl,"list");
   push(newl);
   if(tag(l)==HD)
   {  --sp;
      return lazy?hd(newl)=isusp(hd(newl)):hd(newl);
   }
   --sp;
   return lazy?tl(newl)=isusp(tl(newl)):tl(newl);
}

OBJ iindex(l)
register OBJ l;
{  register OBJ o,v,n;
   register short i;
   extern OBJ isusp();

   push(o=iexp(hd(l)));
   v=iexp(tl(tl(l)));
   if(hd(tl(l))==NIL)
   {  if(tag(o)!=STRING && tag(o)!=ILIST)
       rerror(1,hd(l),o,"list");
      if(!isnumeric(v))
       rerror(1,tl(tl(l)),v,"number for list indexing");
      i=value(v)-1;
      if(i<0)
       rerror(1,tl(tl(l)),v,"positive number for list indexing");
      while(i)
      {  o=lazy?(tl(o)=isusp(tl(o))):tl(o);
         if(tag(o)!=STRING && tag(o)!=ILIST)
          rerror(1,o,o,"list");
         --i;
      }
      if(lazy)
       hd(o)=isusp(hd(o));
      --sp;
      return hd(o);
   }
   n=hd(tl(l));
   if(v==NIL)
    i=1;
   else
   if(!isnumeric(v))
    rerror(1,tl(tl(l)),v,"number for field selection");
   else
    i=value(v);
   if(i<=0)
    rerror(1,tl(tl(l)),v,"positive number for field selection");
   if(tag(o)==IFIELD)
   {  if(name(hd(o))==name(n))
       if(i==1)
       {  --sp;
          return tl(o);
       }
      rerror(4,o,tl(l));
   }
   while(tag(o)==ILIST)
   {  if(lazy)
       hd(o)=isusp(hd(o));
      if(tag(hd(o))==IFIELD)
       if(name(hd(hd(o)))==name(n))
        if(i==1)
        {  --sp;
           return tl(hd(o));
        }
        else
        if((--i)==0)
         break;
      o=lazy?(tl(o)=isusp(tl(o))):tl(o);
   }
   if(tag(o)==IFIELD)
    if(name(hd(o))==name(n))
     if(i==1)
     {  --sp;
        return tl(o);
     }
   rerror(4,pop(),tl(l));
}

OBJ isusp(l)
OBJ l;
{  extern OBJ evallet();
   extern OBJ nibp();
   extern OBJ nirand();
   switch(tag(l))
   {  case IBP:return nibp(l);
      case DEF:return tl(l)=isusp(tl(l));
      case ILET:return evallet(l);
      case ORAND:return nirand();
      case IFREAD:return iifread(l);
      default:return l;
   }
}

OBJ ifield(l)
OBJ l;
{  return new(IFIELD,hd(l),iexp(tl(l)));  }

OBJ irule(r)
OBJ r;
{  extern OBJ freezefvs();

   return new(IRULE,freezefvs(hd(r)),tl(r));
}

OBJ irulecase(l)
register OBJ l;
{  register OBJ r,c,m;
   extern short rmatch();

   push(r=iexp(hd(l)));
   if(tag(r)!=ILIST && r!=NIL && tag(r)!=IFIELD && tag(r)!=STRING)
    rerror(1,hd(l),r,"parse tree for rule matching");
   c=tl(l);
   while(tag(c)==OF)
   {  m=iexp(hd(hd(c)));
      if(tag(m)!=IRULE)
       rerror(1,hd(hd(c)),m,"rule for rule matching");
      if(tl(tl(m))!=NIL)
       rerror(1,hd(hd(c)),m,"optionless rule for rule matching");
      if(rmatch(r,hd(tl(m))))
      {  --sp;
         return iexp(tl(hd(c)));
      }
      c=tl(c);
   }
   --sp;
   return iexp(c);
}

short rmatch(tree,rule)
register OBJ tree,rule;
{  extern short matchone();
   while(hd(rule)==REMPTY)
    rule=tl(rule);
   while(rule!=NIL)
   {  if(tree==NIL)
       return 0;
      if(!islist(tree))
      {  if(!matchone(tree,hd(rule)))
          return 0;
         rule=tl(rule);
         while(hd(rule)==REMPTY)
          rule=tl(rule);
         return rule==NIL;
      }
      if(lazy)
       hd(tree)=isusp(hd(tree));
      if(!matchone(hd(tree),hd(rule)))
       return 0;
      tree=lazy?(tl(tree)=isusp(tl(tree))):tl(tree);
      rule=tl(rule);
      while(hd(rule)==REMPTY)
       rule=tl(rule);
   }
   return 0;
}

short matchone(tree,rule)
register OBJ tree,rule;
{  if(tag(tree)==STRING && tag(rule)==STRING)
    return eq(tree,rule);
   else
   if(tag(tree)!=IFIELD)
    return 0;
   else
   switch(tag(rule))
   {  case DEF:
      case NAME:if(tag(hd(tree))==ONAME)
                 if(name(hd(tree))==name(hd(rule)))
                  return 1;
                return 0;
      case ORID:
      case ORCHARACTER:
      case ORNAME:
      case ORNUMB:if(hd(tree)==rule)
                   return 1;
      default:return 0;
   }
}


OBJ ireadln()
{  OBJ l;
   int ch;
   ch=getch();
   if(ch=='\n')
    return NIL;
   push(l=new(STRING,newatom(OCHAR,ch),NIL));
   while((ch=getch())!='\n')
   {  tl(l)=new(STRING,newatom(OCHAR,ch),NIL);
      l=tl(l);
   }
   return pop();
}

OBJ ifreadrest(l)
OBJ l;
{  FILE * fp;
   int ch;
   fp=(FILE *)value(tl(l));
   ch=getc(fp);
   if(ch==EOF)
   {  fclose(fp);
      return NIL;
   }
   push(l=new(STRING,newatom(OCHAR,ch),NIL));
   putch(ch);
   while((ch=getc(fp))!=EOF)
   {  tl(l)=new(STRING,newatom(OCHAR,ch),NIL);
      l=tl(l);
      putch(ch);
   }
   fclose(fp);
   return pop();
}
   
noquotes(l)
OBJ l;
{  while(l!=NIL)
   {  putch((int)value(hd(l)));
      if(tl(l)!=NIL)
       if(tag(tl(l))==IFREAD)
       {  tl(l)=ifreadrest(tl(l));
          break;
       }
      l=tl(l);
   }
}  

OBJ iwrite(l)
OBJ l;
{  l=iexp(l);
   if(tag(l)==OCHAR)
    putch(value(l));
   else
   if(tag(l)==STRING)
    noquotes(l);
   else
   if(tag(l)==ILIST)
   { l=ilist(l,0);
     if(tag(l)==STRING)
      noquotes(l);
     else
      pexp(l);
   }
   else
    pexp(l);
   return l;
}

OBJ iwriteln(l)
OBJ l;
{  l=iwrite(l);
   putch('\n');
   return l;
}

igetsize(l)
OBJ l;
{  int count;
   count=0;
   loop:
   switch(tag(l))
   {  case ONIL:
      case DEF:
      case ORAND:
      case ORNUMB:
      case ORNAME:
      case OREMPTY:
      case ORFAIL:
      case ORSTOP:
      case ORCHARACTER:
      case ORID: return count;
      case OREADLN:
      case OREAD:
      case ONAME:
      case ONUMB:
      case OCHAR:
      case OTRUE:
      case OFALSE: return 1+count;
      case NAME: return 2+count;
      case ISNUMB:
      case ISCHAR:
      case ISBOOL:
      case ISLIST:
      case ISRULE:
      case ISFUNC:
      case ISFIELD:
      case ISSTRING:
      case EXIT:
      case SYSTEM:
      case EVAL:
      case NEG:
      case CHAR:
      case TERMINALS:
      case NOT:
      case WRITE:
      case WRITELN:
      case SIZE:
      case FREAD:
      case HD:
      case TL: count++;
               l=hd(l);
               goto loop;
      case LAM:
      case RULE:
      case FIELD:
      case LET: count++;
                l=tl(l);
                goto loop;
      case STRING: count=count+2;
                   l=tl(l);
                   goto loop;
      default: count=count+1+igetsize(hd(l));
               l=tl(l);
               goto loop;
   }
}

OBJ objsize(l)
OBJ l;
{  return newatom(ONUMB,igetsize(l));  }
