#include "defs.h"

extern reset(),skippast();
extern short symb;
extern int getch();
extern putch(),nl(),fprint();
extern eq();
extern short trace,tracedepth;
extern tpush();
extern OBJ * tp;

extern OBJ NIL;

short errors;

short indentdepth;

extern short saving;

initprint()
{  indentdepth=0;
}

indentnl()
{  short i,l;
   nl();
   i=0;
   l=trace?indentdepth+tracedepth+3:indentdepth;
   while(i<l)
   {  putch(' ');
      ++i;
   }
}

pindent(s)
char *s;
{  indentnl();
   fprint("%s",s);
}

indent()
{  ++indentdepth;
}

outdent()
{  --indentdepth;
}

nerror(n,m)
short n;
char * m;
{  fprint("%s ",m);
   switch(n)
   {  case 1:fprint("NOT DEFINED");break;
      case 2:fprint("DECLARED ALREADY");break;
   }
   nl();
   ++errors;
}

serror(n)
short n;
{  char *s;
   switch(n)
   {  case 1:s="TOO MANY NAMES";
             break;
      case 2:s="NO MORE NAME SPACE";
             break;
      case 3:s="NO MORE CELL SPACE";
             break;
      case 4:s="TEMPORARY STACK OVERFLOW";
             break;
      case 5:s="TEMPORARY STACK UNDERFLOW";
             break;
      case 6:s="STACK OVERFLOW";
             break;
      case 7:s="STACK UNDERFLOW";
             break;
      case 8:s="RETURN LINK STACK OVERFLOW";
             break;
      case 9:s="RETURN LINK STACK UNDERFLOW";
             break;
      case 10:s="NON-TERMINAL STACK OVERFLOW";
              break;
      case 11:s="NON-TERMINAL STACK UNDERFLOW";
              break;
   }
   printf("\nSYSTEM ERROR - %s\n",s);
   if(symb!=';')
    skippast(';');
   reset();
}

rerror(n,old,new,m)
short n;
OBJ old,new;
char *m;
{  short t;
   t=trace;
   trace=0;
   nl();
   switch(n)
   {  case 1:
             pexp(old);
             if(!eq(old,new))
             {  printf("\n=\n");
                pexp(new);
             }
             nl();
             printf("doesn't return a %s",m);
             break;
      case 2:
             printf("divide by 0 in\n");
             pexp(old);
             break;
      case 3:
             pexp(old);
             printf("\ndoesn't match\n");
             pexp(new);
             break;
      case 4:
             pexp(old);
             printf("\n doesn't have a\n");
             pexp(new);
             break;
      case 5:printf("can't open ");
             pexp(old);
             printf(" to %s",m);
             break;
      case 6:printf("exit ");
             pexp(old);
             break;
      case 7:printf("type mismatch in comparison between\n");
             pexp(old);
             printf("\nand\n");
             pexp(new);
             break;
   }
   nl();nl();
   trace=t;
   reset();
}

error(n,m)
short n;
char *m;
{  nl();
   switch(n)
   {  case 1:printf("%s EXPECTED",m);break;
      case 2:printf("NO FILE");break;
      case 3:printf("CAN'T OPEN %s",m);break;
      case 4:printf("NO COMMAND");break;
   }
   nl();
   ++errors;
}

pexp(l)
OBJ l;
{  extern plexp(),prexp(),psymb();
   switch((UNMARK&tag(l)))
   {  case ONIL:fprint("()");return;
      case ONAME:
      case OTRUE:
      case OFALSE:
      case ORNUMB:
      case ORNAME:
      case OREAD:
      case OREADLN:
      case ORFAIL:
      case ORCHARACTER:
      case ORSTOP:
      case ORID:fprint("%s",name(l));return;
      case DEF:
      case NAME:fprint("%s",name(hd(l)));return;
      case ONUMB:fprint("%ld",value(l));return;
      case STRING:putch('"');
                  while(l!=NIL)
                  {  sputchar(hd(l),0);
                     l=tl(l);
                     if(l!=NIL)
                      if(tag(l)==IFREAD)
                      {  fprint("\" #rest of file ");
                         pexp(hd(l));
                         putch('#');
                         return;
                      }
                  }
                  putch('"');
                  return;
      case LIST:
      case ILIST:
                 plist(l);
                 return;
      case OCHAR:putch('\'');
                 sputchar(l,1);
                 putch('\'');
                 return;
      case ORAND:putch('?');return;
      case OREMPTY:fprint("{}");return;
      case LAM:
                plam(l);
                return;
      case LET:
                plet(l);
                return;
      case IRULE:
      case ILAM:
      case ILET:
                pclosure(l,tp);
                return;
      case BP:
      case IBP:
               pbp(l);
               return;
      case IF:indent();
              pindent("if ");
              pexp(hd(l));
              pindent("then ");
              pexp(hd(tl(l)));
              pindent("else ");
              pexp(tl(tl(l)));
              outdent();
              return;
      case RULECASE:
      case CASE:indent();
                pindent((UNMARK&tag(l))==CASE?"case ":"rule ");
                pexp(hd(l));
                fprint(" of");
                if(trace && !saving)
                {  fprint(" ...");
                   outdent();
                   return;
                }
                l=tl(l);
                while((UNMARK&tag(l))==OF)
                {  indentnl();
                   pexp(hd(hd(l)));
                   fprint("->");
                   pexp(tl(hd(l)));
                   putch(',');
                   l=tl(l);
                }
                indentnl();
                pexp(l);
                outdent();
                return;
      case RULE:
                 prule(l);
                 return;
      case EXPR:
                putch('(');
                pexp(hd(l));
                putch(')');
                return;
      case FIELD:
      case IFIELD:
                  putch('[');
                  pexp(hd(l));
                  putch(' ');
                  pexp(tl(l));
                  putch(']');
                  return;
      case INDEX:
                 pindex(l);
                 return;
      case SELECT:
                  ppselect(l);
                  return;
      case NEG:
      case NOT:
      case HD:
      case TL:
      case ISNUMB:
      case ISBOOL:
      case ISCHAR:
      case ISFUNC:
      case ISRULE:
      case ISLIST:
      case ISSTRING:
      case ISFIELD:
      case CHAR:
      case TERMINALS:
      case WRITE:
      case WRITELN:
      case FREAD:
      case SYSTEM:
      case EVAL:
      case EXIT:
      case SIZE:
              psymb((UNMARK&tag(l)));
              prexp((UNMARK&tag(l)),hd(l));
              return;
      case FWRITE:fprint("fwrite ");
                  plistelem(hd(l));
                  putch(' ');
                  prexp(WRITE,tl(l));
                  return;
      default:plexp((UNMARK&tag(l)),hd(l));
              psymb((UNMARK&tag(l)));
              prexp((UNMARK&tag(l)),tl(l));
              return;
   }
}

psymb(s)
short s;
{  char *ss;
   switch(s)
   {  case ADD:ss="+";break;
      case SUB:ss="-";break;
      case MULT:ss="*";break;
      case DIV:ss="/";break;
      case MOD:ss="%";break;
      case EQ:ss="=";break;
      case NEQ:ss="<>";break;
      case LT:ss="<";break;
      case LE:ss="<=";break;
      case GT:ss=">";break;
      case GE:ss=">=";break;
      case LAND:ss=" & ";break;
      case LOR:ss=" | ";break;
      case NEG:ss="-";break;
      case NOT:ss="not ";break;
      case HD:ss="hd ";break;
      case TL:ss="tl ";break;
      case ISNUMB:ss="isnumb ";break;
      case ISBOOL:ss="isbool ";break;
      case ISLIST:ss="islist ";break;
      case ISRULE:ss="isrule ";break;
      case ISFUNC:ss="isfunc ";break;
      case ISSTRING:ss="isstring ";break;
      case ISCHAR:ss="ischar ";break;
      case ISFIELD:ss="isfield ";break;
      case WRITE:ss="write ";break;
      case WRITELN:ss="writeln ";break;
      case FREAD:ss="fread ";break;
      case SYSTEM:ss="system ";break;
      case EVAL:ss="eval ";break;
      case CHAR:ss="char ";break;
      case TERMINALS:ss="terminals ";break;
      case EXIT:ss="exit ";break;
      case SIZE:ss="osize ";break;
      default:ss="";break;
   }
   fprint("%s",ss);
}

plexp(s,l)
short s;
OBJ l;
{  short bra,lt;
   lt=(UNMARK&tag(l));
   switch(lt)
   {  case ONIL:
      case ONUMB:
      case ONAME:
      case OTRUE:
      case OFALSE:
      case ORNAME:
      case ORNUMB:
      case OREMPTY:
      case OCHAR:
      case STRING:
      case ILIST:
      case LIST:
      case RULE:
      case IRULE:
      case FIELD:
      case IFIELD:
      case OREAD:
      case OREADLN:
      case ORFAIL:
      case ORSTOP:
      case ORID:
      case ORCHARACTER:
      case ORAND:
      case NAME:
      case DEF:bra=0;
               break;
      default:
              switch(s)
              {  case ADD:
                 case SUB:
                          bra=lt!=ADD && lt!=SUB && lt!=NEG && lt!=MULT &&
                              lt!=DIV && lt!=MOD;
                              break;
                 case MULT:
                 case DIV:
                 case MOD:bra=lt!=MULT && lt!=DIV && lt!=MOD && lt!=NEG;
                          break;
                 case INDEX:bra=lt!=INDEX;
                            break;
                 case EQ:case NEQ:
                 case LT:case LE:
                 case GT:case GE:
                                 bra=lt!=ADD && lt!=SUB && lt!=MULT &&
                                     lt!=MOD && lt!=INDEX &&
                                     lt!=DIV && lt!=NEG && lt!=HD &&
                                     lt!=TL && lt!=CHAR && lt!=TERMINALS;
                                 break;
                 case LAND:
                          bra=lt!=NOT && lt!=LAND && lt!=EQ && lt!=NEQ &&
                              lt!=GE && lt!=GT && lt!=LE && lt!=LT &&
                              lt!=CHAR && lt!=TERMINALS;
                          break;
                 case LOR:
                         bra=lt!=NOT && lt!=LAND && lt!=LOR && lt!=EQ && 
                             lt!=NEQ && lt!=GE && lt!=GT && lt!=LE && lt!=LT;
                         break;
                 case BP:
                 case IBP:
                          bra=lt!=LAM && lt!=ILAM && lt!=BP && lt!=IBP;
                          break;
                 default:bra=1;
             }
   }
   if(bra)
    putch('(');
   pexp(l);
   if(bra)
    putch(')');
}

prexp(s,r)
short s;
OBJ r;
{  short bra,rt;
   rt=(UNMARK&tag(r));
   switch(rt)
   {  case ONIL:
      case ONAME:
      case ONUMB:
      case OTRUE:
      case OFALSE:
      case ORNAME:
      case ORNUMB:
      case OREMPTY:
      case DEF:
      case NAME:
      case OCHAR:
      case STRING:
      case RULE:
      case IRULE:
      case FIELD:
      case IFIELD:
      case OREAD:
      case OREADLN:
      case ORFAIL:
      case ORSTOP:
      case ORID:
      case ORCHARACTER:
      case ORAND:
               bra=0;
               break;
      default:
              switch(s)
              {  case ADD:
                          bra=rt!=NEG && rt!=ADD && rt!=SUB &&
                              rt!=MULT && rt!=DIV && rt!=MOD;
                          break;
                 case SUB:
                          bra=rt!=NEG && rt!=MULT && rt!=DIV && rt!=MOD;
                          break;
                 case MULT:
                           bra=rt!=NEG && rt!=MULT && rt!=DIV && rt!=MOD;
                           break;
                 case MOD:
                 case DIV:
                          bra=rt!=NEG;
                          break;
                 case EQ:case NEQ:
                 case LT:case LE:
                 case GT:case GE:
                                 bra=rt!=NEG && rt!=ADD && rt!=SUB &&
                                     rt!=MULT && rt!=DIV && rt!=INDEX &&
                                     rt!=MOD && rt!=HD && rt!=TL &&
                                     rt!=CHAR && rt!=TERMINALS;
                                 break;
                 case NOT:
                          bra=rt!=EQ && rt!=NEQ && rt!=LT && rt!=LE &&
                              rt!=GE && rt!=GT;
                          break;
                 case LAND:
                          bra=rt!=EQ && rt!=NEQ && rt!=LE && rt!=LT &&
                              rt!=GE && rt!=GT && rt !=NOT && rt!=LAND;
                          break;
                 case LOR:
                         bra=rt!=EQ && rt!=NEQ && rt!=LE && rt!=LT &&
                             rt!=GE && rt!=GT && rt !=NOT && rt!=LAND &&
                             rt!=LOR;
                         break;
                 case LAM:
                          bra=rt!=LAM && rt!=ADD && rt!=SUB && rt!=MULT &&
                              rt!=DIV && rt!=MOD && rt!=INDEX &&
                              rt!=NEG && rt!=NOT && rt !=EQ &&
                              rt!=NEQ && rt!=LE && rt!=LT && rt!=GE &&
                              rt!=GT && rt!=LAND && rt!=LOR && rt!=NOT;
                          break;
                 case BP:
                 case IBP:
                          bra=rt!=LAM && rt!=ILAM && rt!=LIST && rt!=ILIST &&
                              rt!=ADD && rt!=SUB && rt!=MULT && rt!=DIV &&
                              rt!=MOD && rt!=INDEX &&
                              rt!=EQ && rt!=NEQ && rt!=LE && rt!=LT &&
                              rt!=GE && rt!=GT && rt!=NOT &&
                              rt!=LAND && rt!=LOR;
                          break;
                 case HD:
                 case TL:
                         bra=rt!=HD && rt!=TL;
                         break;
                 default:bra=1;
              }
   }
   if(bra)
    putch('(');
   pexp(r);
   if(bra)
    putch(')');
}

sputchar(c,nlprint)
OBJ c;
short nlprint;
{  if((int)value(c)=='\n' && nlprint)
    fprint("\\n");
   else
   if((int)value(c)==';')
    fprint("\\;");
   else
   if((int)value(c)=='\'')
    fprint("\\'");
   else
   if((int)value(c)=='\\')
    fprint("\\\\");
   else
   if((int)value(c)=='"')
    fprint("\\\"");
   else
    putch((int)value(c));
}

plist(l)
OBJ l;
{  while((UNMARK&tag(l))==LIST || (UNMARK&tag(l))==ILIST)
   {  plistelem(hd(l));
      putch(':');
      l=tl(l);
   }
   if(l==NIL)
    return;
   plistelem(l);
}

plistelem(l)
OBJ l;
{  short bra;
   switch((UNMARK&tag(l)))
   {  case ONIL:
      case ONUMB:
      case OCHAR:
      case STRING:
      case OTRUE:
      case OFALSE:
      case NAME:
      case ONAME:
      case DEF:
      case OREMPTY:
      case ORNAME:
      case ORNUMB:
      case ORSTOP:
      case ORFAIL:
      case ORCHARACTER:
      case ORID:
      case FIELD:
      case IFIELD:
               bra=0;
               break;
      default:bra=1;
   }
   if(bra)
    putch('(');
   pexp(l);
   if(bra)
    putch(')');
}

plam(l)
OBJ l;
{  fprint("lam ");
   while(1)
   {  pnames(hd(tl(l)));
      l=tl(tl(l));
      if(l==NIL)
       break;
      if((UNMARK&tag(l))!=LAM && (UNMARK&tag(l))!=ILAM)
       break;
      putch(' ');
   }
   putch('.');
   prexp(LAM,l);
}

plet(l)
OBJ l;
{  OBJ d,dd;
   indent();
   pindent("let ");
   d=hd(tl(l));
   while(1)
   {  pnames(hd(hd(d)));
      dd=tl(hd(d));
      while((UNMARK&tag(dd))==LAM)
      {  putch(' ');
         pnames(hd(tl(dd)));
         dd=tl(tl(dd));
      }
      fprint(" = ");
      pexp(dd);
      d=tl(d);
      if(d==NIL)
       break;
      pindent("and ");
   }
   pindent("in ");
   pexp(tl(tl(l)));
   outdent();
}
  
pnames(l)
OBJ l;
{  while((UNMARK&tag(l))==LIST)
   {  if((UNMARK&tag(hd(l)))==LIST)
      {  putch('(');
         pnames(hd(l));
         putch(')');
      }
      else
       fprint("%s",name(hd(l)));
      putch(':');
      l=tl(l);
   }
   if(l==NIL)
    return;
   fprint("%s",name(l));
}

pbp(l)
OBJ l;
{  plexp(BP,hd(l));
   putch(' ');
   prexp(BP,tl(l));
}  

prule(l)
OBJ l;
{  putch('{');
   l=tl(l);
   while(1)
   {  prulebody(hd(l));
      l=tl(l);
      if(l==NIL)
       break;
      fprint(" | ");
   }
   putch('}');
}

prulebody(r)
OBJ r;
{  while(1)
   {  pexp(hd(r));
      r=tl(r);
      if(r!=NIL)
       putch(' ');
      else
       break;
   }
}

pindex(l)
OBJ l;
{  plexp(INDEX,hd(l));
   ppselect(tl(l));
}
   
ppselect(l)
OBJ l;
{  if(hd(l)!=NIL)
   {  putch('^');
      pexp(hd(l));
   }
   if(tl(l)!=NIL)
   {  putch('@');
      prexp(INDEX,tl(l));
   }
}

pclosure(l,base)
OBJ l,*base;
{  OBJ fvs,*f,*i,*oldtp;
   short letflag;
   if((fvs=hd(l))==NIL)
    switch(tag(l))
    {  case ILAM:plam(l);return;
       case ILET:plet(l);return;
       case IRULE:prule(l);return;
    }
   oldtp=tp;
   while(fvs!=NIL)
   {  tpush(hd(hd(fvs)));
      tpush(tl(hd(fvs)));
      fvs=tl(fvs);
   }
   letflag=0;
   f=tp-2;
   while(f>=oldtp)
   {  i=tp-2;
/*    while(i>=base) */
/*     if(i!=f && name((*i))==name((*f)) && *(i+1)==*(f+1)) */
/*      break; */
/*     else */
/*      i-=2; */
/*    if(i<base) */
      {  if(!letflag)
         { ++letflag;
           putch('(');
           indent();
           pindent("let ");
         }
         else
          pindent("and ");
         fprint("%s = ",name((*f)));
         if(tag((*(f+1)))==ILAM || tag((*(f+1)))==ILET)
          pclosure(*(f+1),base);
         else
          pexp(*(f+1));
      }
      f-=2;
   }
   tp=oldtp;
   if(letflag)
    pindent("in ");
   switch(tag(l))
   {  case ILAM:plam(l);break;
      case ILET:plet(l);break;
      case IRULE:prule(l);break;
   }
   if(letflag)
   {  pindent(")");
      outdent();
   }
}

pt(b)
OBJ * b;
{ OBJ * t;
  t=tp-2;
  nl();
  while(t>=b)
  {  printf("%d %s %d\n",t,name((*t)),*(t+1));
     t-=2;
  }
  nl();
}
