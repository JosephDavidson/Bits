#include<stdio.h>
#include<stdlib.h>
#include<generalSupport.h>

int
main(int arc, char **argv){

  int i;
  tokeniser_r *t;

  char string[] = "1,23,456,789,1024,1,4342342";

  setbuf(stdout, NULL);
  setbuf(stderr, NULL);

  t = tokenise(string, ',');

  printf("Tokenising done\n");

  for(i=0; i<t->length; i++){
    printf("%s\n",t->array[i]);
  }


  return(EXIT_SUCCESS);

}
