#include<stdio.h>
#include<stdlib.h>


int
main(int argc, char** argv){
  int i,
      numerator,
      denominator,
      loopCount,
      maxForLoop;

  loopCount = 1;

  while(loopCount < 10){
    printf("Starting loop %d\n", loopCount);
    maxForLoop = loopCount+1;
     
    numerator = maxForLoop - 1;
    denominator = 1; 
    
    for(i = 0; i < loopCount;i++){
      printf("%d/%d\n", numerator, denominator);  
      numerator -= 1;
      denominator += 1;    
    }
    loopCount += 1;
  }
      
  return EXIT_SUCCESS;
}
