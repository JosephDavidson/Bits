#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <stdarg.h>
#include <gmp.h>
#include <mpi.h>

void masterProcess();
void workerProcess();

main(int argc, char **argv){

  int id;

  setbuf(stdout, NULL);
  setbuf(stderr, NULL);

  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &id);

  if(id == 0){
    masterProcess();
  }else{
    workerProcess();
  }
  MPI_Barrier(MPI_COMM_WORLD);

  MPI_Finalize();

  return(EXIT_SUCCESS);

}


void
masterProcess(){

  mpz_t integer, resInt;

  mpz_init(integer);
  mpz_init(resInt);

  mpz_set_ui(integer, 5);
  mpz_set_ui(resInt, 10);

  size_t *result_size;
  void *result;
  

  result = mpz_export(NULL, result_size, 1, sizeof(int), 0,0, integer);

  printf("Exported\n");

  mpz_import(resInt, *result_size, 1, sizeof(int), 0, 0, result);

  gmp_printf("integer: %Zd, resInt: %Zd\n", integer, resInt);  

}

void
workerProcess(){

}

