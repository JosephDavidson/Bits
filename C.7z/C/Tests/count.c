#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

#include<gmp.h>

#define LIMIT_BITS 20 


int
main(){

  int i,
      bits,
      states,
      loop,
      symbols,
      counter,
      flag;

  mpz_t machines,
        tmp1,
        tmp2,
        rasp,
        mult;

  mpz_init(machines);
  mpz_init(rasp);
  mpz_init(tmp1);
  mpz_init(tmp2);
  mpz_init(mult);

  bits = 2;

  while (bits <= LIMIT_BITS){

    counter = 0;
    loop = 2;
    mpz_set_ui(rasp, pow(2,bits));
    mpz_set_ui(tmp1, pow(2,bits));
    mpz_set_ui(tmp2, pow(2,bits) - 4);

    // Power function for initilaising our rasp 
    while(mpz_cmp_ui(tmp2, 0) != 0){
       mpz_mul(rasp, rasp, tmp1);
       mpz_sub_ui(tmp2, tmp2, 1);
    }

    mpz_set_ui(mult, pow(2,bits));
    mpz_set_ui(tmp1, pow(2,bits) -1);    

    for(i=0; i< 7;i++){
      mpz_mul(mult, mult,tmp1);
      mpz_sub_ui(tmp1, tmp1, 1);
    }

    mpz_mul(rasp, mult, rasp);

    gmp_printf("RASP is %Zd for %d bits\n", rasp, bits);

    while(1){
      flag = 0;
      loop += 1;
      states = loop - 1;
      symbols = 1;       

      for(i=0;i<loop;i++){
         counter++;
         //printf("Trying (%d,%d) for %d bits\n", states, symbols, bits);
         mpz_set_ui(machines,(states+1) *symbols *2);
         mpz_pow_ui(machines, machines,states *symbols);
         states--;
         symbols++;
        
         //printf("%d\n",counter);
 
         if(mpz_cmp(machines,rasp) == 0){
           gmp_printf("states: %d, symbols: %d bits %d\n", states, symbols, bits);  
           flag = 1;
           break;
         }
         if(counter == 10000){
           printf("No candidate fround for %d bits\n", bits);
           flag = 1;
           break;
         } 
      }
      if(flag){
        bits++;
        break;
      }
     
    }

  }
}
