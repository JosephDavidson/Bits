#ifndef POOL_H_GUARD

#define POOL_H_GUARD

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include<mpi.h>
#include<gmp.h>

#include "defs.h"
#include "linkedList.h"
/*************************************************************************/

void pool();
int sendProc();

/*************************************************************************/

void
pool(){

  int recieved,
      flag,
      buffer,
      availableRequest;

  List *availableList = List_new();

  MPI_Request req;
  MPI_Status status;

  recieved = flag = availableRequest = 0;

  while(1){

    /* Proceedure for adding processor to available list */
    MPI_Iprobe(MPI_ANY_SOURCE, AVAILABLE, MPI_COMM_WORLD, &recieved, &status);
    if(recieved == 1){
      MPI_Irecv(&buffer, 1, MPI_INT, MPI_ANY_SOURCE, AVAILABLE,
                MPI_COMM_WORLD, &req);
      MPI_Wait(&req, &status);
      printf("Pool has retrived 'Available' message from processor %d\n",
              buffer);
      addElement(availableList, Element_new(buffer));
      printList(availableList);
    }

    /* Proceedure for removing processor from available list */
    MPI_Iprobe(MPI_ANY_SOURCE, BUSY, MPI_COMM_WORLD, &recieved, &status);
    if(recieved == 1){
      MPI_Irecv(&buffer, 1, MPI_INT, MPI_ANY_SOURCE, BUSY,
                MPI_COMM_WORLD, &req);
      MPI_Wait(&req, &status);
      printf("Pool has retrived 'Busy' message from processor %d\n",
              buffer);
      removeElement(availableList, buffer);
      printList(availableList);
    }
    
    /* Proceedure for dealing with available processor request */
    MPI_Iprobe(MASTER, FREE_PROC, MPI_COMM_WORLD, &recieved, &status);
    if(recieved == 1){
      MPI_Irecv(&buffer, 1, MPI_INT,
                MASTER, FREE_PROC, MPI_COMM_WORLD, &req);
      MPI_Wait(&req, &status);
      printf("Pool has recieved 'List' message from Master: %d\n", buffer);
      availableRequest = 1;
    }

    /* Proceedure for halting */
    MPI_Iprobe(MASTER, HALT_ALL, MPI_COMM_WORLD, &recieved, &status);
    if(recieved == 1){
      MPI_Irecv(&buffer, 1, MPI_INT,
                MASTER, HALT_ALL, MPI_COMM_WORLD, &req);
      MPI_Wait(&req, &status);
      printf("Pool has recieved 'Halt' message from Master: %d\n", buffer);
      break;
    }

    if(availableRequest == 1){
      availableRequest = sendProc(availableList);
    }
    
  }
  if(availableList == NULL){
    printf("List is NULL\n");
  }
  //deleteList(availableList);

}

/*************************************************************************/

int
sendProc(List *list){
  int buffer,
      flag; 
  
  MPI_Request req; 
  MPI_Status status;
 
  if(list == NULL || list->head == NULL){
    return 1;
  }

  buffer = list->head->number;
  flag = 0;

  MPI_Isend(&buffer, 1, MPI_INT, MASTER, FREE_PROC, MPI_COMM_WORLD, &req);  
  MPI_Wait(&req, &status);
  printf("Pool sent free processor %d\n", list->head->number);
  return 0;
}

#endif
