#ifndef DEFS_H_GUARD
#define DEFS_H_GUARD

#define MASTER             0
#define POOL               1

#define FREE_PROC          100

#define AVAILABLE          200
#define BUSY               404

#define HALT_ALL           900

#define INCOMING           300
#define ACK                111           

#endif
