#ifndef LL_H_GUARD
#define LL_H_GUARD

typedef struct Element{
  int number;
  struct Element *next;
  struct Element *prev;
}Element;

typedef struct List{
  Element *head;
}List;

/*****************************************************************************/

List* List_new();
Element* Element_new(int x);

void addElement(List *list, Element *element);
Element* findElement(List *list, int num);
void removeElement(List *list, int num);

void deleteList(List *list);
void deleteListNext(Element *e);

void printList(List *list);


/*****************************************************************************//*****************************************************************************/
/*****************************************************************************/

List*
List_new(){
  List *l;
  l = malloc(sizeof(List));
  l->head = NULL;
  return l;
}


Element*
Element_new(int x){
  Element *l;
  l =  malloc(sizeof(Element));
  l->number = x;
  l->next = NULL;
  l->prev = NULL;
  return l;
}

/*************************************************************************/

void
addElement(List *list, Element *element){
  Element *e;

  if(list->head == NULL){
    list->head = element;
    return;
  }

  e = list->head;

  while(e->next != NULL){
    e = e->next;
  }
  e->next = element;
  element->prev = e;

}

/*************************************************************************/

Element*
findElement(List *list, int num){
  Element *r;

  if(list->head == NULL){
    return NULL;
  }

  r = list->head;


  while(r != NULL && num != r->number){
    r = r->next;
  }

  return r;
}
/*************************************************************************/

void
removeElement(List *list, int num){
  Element *n, *p, *target;

  target = findElement(list, num);

  printf("Gets here\n");
  if(target == NULL ){
    return;
  }


  if(list->head == target){
    list->head = target->next;
  }
  n = target->next;
  p = target->prev;

  if(n != NULL){
    n->prev = NULL;
    if(p != NULL){
      n->prev = p;
    }
  }

  if(p != NULL){
    p->next = NULL;
    if(n != NULL){
      p->next = n;
    }
  }

  free(target);
}


/*************************************************************************/

void
deleteList(List *list){
  Element *e;

  if(list->head == NULL){
    return;
  }

  e = list->head;

  while(e->next != NULL){
    deleteListNext(e->next);
  }

}

void
deleteListNext(Element *e){
  if(e->next != NULL){
    deleteListNext(e->next);
  }
  free(e);
}


/*************************************************************************/
void
printList(List *list){
  Element *e;


  if(list->head == NULL){
    printf("List is NULL\n");
  }

  e = list->head;
  while(e != NULL){
    if(e->prev != NULL){
      printf("<");
    }
    printf("%d", e->number);
    if(e->next != NULL){
      printf(">");
    }
    e = e->next;
  }
  printf("\n");
}


#endif
