#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include<mpi.h>
#include<gmp.h>

#include "pool.h"
#include "worker.h"
#include "defs.h"

/*********************************************************************/
void master(int ranks);
void haltAll(int *buffers, int size);
/*********************************************************************/

int
main(int argc, char** argv){

  int id,
      size;

  setbuf(stdout, NULL);

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &id);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  if(id == MASTER && size < 3){
    printf("Not enough processors to perform function\n");
    return EXIT_FAILURE;
  }

  if(id == MASTER){
    master(size);
  }else if(id == POOL ){
    pool();    
  }else{
    worker(id);
  } 

  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Finalize();

  return EXIT_SUCCESS;
}

/*********************************************************************/

void
master(int ranks){

   int flag,
       *buffers;

   MPI_Request req;
   MPI_Status status;

   buffers = malloc(sizeof(int) * ranks + 1);

   MPI_Isend(&buffers[POOL], 1, MPI_INT, POOL, FREE_PROC, MPI_COMM_WORLD, &req);
   MPI_Wait(&req, &status);
   printf("Master sent message successfully\n");

   MPI_Irecv(&buffers[POOL], 1, MPI_INT, POOL, FREE_PROC, MPI_COMM_WORLD, &req);
   MPI_Wait(&req, &status);
   printf("Master has recieved the free processor %d\n",buffers[POOL]);

   haltAll(buffers, ranks);
   
   sleep(3);

   free(buffers);

}

/*********************************************************************/

void
haltAll(int *buffers,int size){	
  int i;
  
  MPI_Request req;

  for(i = POOL;i < size ; i++){
    MPI_Isend(&buffers[i], 1, MPI_INT, i, HALT_ALL, MPI_COMM_WORLD, &req);
  }
}


