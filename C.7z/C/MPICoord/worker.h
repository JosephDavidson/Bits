#ifndef WORKER_H_GUARD

#define WORKER_H_GUARD

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include<mpi.h>
#include<gmp.h>

#include "defs.h"

void worker(int id);
int checkHalt(int id);



/*****************************************************************************/

void
worker(int id){

  int buffer,
      recieved,
      flag,
      halted;

  buffer = id;

  recieved = flag = halted = 0;

  MPI_Request req;
  MPI_Status status;

  MPI_Isend(&buffer, 1, MPI_INT, POOL, AVAILABLE, MPI_COMM_WORLD, &req);

  MPI_Wait(&req, &status);
  if(id > 3){
    MPI_Isend(&buffer, 1, MPI_INT, POOL, BUSY, MPI_COMM_WORLD, &req);
  }
   

  while(!halted){
    halted = checkHalt(id);
  }
}

/*****************************************************************************/

int
checkHalt(int id){

  MPI_Request req;
  MPI_Status status;

  int buffer,
      recieved;
   
  /* Procedure for halting */
  MPI_Iprobe(MASTER, HALT_ALL, MPI_COMM_WORLD, &recieved, &status);
  if(recieved == 1){
    MPI_Irecv(&buffer, 1, MPI_INT,
              MASTER, HALT_ALL, MPI_COMM_WORLD, &req);
    MPI_Wait(&req, &status);
    printf("Worker %d has recieved 'Halt' message from Master: %d\n",
           id, buffer);

   return 1;
}



}
#endif
