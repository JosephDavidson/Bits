/* simple genetic algorithm for coin counting */
/* Greg Michaelson - greg@cee.hw.ac.uk        */

#include <stdio.h>

#define MAXCOIN 7
long coins[MAXCOIN]; /* coin values */

#define MAXC 200000
long cand[MAXC][MAXCOIN]; /* candidate codings */

long fit[MAXC];           /* candidate fitness */
long count[MAXC];         /* no of coins in candidate */
long total[MAXC];         /* value of coins in candidate */

#define MAXNO 100         /* max initial no of coins */

long CANDS;               /* how many candidates? */
long SELECT;              /* select how many fit candidates? */
long CROSS;               /* how many crossovers? */
long MUTATE;              /* how many mutations? */
long MAXPRINT;            /* print how many candidates? */

long STEP;                /* stop after each generation? */
long CHANGE;              /* only print if most fit has changed? */

long sum,max,min;         /* how much money/max no of coins/min no of coins? */

initcoins()               /* initial coin values */
{  coins[0]=100;
   coins[1]=50;
   coins[2]=20;
   coins[3]=10;
   coins[4]=5;
   coins[5]=2;
   coins[6]=1;
}

initrand() /* use time of day to seed random no generation */
{  srandom(time(0));  }

initcands() /* give each candidate a random no of coins */
{  long i,j;
   for(i=0;i<CANDS;i++)
    for(j=0;j<MAXCOIN;j++)
     cand[i][j]=random()%MAXNO;
}

swap(i,j)
long *i,*j;
{  long t;
   t=*i;
   *i=*j;
   *j=t;
}

fitness()
{  long i,j,k,t;
   for(i=0;i<CANDS;i++) /* calculate fitnesses */
   {  total[i]=0;
      count[i]=0;
      for(j=0;j<MAXCOIN;j++)
      {  total[i]=total[i]+cand[i][j]*coins[j];
         count[i]=count[i]+cand[i][j];
      }
      fit[i]=abs(sum-total[i]);
      if(count[i]<min)
       fit[i]=fit[i]+(min-count[i])*(min-count[i]);
      else
      if(count[i]>max)
       fit[i]=fit[i]+(count[i]-max)*(count[i]-max);
   }
   for(i=0;i<CANDS-1;i++) /* sort in fitness order */
    for(j=i;j>=0;j--)
     if(fit[j]>fit[j+1])
     {  swap(&(fit[j]),&(fit[j+1]));
        swap(&(count[j]),&(count[j+1]));
        swap(&(total[j]),&(total[j+1]));
        for(k=0;k<MAXCOIN;k++)
         swap(&(cand[j][k]),&(cand[j+1][k]));
     }
}

printcand(i)
long i;
{  long j;
   for(j=0;j<MAXCOIN;j++)
    printf("%4d ",cand[i][j]);
}

printcands()
{  long i;
   printf("cand ");
   for(i=0;i<MAXCOIN;i++)
    printf("%3dp ",coins[i]);
   printf("  sum  count  fit\n");
   for(i=0;i<MAXPRINT;i++)
   {  printf("%4d ",i);
      printcand(i);
      printf("%5d %5d %5d\n",total[i],count[i],fit[i]);
   }
   printf("\n");
}

crossover()
{  long i,j,k,l;
   for(k=0;k<CROSS;k++)
   {  i=random()%CANDS;   /* select 2 random candidates */
      j=random()%CANDS;
      l=random()%MAXCOIN; /* select random crossover point */
      swap(&(cand[i][l]),&(cand[j][l]));
   }
}

mutate() /* change rand cand at rand code position to rand coin no */
{  long i,j;
   for(i=0;i<MUTATE;i++)
    cand[random()%CANDS][random()%MAXCOIN]=random()%MAXNO;
}

reproduce() /* copy 1st SELECT cands repeatedly to replace less fit cands */
{  long i,j,k,c;
   for(i=0;i<CANDS/SELECT;i++)
    for(j=0;j<SELECT;j++)
     for(k=0;k<MAXCOIN;k++)
      cand[i*SELECT+j][k]=cand[j][k];
   c=SELECT*(CANDS/SELECT);
   for(j=c;j<CANDS;j++)
    for(k=0;k<MAXCOIN;k++)
     cand[j][k]=cand[j-c][k];
}

readint(m,i,mm) /* read integer - limit check */
char * m;
long * i,mm;
{  printf("%s ",m);
   scanf("%d",i);
   if(*i>mm)
   {  (*i)=mm;
      printf("restricted to %d\n",mm);
   }
}

readi(m,i) /* read integer - no limit check */
char * m;
long * i;
{  printf("%s ",m);
   scanf("%d",i);
}

readyn(m,a) /* check for yes/no answer */
char * m;
long * a;
{  char c;
   printf("%s ",m);
   scanf("%c",&c);
   (*a)=c=='y'?1:0;
}
    
main()
{  long g;                /* no of generations */
   long oldfittest;
   initrand();
   initcoins();
   readi("how much money?",&sum);
   readi("maximum number of coins?",&max);
   readi("minimum number of coins?",&min);
   readint("how many candidates? ",&CANDS,MAXC);
   readint("select how many fittest candidates?",&SELECT,CANDS);
   readint("how many crossovers?",&CROSS,CANDS);
   readint("how many mutations?",&MUTATE,CANDS);
   readint("print how many fit candidates?",&MAXPRINT,CANDS);
   getchar();
   readyn("stop after each generation?",&STEP);
   getchar();
   readyn("only show generation after change in most fit?",&CHANGE);
   initcands();
   fitness();
   printcands();
   g=0;
   oldfittest=0;
   while(fit[0] || count[0]<min || count[0]>max)
   {  reproduce();
      crossover();
      mutate();
      fitness();
      g++;
      if(!CHANGE || fit[0]!=oldfittest)
      {  if(STEP)
          getchar();
         printf("GENERATION %d sum %d max %d min %d",g,sum,max,min);
         printf(" cands %d sel %d cross %d mut %d\n",CANDS,SELECT,CROSS,MUTATE);
         printcands();
      }
      oldfittest=fit[0];
   }
}

