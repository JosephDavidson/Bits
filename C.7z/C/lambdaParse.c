#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct node{
  struct node  *left;
  struct node  *right;
  int type;            
  char value;
}node;

// Types:
// 1 Abstraction
// 2 Application 
// 3 Value

int reverseMatchingBracket(char * str, int startIndex);
char* getsubstring(char* s, int start, int end);
node *parseIntoTree(char *s);
node* evaluate(node *n);
int eval(node *n);

void printExpr(node *n);
int tidy(node *n);
int applyAbstraction(node *n, char ch, node *replacement);
node* copyNode(node *n);
void debugNode(node *n);

void printExpr(node *n);
void printTree(node *n, int level);
node *node_new(int type, char value);
void node_free(node *n);


int
main(int argc, char **argv){

  
  node *parent;
  node *treepointer = NULL;
  int i = 0;
  int x = 0;  
  char *s = argv[1];
  
  setbuf(stdout, NULL);
  //printf("%s\n",argv[1]);

  parent = parseIntoTree(s);
  printExpr(parent);
  printf("\n");

  evaluate(parent);
  printExpr(parent); 
  printf("\n");
}


node* 
parseIntoTree(char *s){
  
  node *n;
  int i= 0;
  int x;
  char *expA;
  char *expB; 

  printf("Parsing %s of size %d\n", s, strlen(s));

  if(s[0] == '\0'){
    //printf("string is null\n");
    return NULL;
  }
 
  if(s[0] == '\\'){
    printf("Found \\\n");
    n = node_new(1,s[i+1]);
    printf("calling left abstraction\n");
    n->left = node_new(3, s[i+1]);
    printf("calling right abstraction on %s\n", getsubstring(s,i+3,strlen(s)));
    n->right = parseIntoTree(getsubstring(s,i+3,strlen(s))); // Might need a range variable rather than the
    return n;                                                // rest of the string
  }
  i = strlen(s)-1;

  while(i > 0){
   printf("%d : %c\n", i, s[i]); 
    if(s[i] == ')'){
      printf("Found )\n");
      x = reverseMatchingBracket(s, i);
      if(x == 0){
        printf("Parsing into %s\n",getsubstring(s,1, i));
        return parseIntoTree(getsubstring(s,1, i)); 
      }
      n = node_new(2,'0');
      printf("Left expr is %s\n", getsubstring(s,0,x));
      printf("Right expr is %s\n", getsubstring(s,x+1,strlen(s)-1));
      printf("calling left (\n");
      n->left = parseIntoTree(getsubstring(s,0,x));
      //printf("calling right (\n");
      n->right = parseIntoTree(getsubstring(s,x+1, strlen(s)-1));
      return n;
    }
    if(s[i] == ' '){
      //printf("Found space\n");
      i--;
      continue;
    }     
    if(s[i] == '('){
      //printf("Found (\n");
      return NULL;
    }
    if( i-1 == 0 || s[i-1] != '(' || s[i-1] != ')' || s[i-1] != '.'){
     // another application for variables... this might not toally work first time
     printf("Found variable %c\n", s[i]);
     n = node_new(2,'0');
     printf("Calling parse on %s\n",getsubstring(s, 0, i));
     n->left = parseIntoTree(getsubstring(s, 0, i));
     n->right = node_new(3,s[i]);
     return n;
    }
   }
   printf("Default parse\n");
   n = node_new(3,s[i]);
   //printf("Left node is %c\n", s[i]);
   //printf("Right node is %s\n", getsubstring(s,i+1,strlen(s)));
   //printf("calling right var\n");
   return n; 
}

void
printExpr(node *n){
  if(n == NULL)
    return;
 
  if(n->left != NULL && n->type == 2){
    if(n->left->type == 3){
      printf("%c", n->left->value);
    }else{
      printf("(");
      printExpr(n->left);
      printf(")");
    }
     
    if(n->right != NULL && n->right->type == 3){
      printf("%c", n->right->value);
    }else{
      printf("(");
      printExpr(n->right);
      printf(")");
    }
  }
  
  if(n->type == 1){
    printf("\\%c.",n->value);
    printExpr(n->right);
  }
  if(n->type == 3){
    printf("%c", n->value);
  }
}

int 
reverseMatchingBracket(char *s, int i){

   int count =1;
   while(count > 0 && i > 0){
     i--;    //start on the next character
     if(s[i] == ')')
       count++;
     else if(s[i] == '(')
       count--;
   }
   if(i == 0 && count != 0){
     printf("Badly matched brackets!\n");
     exit(0);
   }
   return i;
} 

node*
evaluate(node *parent){

  int changed = 1;
  printf("Evaluating\n");

  while(changed){
    changed = eval(parent);
    //printf("Tidying now\n");
    tidy(parent);
    printf("Returned %d. Now we have:\n", changed);
    printExpr(parent);
    printf("\n");
  }
  printf("Done!\n");
  printTree(parent, 0);
  return parent;
}

int
eval(node *n){
  // Check to see if the node is an application and if the left
  // is an abstraction
  node *k;
  char rval=0;
  if(n == NULL)
    return 0;
  if(n->type == 2 && n->left->type == 1){

     printf("Applying abstraction %c\n",n->left->value );
     printf("Expression:\n");
     printTree(n->right,0);
     printf("-----------\nTo tree:\n");
     printTree(n->left,0);
     
     rval = applyAbstraction(n->left, n->left->value, n->right);
     node_free(n->right);
     n->right = NULL;
     k = n->left;
     n->left =k->right;
     k->right = NULL;
     node_free(k);    
   return 1;   
   }
  return eval(n->left) || eval(n->right);
}

int
applyAbstraction(node *n, char ch, node *replacement){

  int ret = 0;

  if(n == NULL)
    return 0;

 
  printf("Current Tree for %c\n", ch); 
  printTree(n,0);
  printf("-------------\n");
 
  if(n->type != 1){
    if(n->left->type ==3){ 
      if(n->left->value == ch){
        printf("Found %c on the left:\n",ch);
        printTree(replacement,0);
        printf("-------------\n");
        node_free(n->left);
        n->left = copyNode(replacement);
      }
    }else{
      ret = applyAbstraction(n->left, ch, replacement);
    }
  }  
  
    if(n->right->type == 3){
      if(n->right->value == ch){
        printf("Found %c on the right:\n",ch);
        printTree(replacement,0);
        printf("-------------\n");
        node_free(n->right);
        n->right = copyNode(replacement);
      }
    }else{
      printf("Going right\n");
      ret = applyAbstraction(n->right, ch, replacement);
    }
  
  printf("returning %d\n", ret);
  return ret;
}
   
int
tidy(node *n){
  printf("Tidying\n");
  printTree(n,0);
  if(n == NULL || n->type != 2){
    return 0;
  }  

  if(n->right == NULL){
    printf("Making sub\n");
    node *k = n->left;
    n->right = k->right;
    n->left = k->left;
    k->left = NULL;
    k->right = NULL;
    n->type = k->type;
    n->value = k->value;
    node_free(k);
    printf("-----------\n");
    printf("new tree is\n");
    printTree(n,0);
    printf("-----------\n");
    return 1 || tidy(n->left) || tidy(n->right);   
  }else{
   return tidy(n->left) || tidy(n->right);
  }
}


node*
copyNode(node *n){
  if(n == NULL){
    return NULL;
  }
  node *k = node_new(n->type, n->value);
  k->left = copyNode(n->left);
  k->right = copyNode(n->right);
  return k;
}


char*
getsubstring(char *s, int start, int end){
   int size = (end-start)+2;
   char *str = malloc(sizeof(char)*size);
   memcpy(str,&s[start],size-2);
   str[size-1] = '\0';
   return str;    
} 


void
printTree(node *n, int level){
  int i;
  for(i = 0;i<level;i++){
    printf("  ");
  }
  if(n == NULL){
    printf("NULL\n");
    return;
  }
  printf("%s : %c\n",(n->type == 1 ? "ABS" : (n->type == 2 ? "APP" : "VAR")), n->value);
  if(n->type != 3){
    printTree(n->left, level+1);
    printTree(n->right, level+1);
  }
}

node *
node_new(int t, char c){
  node *n = malloc(sizeof(node));
  n->left = NULL;
  n->right = NULL;
  n->type = t;
  n->value = c;
}

void
node_free(node *n){
  if(n->left !=NULL)
    node_free(n->left);
  if(n->right != NULL)
    node_free(n->right);
  free(n);
}


