
#ifndef BASES_GUARD 
#define BASES_GUARD


#include<stdio.h>
#include<string.h>
#include<math.h>
#include<gmp.h> 


void outputArbitraryBaseNumber(FILE *fp, int *number, int numLength);
void incrementArbitraryBaseNumber(int base, int *number, int numLength);
int* convertBetweenBases(int* original, int originalBase,
                         int baseTo, int originalSize);
int* convertBase10ToArbitrary(mpz_t original, int baseTo, int fixed);
void convertArbitraryToBase10(mpz_t value, int* original,
                                           int originalBase, int size);
int determineSize(int* number);


/*&****************************************************************************/
void 
outputArbitraryBaseNumber(FILE *fp, int *number, int numLength){
  int i;

  for(i = 0;i < numLength; i++){
    fprintf(fp," %d |",number[i] );
  }
  fprintf(fp, "\n");

}

/*****************************************************************************/
void
incrementArbitraryBaseNumber(int base, int *number, int numLength){

  int flag,
      currentIndex;

  flag = 0;
  currentIndex = numLength - 1;

  while(flag == 0){

    if(number[currentIndex] == base - 1){
      number[currentIndex] = 0;
      currentIndex -= 1;
    }else {
      number[currentIndex] += 1;
      flag = 1;
    }

    if(currentIndex == -1){
      flag = 1;
    }

  }

} 

/*****************************************************************************/
int*
convertBetweenBases(int* original, int originalBase, int baseTo, int size){
  
//  return convertBase10ToArbitrary(convertArbitraryToBase10(original,
  //                                                         originalBase,
    //                                                       size),
      //                            baseTo, 0);
}

/*****************************************************************************/
int* convertBase10ToArbitrary(mpz_t original, int baseTo, int fixedSize){
  
  int runningTotal,
      newSize,
      *returnNumber,
      index;

  mpz_t tmp,
        base;


  mpz_init(tmp);
  mpz_init(base);

  /* Convert to our base of choice */
  /* Work out the size of the resultant number */ 
  newSize = 1;

  mpz_set_ui(base, baseTo);
   
  mpz_pow_ui(tmp, base, newSize+1);
  mpz_sub_ui(tmp, tmp, 1);
 
  while(mpz_cmp(original, tmp) > 0){
    newSize++;
    mpz_pow_ui(tmp, base, newSize+1);
    mpz_sub_ui(tmp, tmp, 1);
  }

  if(newSize == 1){
    newSize = 2;
  }

  if(fixedSize != 0){
    newSize = fixedSize;
  }

  returnNumber = malloc(sizeof(int) * newSize);
  memset(returnNumber, 0, sizeof(int) * newSize);

  index = 0;
  
  /* convert the base 10 number to this new base*/
  while(mpz_sgn(original) > 0){ 
    mpz_pow_ui(tmp, base, newSize-1);
    if(mpz_cmp(original, tmp ) >= 0){
      returnNumber[index] += 1;
      mpz_sub(original, original, tmp);
    }else{
      index += 1;
      newSize -= 1;
    }
  }

  mpz_clear(tmp);
  mpz_clear(base);
   
  return returnNumber;

}

/*****************************************************************************/

void convertArbitraryToBase10( mpz_t value, int* original,
                                           int originalBase, int size){

  int index,
      exp;

  mpz_t mult;

  mpz_init(mult);

  /* convert original to base 10 */
  
  mpz_set_ui(value, 0);
  index = 0;
  exp = size - 1;
  while(index < size){
    mpz_set_ui(mult, pow(originalBase, exp));
    mpz_mul_ui(mult, mult, original[index]);
    mpz_add(value, value, mult);
    index += 1;
    exp -= 1;
  }

  mpz_clear(mult);
  
}

/*****************************************************************************/

int determineSize(int* number){

  int size;

  size = 0;

  while(number[size] != -1){
    size += 1;
  }

  return size;
}


#endif
