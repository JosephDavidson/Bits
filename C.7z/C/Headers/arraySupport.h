#ifndef ARRAY_SUPPORT_GUARD
#define ARRAY_SUPPORT_GUARD

int unique(int *array, int size);
int isZeroed(int* array, int size );
int lookup(int *arr, int target, int arraySize);
int arrayEqual(int *arr1, int *arr2, int size);
/*****************************************************************************/

int	
unique(int *array, int size){

  int i,j;

  for(i = 0; i < size-1; i++){
    for(j = i+1; j< size;j++){
      if(array[i] == array[j]){
        return 0;
      }
    }
  }

  return 1;

}

/*****************************************************************************/
int
isZeroed(int* array, int size ){
  int i;

  for(i = 0;i < size; i++){
    if(array[i] != 0){
      return 0;
    }
  }
  return 1;

}
/*****************************************************************************/
int
lookup(int *arr, int target, int arraySize){

  int i;

  for(i = 0; i < arraySize; i++){ 
    if(arr[i] == target){
      return i;
    }
  }

  return -1;

}

/*****************************************************************************/
int
arrayEqual(int *arr1, int *arr2, int size){

  int i;

  for(i = 0;i < size; i++){
    if(arr1[i] != arr2[i]){
      printf("%d compared to %d\n", arr1[i], arr2[i]);
      return 0;
    }
  }
  return 1;

}


#endif
