#ifndef EXTRA_MATH_GUARD
#define EXTRA_MATH_GUARD

#include<math.h>

int factorial(int f);
int randint(int min, int max);


int
factorial(int f){

  if(f == 0){
    return 1;
  }

  return f * factorial(f-1);

}

int randint(int min,int max) {
  return min + (int)((max-min+1)*(rand()/(RAND_MAX+1.0)));
}

  
#endif
