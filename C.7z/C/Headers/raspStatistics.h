#ifndef RASP_STAT_H_GUARD
#define RASP_STAT_H_GUARD

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gmp.h>

#include<generalSupport.h>
#include<raspMachineTCL.h>

typedef struct{
  int *outputProgram,
      *shiftProgram,
      *instructionSet;
} SimilarityIndex;

/**********************************************************************/

typedef struct{
  mpz_t machineHaltInstruction;
  mpz_t machineHaltUnrecognised;
  mpz_t machineNonHalt;
  mpz_t highestOutput;
  mpz_t highestShift;

  int *highestOutputs,
      *highestShifts,
      *instructionSet;

} InstructionSetStats;

/**********************************************************************/

typedef struct{
  int numISets;
  int programSize;
  int processor;

  mpz_t machineHaltInstruction;
  mpz_t machineHaltUnrecognised;
  mpz_t machineNonHalt;
  mpz_t highestOutput;
  mpz_t highestShift;
  mpz_t totalOutputs;
  mpz_t startMachine;
  mpz_t endMachine;
  
  SimilarityIndex *similarityIndex;
  InstructionSetStats **instructionSetStats; 
 
} RaspBatchStats;

/**********************************************************************/

RaspBatchStats* raspBatchStats_new(int numISets, int programSize, int processor, mpz_t startmachine);
void raspBatchStats_free(RaspBatchStats *r);
void updateStats(machine *mach, RaspBatchStats *r, int iset);
void printStats(RaspBatchStats *r);

InstructionSetStats* instructionSetStatisitics_new(int *iset);
void instructionSetStats_free(InstructionSetStats *is);
void setUpNewInstructionSetStats(RaspBatchStats *r, int pos, int* iset);
void updateIsetStats(machine *mach, InstructionSetStats *is);
void printInstructionSetStats(InstructionSetStats *is, int programSize);

void generateSimilarityIndex(RaspBatchStats *rbs);
void printHaltingPlotData(RaspBatchStats *rbs, FILE *fp);

void printOutputPlotData(RaspBatchStats *rbs, FILE *fp);
void printBatchData(RaspBatchStats *rbs, FILE *fp);
/**********************************************************************/
/**********************************************************************/
/**********************************************************************/

RaspBatchStats* raspBatchStats_new(int numISets, int programSize, int processor, mpz_t startmachine){
  RaspBatchStats *r = xmalloc(sizeof(RaspBatchStats));
  mpz_init(r->machineHaltInstruction);
  mpz_init(r->machineHaltUnrecognised);
  mpz_init(r->machineNonHalt);
  mpz_init(r->highestOutput);
  mpz_init(r->highestShift);
  mpz_init(r->totalOutputs);
  mpz_init(r->startMachine);
  mpz_init(r->endMachine);
 
  r->processor = processor;
  r->numISets = numISets;
  r->programSize = programSize;
  r->similarityIndex = NULL;
  mpz_set(r->startMachine, startmachine);

  
 // r->instructionSetStats =
//           xmalloc(sizeof(InstructionSetStats*) * numISets);

  return r;
} 

/**********************************************************************/

void raspBatchStats_free(RaspBatchStats *r){

  int i;

  mpz_clear(r->machineHaltInstruction);
  mpz_clear(r->machineHaltUnrecognised);
  mpz_clear(r->machineNonHalt);
  mpz_clear(r->highestOutput);
  mpz_clear(r->highestShift);
  mpz_clear(r->totalOutputs);
  
  if(r->similarityIndex != NULL){
  //  similarityIndex_free(r->similarityIndex); 
  }

  for(i= 0 ;i < r->numISets;i++){
    instructionSetStats_free(r->instructionSetStats[i]);
  }

  free(r->instructionSetStats);
}

/**********************************************************************/

void updateStats(machine *mach, RaspBatchStats *r, int iset){

  if(mach->progState->halted == 1){
    mpz_add_ui(r->machineHaltInstruction, r->machineHaltInstruction, 1); 
  }else if(mach->progState->halted == -1){
    mpz_add_ui(r->machineHaltUnrecognised, r->machineHaltUnrecognised, 1); 
  }else if(mach->progState->halted == 0){
    mpz_add_ui(r->machineNonHalt, r->machineNonHalt, 1);
  }
  
  mpz_add_ui(r->totalOutputs, r->totalOutputs, mach->progState->outputCount);


  if(mpz_cmp_ui(r->highestOutput, mach->progState->outputCount) < 0){
    mpz_set_ui(r->highestOutput, mach->progState->outputCount);
  }

  if(mpz_cmp_ui(r->highestShift, mach->progState->stepsRun) < 0){
    mpz_set_ui(r->highestShift, mach->progState->stepsRun);
  }

 // updateIsetStats(mach,r->instructionSetStats[iset]);

}

/**********************************************************************/

void printStats(RaspBatchStats *r){
  int i; 

  gmp_printf("Insturction Halting machines: %Zd\n", r->machineHaltInstruction);
  gmp_printf("Unrecognised Halting machines: %Zd\n", r->machineHaltUnrecognised);
  gmp_printf("Non Halting machines: %Zd\n\n", r->machineNonHalt);

  gmp_printf("Highest Output: %Zd\n", r->highestOutput);
  gmp_printf("Highest Shift: %Zd\n\n", r->highestShift);

  for(i=0; i< r->numISets; i++){
    printInstructionSetStats(r->instructionSetStats[i], r->programSize);
  }

  printf("\n/^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^/\n\n");

}

/**********************************************************************/
/**********************************************************************/

InstructionSetStats* instructionSetStats_new(int *iset){

  InstructionSetStats *is = xmalloc(sizeof(InstructionSetStats));

  mpz_init(is->machineHaltInstruction);
  mpz_init(is->machineHaltUnrecognised);
  mpz_init(is->machineNonHalt);
  mpz_init(is->highestOutput);
  mpz_init(is->highestShift);
  
  is->highestOutputs = NULL;
  is->highestShifts = NULL;
  is->instructionSet = xmalloc(sizeof(int) * 8);
  memcpy(is->instructionSet, iset, sizeof(int) * 8);

  return is;

}

/**********************************************************************/

void instructionSetStats_free(InstructionSetStats *is){

  mpz_clear(is->machineHaltInstruction);
  mpz_clear(is->machineHaltUnrecognised);
  mpz_clear(is->machineNonHalt);
  mpz_clear(is->highestOutput);
  mpz_clear(is->highestShift);
  
  free(is->highestOutputs);
  free(is->highestShifts);
  free(is->instructionSet);
}

/**********************************************************************/

void setUpNewInstructionSetStats(RaspBatchStats *r, int pos, int* iset){
   r->instructionSetStats[pos] = instructionSetStats_new(iset);
}

/**********************************************************************/

void updateIsetStats(machine *mach, InstructionSetStats *is){

  if(mach->progState->halted == 1){
    mpz_add_ui(is->machineHaltInstruction, is->machineHaltInstruction, 1); 
  }else if(mach->progState->halted == -1){
    mpz_add_ui(is->machineHaltUnrecognised, is->machineHaltUnrecognised, 1); 
  }else if(mach->progState->halted == 0){
    mpz_add_ui(is->machineNonHalt, is->machineNonHalt, 1);
    return;
  }

  if(mpz_cmp_ui(is->highestOutput, mach->progState->outputCount) < 0){
    mpz_set_ui(is->highestOutput, mach->progState->outputCount);

    free(is->highestOutputs);
    is->highestOutputs = xmalloc(sizeof(int) * (mach->memSize-3));
    memcpy(is->highestOutputs, mach->progState->program, sizeof(int)*(mach->memSize-3)); 
  }

  if(mpz_cmp_ui(is->highestShift, mach->progState->stepsRun) < 0){
    mpz_set_ui(is->highestShift, mach->progState->stepsRun);

    free(is->highestShifts);
    is->highestShifts = xmalloc(sizeof(int)*(mach->memSize-3));
    memcpy(is->highestShifts, mach->progState->program, sizeof(int)*(mach->memSize-3)); 
  }

}

/**********************************************************************/

void printInstructionSetStats(InstructionSetStats *is, int programSize){

  int i;

  gmp_printf("\tInsturction Halting machines: %Zd\n",
                                      is->machineHaltInstruction);
  gmp_printf("\tUnrecognised Halting machines: %Zd\n",
                                      is->machineHaltUnrecognised);
  gmp_printf("\tNon Halting machines: %Zd\n\n",
                                       is->machineNonHalt);

  gmp_printf("\tHighest Output: %Zd\n", is->highestOutput);
  gmp_printf("\tHighest Shift: %Zd\n\n", is->highestShift);

  printf("\tInstruction set:\n\t\t");
  for(i=0; i < 8;i++){
    printf("|%d",is->instructionSet[i]);
  }

  printf("\n\tHighest Outputs:\n\t\t");
  for(i=0; i < programSize-3;i++){
    printf("|%d",is->highestOutputs[i]);
  }

  printf("\n\tHighest Shifts:\n\t\t");
  for(i=0; i < programSize-3;i++){
    printf("|%d",is->highestShifts[i]);
  }



  printf("\n\t/**********************************************/\n\n");

}

/**********************************************************************/
/**********************************************************************/

void generateSimilarityIndex(RaspBatchStats *rbs){

  int compareSize,
      **topIsets,
      **topOuts,
      **topShifts;

  InstructionSetStats *topStat;

  SimilarityIndex *si = xmalloc(sizeof(SimilarityIndex));

  compareSize = (rbs->numISets / 100) * 5;
 
  si->outputProgram = xmalloc(sizeof(int) * rbs->programSize -3);
  si->shiftProgram = xmalloc(sizeof(int) * rbs->programSize -3);
  si->instructionSet = xmalloc(sizeof(int) * 8); 

  

  rbs->similarityIndex = si;
}


/**********************************************************************/

void
printHaltingPlotData(RaspBatchStats *rbs, FILE *fp){
  
  int i,x;

  for(i=0;i<rbs->numISets ;i++){
    for(x=0;x<8;x++){
      fprintf(fp,"%d,",rbs->instructionSetStats[i]->instructionSet[x]);
    }
    gmp_fprintf(fp,"\t%Zd\t%Zd\t%Zd\n",
                           rbs->instructionSetStats[i]->machineHaltInstruction, 
                           rbs->instructionSetStats[i]->machineHaltUnrecognised,
                           rbs->instructionSetStats[i]->machineNonHalt);
  }

}

void
printOutputPlotData(RaspBatchStats *rbs, FILE *fp){

  int i,x;

  for(i=0;i<rbs->numISets ;i++){
    for(x=0;x<8;x++){
      fprintf(fp,"%d,",rbs->instructionSetStats[i]->instructionSet[x]);
    }
    gmp_fprintf(fp,"\t%Zd\t%Zd\n",
                           rbs->instructionSetStats[i]->highestOutput, 
                           rbs->instructionSetStats[i]->highestShift);
  }
}

void 
printBatchData(RaspBatchStats *rbs, FILE *fp){
 // fprintf(fp,"Proc, haltIns, haltUnrec, nonHalt, highestShifts, highestOuts, combinedOuts");
  mpf_t opm,
        outs,
        machines;
  
  mpz_t temp;

  mpz_init(temp);    

  mpf_init(opm);
  mpf_init(outs);
  mpf_init(machines);

  mpz_sub(temp, rbs->endMachine, rbs->startMachine);

  mpf_set_z(outs, rbs->totalOutputs);
  mpf_set_z(machines, temp);
  mpf_div(opm, outs, machines);

  // Outs per machine

  gmp_fprintf(fp, "%d,%Zd,%Zd,%Zd,%Zd,%Zd,%Zd,%Ff,%Zd,%Zd\n",
                                                rbs->processor, 
                                                rbs->machineHaltInstruction,
                                                rbs->machineHaltUnrecognised,
                                                rbs->machineNonHalt,
                                                rbs->highestShift,
                                                rbs->highestOutput,
                                                rbs->totalOutputs,
                                                opm,
                                                rbs->startMachine,
                                                rbs->endMachine);

  mpf_clear(opm);
  mpf_clear(outs);
  mpf_clear(machines);

  mpz_clear(temp);
}



#endif
