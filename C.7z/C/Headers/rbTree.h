
#ifndef RB_TREE_GUARD

#define RB_TREE_GUARD
#include<stdio.h>
#include<stdlib.h>


typedef struct rbnode {
  void *value;
  int colour;
  struct rbnode *left;
  struct rbnode *right;
  struct rbnode *parent;
} rbnode;

typedef struct rbtree{
  rbnode* root;
} rbtree;

/**************************************************************************/

rbnode* rbnode_new();
void rbnode_free(rbnode* n, void (*valueFree)(void*) );

rbtree* rbtree_new();
 
void rbDeleteTree(rbnode* root, void (*valuefree)(void*));

rbnode* rbSearch(rbnode* root, rbnode* target, int (*fn)(void*, void*));

void rbInsert(rbtree* tree, rbnode* ins, int (*fn)(void*, void*));
void rbPrintTree(rbnode* tree, int depth);

void balanceCase1(rbnode* node, rbtree* root);
void balanceCase2(rbnode* node, rbtree* root);
void balanceCase3(rbnode* node, rbtree* root);
void balanceCase4(rbnode* node, rbtree* root);
void balanceCase5(rbnode* node, rbtree* root);

void replaceNode(rbtree *root, rbnode *old, rbnode *new);

void rotateLeft(rbnode* node, rbtree* root);
void rotateRight(rbnode* node, rbtree* root);

rbnode* getGrandparent(rbnode* node);
rbnode* getUncle(rbnode* node);
/*************************************************************************/

rbnode*
rbnode_new(){
  rbnode *n = malloc(sizeof(rbnode));
  
  n->colour = 2;
  n->value = NULL;
  n->left = NULL;
  n->right = NULL;
  n->parent = NULL;  

  return n;

}

void 
rbnode_free(rbnode* n, void (*fn)(void*)){
   if(n != NULL && n->value != NULL){
      (*fn)(n->value);
   }
   free(n);
}

rbtree*
rbtree_new(){
  rbtree *t = malloc(sizeof(rbtree));
  t->root = NULL;
  return t; 
}

void
rbDeleteTree(rbnode* root, void (*valuefree)(void*)){

  if(root == NULL){
    return;
  }
  
  rbDeleteTree(root->right, (*valuefree));
  rbDeleteTree(root->left, (*valuefree));

  rbnode_free(root,(*valuefree));

}

/*************************************************************************/
rbnode*
rbSearch(rbnode *root, rbnode *target, int(*fn)(void*, void*)){
   int result; 

   if(root == NULL){
     return NULL;
   }
   result = (*fn)(target->value, root->value);
   if(result == 0){
     return root;
   }else if(result == 1){
     return rbSearch(root->right, target, (*fn));
   }else{
     return rbSearch(root->left, target, (*fn));
   } 

}
/*************************************************************************/

void 
rbInsert(rbtree* tree, rbnode* ins, int (*fn) (void*, void*)){
  rbnode *n;
  int result;

  if(tree->root == NULL){
    tree->root = ins;
  }else{
    n = tree->root;
    while(1){
      result = (*fn)(ins->value, n->value);
      if(result == 1){
         if(n->right == NULL){
           n->right = ins;
           ins->parent = n;
           break;
         }else{
           n = n->right;
           continue;
         }
      }else{
        if(n->left == NULL){
          n->left = ins;
          ins->parent = n;
          break;
        }else{
          n = n->left;
          continue;
        }
      }
    }
  }
  balanceCase1(ins, tree);  

}

/*************************************************************************/

void 
rbPrintTree(rbnode* rbnode, int depth){

  int i;

  for(i=0;i<depth;i++){
    printf("|");
  }
  
  if(rbnode != NULL){
    printf("%d (%d)\n",rbnode->value, rbnode->colour);
    rbPrintTree(rbnode->right, depth+1);
    rbPrintTree(rbnode->left, depth+1);
  }else{
    printf("NULL (1)\n");
  }
}

/*************************************************************************/
void 
balanceCase1(rbnode *node, rbtree *root){
  if(node->parent == NULL){
    node->colour = 1;
  }else{
    balanceCase2(node, root);
  }
}

void 
balanceCase2(rbnode* node, rbtree *root){
  if(node->parent->colour == 1){
    return;
  }else{
    balanceCase3(node, root);
  }
}

void 
balanceCase3(rbnode* node, rbtree *root){
  rbnode *u,
         *g;

  u = getUncle(node);
  g = getGrandparent(node);

  if(u != NULL && u->colour == 2){
    node->parent->colour = 1;
    u->colour = 1;
    g->colour = 2;
    balanceCase1(g, root);
  }else{
    balanceCase4(node, root);
  }

}

void 
balanceCase4(rbnode* node, rbtree *root){
  rbnode* g = getGrandparent(node);

  if(node == node->parent->right 
                       && node->parent == getGrandparent(node)->left){
    
    rotateLeft(node->parent, root);
    node = node->left;
  }else if(node == node->parent->left 
                       && node->parent == getGrandparent(node)->right){
    rotateRight(node->parent, root);
    node = node->right;
  }

  balanceCase5(node, root);

}

void 
balanceCase5(rbnode *node, rbtree *root){
  rbnode *g;
  
  g = getGrandparent(node);
  
  node->parent->colour = 1;
  g->colour = 2;
  
  if(node == node->parent->left && node->parent == g->left){
    rotateRight(g, root);
  }else{
    rotateLeft(g, root);
  } 

}

/*************************************************************************/
void 
replaceNode(rbtree* root, rbnode* old, rbnode* new){
  if(old->parent == NULL){
    root->root = new;
  }else{
    if(old == old->parent->left){
      old->parent->left = new;
    }else{
      old->parent->right = new;
    }
  }
  if(new != NULL){
    new->parent = old->parent;
  }

}


void 
rotateRight(rbnode* node, rbtree *root){
  rbnode *l  = node->left;

  replaceNode(root, node, l);
  
  node->left = l->right;

  if(l->right != NULL){
    l->right->parent = node;
  }
  l->right = node;
  node->parent = l;
}

void 
rotateLeft(rbnode* node, rbtree *root){
  rbnode *r = node->right;

  replaceNode(root, node, r);

  node->right = r->left;
  if(r->left != NULL){
    r->left->parent = node;
  }
  
  r->left = node;
  node->parent = r;

}


/*************************************************************************/

rbnode* 
getGrandparent(rbnode* node){
  if(node->parent == NULL){
    return NULL;
  }else{
    return node->parent->parent;
  }
}

rbnode* 
getUncle(rbnode* node){
  rbnode* gParent = getGrandparent(node);
  if(gParent == NULL){
    return NULL;
  }else if(gParent->left == node->parent){
    return gParent->right;
  }else{
    return gParent->left;
  }
}


#endif

