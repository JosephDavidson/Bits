#include "tape.h"
#include "tuples.h"

/*******************************************************************************/

typedef struct resultStruct{
  int halted;
  int steps;
}resultStruct;

typedef struct savedMachine{
  int states, symbols, nScores;
  tuple** symbolTable;
  int *scores;
} savedMachine;


/*******************************************************************************/

resultStruct* runTuringMachine(tuple** symbolTable,
                               cell *tape,
                               int stepLimit,
                               int debug);

resultStruct* resultStruct_new(int halted, int steps);

savedMachine* savedMachine_new(tuple** symbolTable,
                               int states,
                               int symbols,
                               int* scores,
                               int nScores);

void savedMachine_free(savedMachine *s);

void changeBest(savedMachine *bestMachine,
                tuple** symbolTable,
                int states,
                int symbols,
                int* newRecords,
                int numRecords);

void outputSavedMachine(savedMachine *m);

/*******************************************************************************/

resultStruct*
runTuringMachine(tuple** symbolTable, cell *tape, int stepLimit, int debug){
  int state,
      steps,
      halted,
      found;
  
  resultStruct *res = NULL;
  
  tuple *tup = NULL;

  halted = 0;
  state = 1;
  steps = 0;
  found = 0;

  if(debug){
    printSymbolTable(symbolTable, 3);
    printf("Start:\n");
    printTape(tape);
  }
 
  while(!halted && steps < stepLimit){
    steps += 1;
    tup = symbolTable[state];

    while(found == 0){

      if(tup == NULL){
        break;   
      }
      else if(tape->symbol == tup->rSymb){
        found = 1;
      }else{
        tup = tup->next;
      }
    }

    if(found == 0){
      printf("No transition found for symbol %c in state %d\n",
              tape->symbol, state);
      halted = 1;
    }
    state = tup->newState;
    tape->symbol = tup->wSymb;

    if(tup->dir == 'L'){
      if(tape->left == NULL){
        tape->left = cell_new('0');
        tape->left->right = tape;
      }
      tape = tape->left;
    }else{
      if(tape->right == NULL){
        tape->right = cell_new('0');
        tape->right->left = tape;
      }
      tape = tape->right;
    }

    if(state == 0){
      halted = 1;
    }
    if(debug){
      printTape(tape);
    }     

    found = 0;
    tup = NULL;
  }

  if(debug){
    printf("Finish:\n");
  }

  return resultStruct_new(halted, steps);
}

/**************************************************************************/

resultStruct*
resultStruct_new(int halted, int steps){
  resultStruct *r;
  r = malloc(sizeof(resultStruct));
  r->halted = halted;
  r->steps = steps;
  return r;
}

/**************************************************************************/

savedMachine*
savedMachine_new(tuple** symbolTable, int states,
                 int symbols, int* scores, int nScores){
  savedMachine *s;

  s = malloc(sizeof(savedMachine));
  s->symbolTable = symbolTable;
  s->states = states;
  s->symbols = symbols;
  s->nScores = nScores;
  s->scores = malloc(sizeof(int) * nScores);
  memcpy(s->scores, scores, sizeof(int) * nScores);

  return s;
}


/**************************************************************************/
void
savedMachine_free(savedMachine *s){
  freeSymbolTable(s->symbolTable, s->states);
  free(s->scores);
  free(s);
}

/*************************************************************************/

void
changeBest(savedMachine *bestMachine, tuple** symbolTable,
           int states, int symbols, int* newRecords, int numRecords){

  savedMachine_free(bestMachine);
  bestMachine = savedMachine_new(symbolTable,
                                 states, symbols, newRecords, numRecords);
}

/**************************************************************************/

void
outputSavedMachine(savedMachine *m){
  int i;

  printf("Saved Machine:\n---\n");
  printf("States: %d, Symbols: %d, Tests Run: %d\n",
          m->states, m->symbols, m->nScores);
  printSymbolTable(m->symbolTable, m->states);
  printf("---\n");
  for(i = 0;i < m->nScores;i++){
    printf("Test %d -> %d shifts\n",i, m->scores[i]);
  }

}

/**************************************************************************/
