#ifndef GENERAL_SUPPORT_GUARD
#define GENERAL_SUPPORT_GUARD

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
  char **array;
  int length;

} tokeniser_r;

void* xmalloc(const size_t size);
void debug(const char *format, ...);
void error(const char *format, ...);
tokeniser_r* tokenise(char* string, char split);
void tokeniser_free(tokeniser_r *t);


// it cant pull out the first token
tokeniser_r*
tokenise(char *string, char split){
  int i,
      count,
      length,
      tokenSize,
      x;

  tokeniser_r *t;

  char *s;

  printf("Tokenising: %s using %c\n",string, split);

  t = xmalloc(sizeof(tokeniser_r));
  
  length = strlen(string);
  count = 1;

  for(i=0;i<length;i++){
    if(string[i] == split){
      string[i] = '\0';
      count++;
    }
  }
 
  x = 0;

  printf("length is %d\n", length);
  printf("number of tokens is %d\n", count);  

  t->array = xmalloc(sizeof(char) * count);
  t->length = count;

  for(i=0;i<count;i++){
    tokenSize = strlen(&string[x]) + 1;
       
    printf("size of token %d is %d\n", i, tokenSize);
    t->array[i] = xmalloc(sizeof(char) * tokenSize);
    //>array[i][tokenSize -1] = '\0';
    printf("token is %s\n",&string[x]);
    memcpy(t->array[i],&string[x],sizeof(char) * (tokenSize));
    
    x += tokenSize;
  }

  return t;
}


void tokeniser_free(tokeniser_r *t){
  int i;

  for(i=0;i< t->length; i++){
    free(t->array[i]);
  }

  free(t->array);
  free(t);

}


void*
xmalloc(const size_t size){

  void *mem;

  if(!size){
    error("xmalloc(), Could not allocate memory of size 0!\n");
    exit(EXIT_FAILURE);
  }

  
  mem = NULL;
  mem = malloc(size);

  if(!mem){
    error("xmalloc():, Could not allocate memory!\n");
    exit(EXIT_FAILURE);
  }

  return mem;

}

/*****************************************************************************/

#ifdef _DEBUG_
void
debug(const char *format, ...){

  va_list args;

  va_start(args, format);
  fprintf(stderr, "DEBUG: ");
  vfprintf(stderr, format, args);
  va_end(args);

}
#else
void debug(const char *format, ...){}
#endif

/*****************************************************************************/
void
error(const char *format, ...){

  va_list args;

  va_start(args, format);
  fprintf(stderr, "ERROR: ");
  vfprintf(stderr, format, args);
  va_end(args);

}


#endif
