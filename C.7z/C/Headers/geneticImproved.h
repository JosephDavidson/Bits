#ifndef GENETIC_IMPROVED_GUARD
#define GENETIC_IMPROVED_GUARD

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

#include<generalSupport.h>
#include<extraMath.h>
#include<raspMachineTCL.h>

#define _DEBUG_

machine** initalisePool(int popSize, 
                        int memSize, 
                        int numInstr,
                        int PCadd,
                        int IRadd,
                        int ACCadd);
  
machine** initalisePoolSeeded(int popSize, 
                              machine* seed, 
                              int memSize, 
                              int numInstr,
                              int PCadd,
                              int IRadd,
                              int ACCadd);

machine* generateMachine(int memSize, int numInstr, 
                         int PCadd, int IRadd, int ACCadd);

int* generateProgram(int memSize);
int* generateInstructionSet(int numInstr, int limit);

int calcFitness(machine* mach);

machine** rouletteSelection(machine** population, int popSize, int keepSize);

machine** randSelection(machine** population, int popSize, int keepSize);

void advanceGeneration(machine** population,
                       int popSize,
                       int keepSize,
                       int debugNum,
                       int sorted);


void advanceGenerationSeeded(machine** population,
                             machine* seed,
                             int popSize,
                             int keepSize,
                             int debugNum,
                             int sorted);


void repopulate(machine** population, 
                int popSize, 
                int keepSize); 


int* crossoverIset(machine* parent1, machine* parent2);
int* crossoverProgram(machine* parent1, machine* parent2);


int* mutateProgram(int* program, int memSize);
int* mutateInstructionSet(int* iSet, int numInstr, int memSize);

machine* storeBest(machine *mach, machine *topMachine);

/**************************************************************************/
machine**
initalisePool(int popSize, int memSize, int numInstr,
              int PCadd, int IRadd, int ACCadd){

  int i;

  machine** population;

  population = xmalloc(sizeof(machine*) * popSize);

//  printf("init pool\n");

  
  for(i=0 ;i < popSize; i++){
    population[i] = generateMachine(memSize, numInstr, PCadd, IRadd, ACCadd);
  }
   
  return population;

}

/**************************************************************************/

machine**
initalisePoolSeeded(int popSize, machine* seed, int memSize, int numInstr,
                    int PCadd, int IRadd, int ACCadd){

  int i,
      cross,
      *program1,
      *program2;

  machine  **population,
           *mach;

  population = xmalloc(sizeof(machine*) * popSize);


  if(memSize != seed->memSize){
    // Our seed isn't the same size as our machine so we have to be clever 
    cross = floor(popSize / 5);
  

    for(i=0;i<cross-1;i = i+2){
      mach =  generateMachine(memSize, numInstr, PCadd, IRadd, ACCadd);

      program1 = crossoverProgram(seed, mach);
      program2 = crossoverProgram(mach, seed);
     
      population[i] = machine_new(memSize, numInstr, PCadd, IRadd, ACCadd); 
      population[i+1] = machine_new(memSize, numInstr, PCadd, IRadd, ACCadd);

      initProgram(program1, population[i]);
      initProgram(program2, population[i+1]);
      initInstructionSet(seed->instructionSet, population[i]);
      initInstructionSet(seed->instructionSet, population[i+1]);
    
      machine_free(mach);
      free(program1);
      free(program2);

    } 

    // fill in the rest
    for(i=cross ;i < popSize; i++){
      population[i] = generateMachine(memSize, numInstr, PCadd, IRadd, ACCadd);
    }

  }else{
   
    population[0] = seed;

    for(i=1 ;i < popSize; i++){
      population[i] = generateMachine(memSize, numInstr, PCadd, IRadd, ACCadd);
    }

  }  

  return population;

}

/**************************************************************************/

machine*
generateMachine(int memSize, int numInstr, int PCadd, int IRadd, int ACCadd){

  /*The machine*/
  machine* mach;

  /* Declare and generate our Iset and program */ 
  int *instructionSet,
      *program;

  program = generateProgram(memSize);
  instructionSet = generateInstructionSet(numInstr, memSize);

  mach = machine_new(memSize, numInstr, PCadd, IRadd, ACCadd );

  initInstructionSet(instructionSet, mach);

  initProgram(program, mach);

  /* Free the Iset and program as the assignment functions
     copies the values of the array. */
  free(program);
  free(instructionSet);

  return mach;
}

/**************************************************************************/
int*
generateProgram(int memSize){
 
  int* prog,
       i;

  prog = xmalloc(sizeof(int) * memSize);

  for(i = 0;i< memSize;i++){
    prog[i] = randint(0, memSize - 1);
  }

  return prog;
}

/**************************************************************************/
int*
generateInstructionSet(int numInstr, int limit){

/* Generate an instruction set of numInstr,
   with exactly one of the integers 0 - numInstr -1
   with no repeats */

   int *iSet,
       *used,
       index,
       i;

   iSet = xmalloc(sizeof(int) * numInstr);
   used = xmalloc(sizeof(int) * limit);

   memset(used, 0, sizeof(int) * limit);

   for(i = 0; i < numInstr; i++){
     index = randint(0, limit - 1);    
      
     while(used[index] == 1){
       index = randint(0, limit -1);
     }

     iSet[i] = index;
     used[index] = 1;
   }

   if(!unique(iSet, numInstr)){
     printf("ERROR: iSet not unique.\n");
     for(i = 0; i< numInstr;i++){
       printf("%d ", iSet[i]);
     }
     printf("\n");
     exit(0);
   }

   free(used);
   return iSet;

}

/**************************************************************************/
int
calcFitness(machine* mach){
 if(mach->progState->halted == 0){
   return 0;
 }
 return mach->progState->outputCount;
}

/**************************************************************************/
void
advanceGeneration(machine** population,
                            int popSize,
                            int keepSize,
                            int debugNum,
                            int sorted){

  int i;


  machine** saved;

  programState *ps;

  /* Select our group to save. */ 
  saved = rouletteSelection(population, popSize, keepSize);
  
 /* for(i = 0;i < keepSize;i++){
    if(saved[i] != NULL){
      printf("%d: Machine. %d\n",i, calcFitness(saved[i]));
    }else{
      printf("%d: NULL.\n",i);
    }
  }
 */

  /* Kill off the rest of the population*/
  for(i = 0;i < popSize; i++){
    if(population[i] != NULL){
       machine_free(population[i]);
       population[i] = NULL;
    }
  } 


  /* Put the saved lot back in the pool */
  for(i = 0; i <keepSize;i++ ){
    population[i] = saved[i];
    saved[i] = NULL;
  }

  free(saved); 

  printf("Repopulating\n"); 
  /* repopulate the pool */
  repopulate(population, popSize, keepSize);

  /* Reset all the machines */

  for(i = 0; i < keepSize; i++){
    ps = population[i]->progState;
    initProgram(ps->program, population[i]);
    programstate_free(ps);
  }

}

/**************************************************************************/

void advanceGenerationSeeded(machine** population,
                             machine* seed,
                             int popSize,
                             int keepSize,
                             int debugNum,
                             int sorted){
    programState *ps;

    /* Advance generation as usual */
    advanceGeneration(population, popSize, keepSize, debugNum, sorted);

    /* Reset the seed */ 
    ps = seed->progState;
    initProgram(ps->program, seed);
    programstate_free(ps);

    /* Replace first child with seeded machine */
    machine_free(population[keepSize]);
    population[keepSize] = seed;

    seed = NULL;

}

/**************************************************************************/

machine**
rouletteSelection(machine** population, int popSize, int keepSize){

  int i,
      x,
      sumFitness,
      max,
      maxVal,
      tmp;

  float ran,
        partsum;

  machine** keeping;
 
  keeping = xmalloc(sizeof(machine*) * keepSize);

  sumFitness = 0;  
  max = 0;
  maxVal = calcFitness(population[0]);

  for(i = 0; i < popSize; i++){
    if(population[i] != NULL){
      tmp =calcFitness(population[i]);
      if( tmp > maxVal){
        maxVal = tmp;
        max = i;
      }
      sumFitness += tmp;
    }
  }
  keeping[0] = population[max];
  population[max] = NULL; 


  for(x = 1;x < keepSize; x++){
    
    ran = (float)rand()/(float)RAND_MAX * sumFitness; 
    partsum = 0.0;
    i = 0;
    while(partsum < ran){
      if(population[i] != NULL){
        partsum += (float) calcFitness(population[i]);
      }
      i= (i+1) % popSize;
    }
    while(population[i] == NULL){
      i = (i+1) % popSize;
    }
    keeping[x] = population[i];
    population[i] = NULL;
  }
  return keeping;
}


/**************************************************************************/
void
repopulate(machine** population, int popSize, int keepSize){ 
  
  int i,
      parent1,
      parent2,
      dice,
      memSize,
      numInstr,
      PCadd,
      IRadd,
      ACCadd,
      dominantParent,
      *program,
      *iSet;

 // printf("Repopulating\n");

  program = NULL;
  iSet = NULL;  

  for(i = keepSize; i < popSize;i++){
   
  //  printf("i = %d\n", i); 
    parent1 = randint(0, keepSize - 1);
    parent2 = randint(0, keepSize - 1);

    memSize = population[parent1]->memSize;
    numInstr = population[parent1]->numInstr;
    PCadd = population[parent1]->pcAddress;
    IRadd = population[parent1]->irAddress;
    ACCadd = population[parent1]->accAddress;

    dice = randint(1, 6);
  //  printf("parent1: %d, parent2: %d\n",parent1, parent2);


  //  debugMachine(stderr, population[parent1], memSize, numInstr);
  //  debugMachine(stderr, population[parent2], memSize, numInstr); 

    if(dice == 1 || dice == 2){
      /* We crossover over the Iset only */
   //   printf("Cross iset\n");
      dominantParent = randint(0, 20) % 2;
      iSet = crossoverIset(population[parent1], 
                         population[parent2]); 
    //  printf("After iset cross\n");
      program = xmalloc(sizeof(int) * memSize - 3);
 
      if(dominantParent == 0){
        dominantParent = parent1;
      }else{
        dominantParent = parent2;
      }

      memcpy(program,
             population[dominantParent]->progState->program,
             sizeof(int) * memSize - 3);

    }else if(dice == 3 || dice == 4){
      /* We crossover the Program only */
   //   printf("Cross program\n");
      dominantParent = randint(0, 20) % 2;
      program = crossoverProgram(population[parent1],
                                 population[parent2]);

      iSet = xmalloc(sizeof(int) * numInstr);

      if(dominantParent == 0){
        dominantParent = parent1;
      }else{
        dominantParent = parent2;
      }

      memcpy(iSet, population[dominantParent]->instructionSet,
                                              sizeof(int) * numInstr);
 
    }else if(dice == 5 || dice == 6){
   //   printf("Both cross\n");
      /* We crossover the Iset and Program */
      iSet = crossoverIset(population[parent1], 
                           population[parent2]); 

      program = crossoverProgram(population[parent1],
                                 population[parent2]);

    }
  //  printf("new child\n");
    dice = randint(1,6);

  //  printf("Mutation!\n");

    if(dice == 1 || dice == 2){
      /* Mutate instruction set */
      iSet = mutateInstructionSet(iSet, numInstr, memSize);
    }else if(dice == 3 || dice == 4){
      /* Mutate program */
      program = mutateProgram(program, memSize);
    }
   


    /* Create the new child */
    population[i] = machine_new(memSize, numInstr, PCadd, IRadd, ACCadd); 
    initInstructionSet(iSet, population[i]);
    initProgram(program, population[i]);

  free(iSet);
  free(program);


  }

    printf("End of repopulation\n");
}

/**************************************************************************/
int*
crossoverIset(machine* parent1, machine* parent2){
  /* Returns a crossed instruction set with 
     the uniqueness constraint active */

  int crossPoint,
      i,
      *returnIset,
      *iCount,
      target,
      ms,
      numInstr,
      replace;

  numInstr = parent1->numInstr;
  crossPoint = randint(0, numInstr);

 // printf("allocing\n");
  
  if(parent1->memSize > parent2->memSize){
    ms = parent1->memSize;
  }else{
    ms = parent2->memSize;
  }
 
  returnIset = xmalloc(sizeof(int) * numInstr);
  iCount = xmalloc(sizeof(int) * ms);

  memset(iCount, 0, sizeof(int) * ms);


  //printf("crossing\n");
  for(i = 0; i< crossPoint; i++){
    returnIset[i] = parent1->instructionSet[i];
  }

 
  for(i = crossPoint; i< numInstr; i++){
    returnIset[i] = parent2->instructionSet[i];
  }

  for(i = 0; i < numInstr;i++){
    iCount[returnIset[i]] += 1;
  }


  while(unique(returnIset, numInstr) == 0){
    /* Find a instruction we have >1 times in the iSet. 
       and an instruction we have 0 times in the iSet.*/
    target = -1;
    replace = -1;
    i = 0;
    while(target == -1 || replace == -1){
      if(iCount[i] > 1){
        target = i;
      }
      if(iCount[i] == 0){
        replace = i;
      }
      i += 1;
    }
   // printf("target = %d\n",target);
   // printf("replace = %d\n", replace);
    /* Find first occurence of the duplicated instruction and
       replace it with the other one. */

    for(i = 0; i< numInstr; i++){
      if(returnIset[i] == target){
        returnIset[i] = replace;
        iCount[target] =- 1;
        iCount[replace] += 1;
        break;
      }
    }

  }

  free(iCount);

 /* printf("Sanitised iset:");
    for(i=0;i<numInstr;i++){
      printf(" %d", returnIset[i]);
    }
    printf("\n");*/
  return returnIset;
}
/**************************************************************************/
int*
crossoverProgram(machine* parent1, machine* parent2){

  int crossPoint,
      ms,
      smaller,
      diffFlag,
      *returnProgram,
      i;

//  printf("programCross\n");

  
  if(parent1->memSize > parent2->memSize){
    ms = parent1->memSize;
    smaller = parent2->memSize;
    diffFlag = 1;
  }else{
    ms = parent2->memSize;
    smaller = parent1->memSize;
    diffFlag = 0;
  }

  crossPoint = randint(0, smaller - 3);
  returnProgram = xmalloc(sizeof(int) * ms - 3);

  for(i = 0; i < crossPoint; i++){
    returnProgram[i] = parent1->progState->program[i];
  }

  if(parent2->memSize == smaller){
    for(i = crossPoint; i < smaller -3; i++){
      returnProgram[i] = parent2->progState->program[i];
    }
    for(i = smaller - 3; i < ms - 3; i++){
      returnProgram[i] = randint(0, ms-1);
    }
  }else{
    for(i = crossPoint; i < ms -3; i++){
      returnProgram[i] = parent2->progState->program[i];
    }

  }


  return returnProgram;

}
/**************************************************************************/
machine**
randSelection(machine** population, int popSize, int keepSize){

  machine** saved;

  int i,
      m;

  saved = xmalloc(sizeof(machine*) * keepSize);

  for(i = 0;i < keepSize; i++){
    m = randint(0, popSize - 1);
    while(population[m] == NULL){
      m = randint(0, popSize -1);
    }
    saved[i] = population[m]; 
    population[m] = NULL;
  }

  return saved;
}

/**************************************************************************/
int*
mutateInstructionSet(int* iSet, int numInstr, int memSize){
  int i,
      found,
      sub,
      s1,
      s2,
      temp;

  sub = randint(0, memSize - 1);
  found = 0;


  for(i =0;i<numInstr; i++){
    if(iSet[i] == sub){
      found = 1;
      break;
    } 
  }

  if(found){
    s1 = randint(0, numInstr - 1);
    s2 = s1;
    while(s2 == s1){
      s2 = randint(0, numInstr -1);
    }

    temp = iSet[s1];
    iSet[s1] = iSet[s2];
    iSet[s2] = temp;
  } else { 
    s1 = randint(0, numInstr - 1);
    iSet[s1] = sub;
  }


  return iSet;

}

/**************************************************************************/
int*
mutateProgram(int* program, int memSize){
  int loc,
      times,
      i;

  times = randint(1, memSize/2);

  for(i = 0; i < times;i++){
    loc = randint(3, memSize - 1);
    program[loc] = randint(0, memSize - 1);
  }
  
  return program;
}
/**************************************************************************/

machine*
storeBest(machine *mach, machine *topMachine){

 if(topMachine == NULL ||
    (topMachine->progState->outputCount < mach->progState->outputCount &&
    mach->progState->halted != 0 &&
    mach->progState->halted != 2)){

    printf("new topMachine\n");
     if(topMachine != NULL){
       machine_free(topMachine);
     }


     topMachine = machine_deepcopy(mach);
  
  }

  return topMachine;
  
}

/**************************************************************************/

#endif
