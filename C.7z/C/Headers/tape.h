#ifndef TAPE_H_GUARD
#define TAPE_H_GUARD


#define PRINT_DIAMETER       200
#define MAX_TAPES            10


typedef struct cell{
  struct cell *left;
  struct cell *right;
  char symbol;
}cell;

/******************************************************************************/

cell* cell_new(char ch);
void cell_free(cell *c);
void cfr(cell *c);
void cfl(cell *c);
void printTape(cell *c);
cell** getTapes(FILE *fp);
int  equalTapes(cell *tape1, cell *tape2, int debug);

/******************************************************************************/

cell*
cell_new(char ch){
  cell *c = malloc(sizeof(cell));
  c->left = NULL;
  c->right = NULL;
  c->symbol = ch; 
  return c;
}


/******************************************************************************/

void
cell_free(cell *c){
  if(c->right != NULL){
    cfr(c->right);
  }
  if(c->left != NULL){
    cfl(c->left);
  }
  free(c);  
}

/******************************************************************************/

void
cfr(cell *c){
  if(c->right != NULL){
    cfr(c->right);
  }
  free(c);
}

/******************************************************************************/

void
cfl(cell *c){
  if(c->left != NULL){
    cfl(c->left);
  }
  free(c);
}

/******************************************************************************/

void
printTape(cell *c){
  int i;
  cell *d;

  char left,
       right;
  
  left = right = ' ';
  
  d = c;
  while(i < PRINT_DIAMETER && d->left != NULL){
    d = d->left;
    i++;
  }
  i = 0;
  while(i < PRINT_DIAMETER * 2 && d != NULL){
    if(d == c){
      left = '{';
      right = '}'; 
    }
    printf("%c%c%c", left, d->symbol, right);
    left = ' ';
    right = ' '; 
    d = d->right;
    i++;
  }
  printf("\n");

}

/******************************************************************************/

cell** getTapes(FILE *fp){
  cell **tapes,
       *tape,
       *cel;

  int start,
      i;

  char c;

  tapes = malloc(sizeof(cell*) * MAX_TAPES);
  for(i = 0;i< MAX_TAPES; i++){
    tapes[i] = NULL;
  }

  start = 0;
  i = 0;
  tape = NULL;
  cel = NULL;

  c = (char) fgetc(fp);
  while(c != EOF){
    switch(c){
      case ';':
        c = (char) fgetc(fp);
        if(tape == NULL){
          printf("No start marker found, assuming LHS\n");
          while(cel->left != NULL){
            cel = cel->left;
          }
          tape = cel; 
        }
       // printTape(tape);
        tapes[i] = tape;
        i++;
        tape = NULL;
        cel = NULL; 
        break;
      case '^':
        start = 1;
        c = (char) fgetc(fp);
      default :
        if(cel == NULL){
          cel = cell_new(c);
        }else{
          cel->right = cell_new(c);
          cel->right->left = cel;
          cel = cel->right; 
        }

        if(start){
          tape = cel; 
          start = 0;
        }
    }
    c = (char) fgetc(fp);
  }
  return tapes;
}

/******************************************************************************/

void
copyTapes(cell* tape, cell* master){

  cell *t,
       *x;

  t = master;
  x = tape;

  x->symbol  = t->symbol;

  while(t->left != NULL){
    x->left = cell_new(t->left->symbol);
    x->left->right = x;
    x = x->left;
    t = t->left;
  } 
 
  t = master;
  x = tape;  

  while(t->right != NULL){
    x->right = cell_new(t->right->symbol);
    x->right->left = x;
    x = x->right;
    t = t->right;
  }
  
}

/******************************************************************************/

int
equalTapes(cell *tape1, cell *tape2, int debug){
  cell *t1,
       *t2;


  t1 = tape1;
  t2 = tape2;


  if(debug){
    printf("Equalling\n");
    printTape(t1);
    printTape(t2);
  }
  while(t1->left != NULL){
    t1 = t1->left;
  }
  while(t2->left != NULL){
    t2 = t2->left;
  }


  while(t1 != NULL && t2 != NULL){
    if(t1->symbol != t2->symbol){
      if(debug)
        printf("failed\n");
      return 0;
    }
    if(debug)
      printf("Equal Symbol %c == %c \n", t1->symbol, t2->symbol);
    t1 = t1->right;
    t2 = t2->right;
  }
  if(t2 != t1){
    if(debug)
      printf("failed\n");
    return 0;
  }
  
    if(debug)
      printf("pass\n");
  return 1;

}


#endif
