
#ifndef TUPLE_H_GUARD
#define TUPLE_H_GUARD

#include<stdlib.h>

#define MAX_STATES_READ     30

#define DIRLET(d) ((d == 0) ? 'L' : 'R')

typedef struct tuple{
  int state;
  int newState;
  char rSymb,
       wSymb,
       dir;
  struct  tuple *next;  
}tuple;


tuple* tuple_new( int state, char rSymb,
                 int newState, char nSymb, char dir);
void tuple_free(tuple* t);
tuple** createSymbolTable(int** ts, int nTuples, int nStates);
void insertTuple(tuple** tuples, tuple *t);
void printSymbolTable(tuple** tuples, int nStates);
void freeSymbolTable(tuple** tuples, int nStates);
tuple** readSymbolTable(FILE *fp);

/********************************************************************/

tuple* 
tuple_new( int state, char rSymb, int newState, char nSymb, char dir){

  tuple *t;

  t = malloc(sizeof(tuple));
  t->state = state;
  t->newState = newState;
  t->rSymb = rSymb;
  t->wSymb = nSymb;
  t->dir = dir;
  t->next = NULL;

  return t;

}

void 
tuple_free(tuple* t){
  if(t->next != NULL){
    tuple_free(t->next);
  }
  free(t);
}

tuple** 
createSymbolTable(int** ts, int nTuples, int nStates){

   int i;

   tuple **table;

  char *s1,
       *s2;

  nStates += 1;

  s1 = malloc(sizeof(char) * 2);
  s2 = malloc(sizeof(char) * 2);  

   table = malloc(sizeof(tuple*) * nStates);
   for(i = 0; i < nStates; i++){
     table[i] = NULL;
   } 
   
   for(i = 0; i < nTuples; i++ ){
     sprintf(s1,"%d",ts[i][1]);
     sprintf(s2,"%d",ts[i][3]);
     insertTuple(table, tuple_new(ts[i][0],s1[0],
                                  ts[i][2],s2[0],
                                  DIRLET(ts[i][4])));

   }
   free(s1);
   free(s2);
   return table;
}

void insertTuple(tuple** tuples, tuple *t){
  
  tuple *x = tuples[t->state];

  if(x == NULL){
    tuples[t->state] = t;
    return;
  }
 
  while(1){
    if(x->next == NULL){
      x->next = t;
      return;
    }

    if(x->rSymb == t->rSymb){
      x->dir = t->dir;
      x->wSymb = t->wSymb;
      x->newState = t->newState;
      tuple_free(t);
      return;
    }
    x = x->next;
  }
}

void
printSymbolTable(tuple** tuples, int nStates ){
  int i;

  tuple *tup;

  printf("---\n");
  for(i = 0;i <= nStates; i++){
    tup = tuples[i];
    while(tup != NULL){
      printf("(%d, %c, %d, %c, %c)\n",
             tup->state, tup->rSymb,
             tup->newState, tup->wSymb, tup->dir);
      tup = tup->next;
    }    

  }
  printf("\n");

}

void
freeSymbolTable(tuple** tuples, int nStates){
  int i;
  
  for(i=0; i <= nStates; i++){
    if(tuples[i] != NULL){
      tuple_free(tuples[i]);
    }
  }
  free(tuples);
}


tuple**
readSymbolTable(FILE *fp){

  tuple **table;
 
  tuple *t;
   
  int state,
      newstate,
      tups;
     
  char symbol,
       newsymbol,
       dir;
  
  table = malloc(sizeof(tuple*) * MAX_STATES_READ);
  for(tups = 0; tups < MAX_STATES_READ; tups++){
    table[tups] = NULL;
  }

  tups = 0;
  while(fscanf(fp,"%d,%c,%d,%c,%c\n",&state, &symbol, &newstate, &newsymbol, &dir) != EOF){
    if(tups >= MAX_STATES_READ){
      fprintf(stderr, "Error: too mny states to be read in. Current max is %d\n",
              MAX_STATES_READ);
      break;
    }
    //printf("Read in (%d,%c,%d,%c,%c)\n", state, symbol, newstate, newsymbol, dir);
    insertTuple(table, tuple_new(state,symbol,newstate, newsymbol, dir));
    tups++;
  }

  return table;
}

#endif
