#ifndef RASP_MACHINE_GUARD
#define RASP_MACHINE_GUARD

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <gmp.h>


#include <generalSupport.h>
#include <arraySupport.h>
#include <bases.h>
#include <rbTree.h>


typedef struct{
  int halted;
  long long int stepsRun;
  int outputCount;
  int *processMemory;
  int *program;
  int *outputs;
} programState;


typedef struct{
  programState *progState;
  int *memory;
  int *instructionSet;
  int numInstr;
  int pcAddress;
  int irAddress;
  int accAddress;
  int memSize;
} machine;


typedef struct valueStruct{
  mpz_t value;
} valueStruct;

/* Set up machine */
void initProgram(int *program, machine *mach);
void initInstructionSet(int *is, machine *mach);

/* Running a machine */

void runMachine(machine *mach, int stepLimit, int trace);

void runMachineHalting(machine *mach, int trace);


void fetch(machine *mach);
int execute(machine *mach, int trace);


int* decodeFromStateEnum(mpz_t value, int memSize);
void calculateStateEnum(machine *mach, mpz_t retVal);

/* Constructors / Deconstructors */
machine* machine_new(int memsize, int inssize, int pcAdd,
                     int irAdd, int accAdd);
void     machine_free(machine *m);

programState* programstate_new(int halted, int *instr, int memorySize);
void          programstate_free(programState *p);

machine* machine_deepcopy(machine* mach);
programState* programstate_deepcopy(programState *ps, int memSize);

//machine * readMachineFromFile(FILE *fp);

/* Misc Halting */
rbnode* node_new();
void valueStruct_free(void* i);
int compareValueStruct(void* a, void* b);

/* Debugging */
void debugMachine(FILE *fp, machine *mach);
void debugProgramState(FILE *fp, programState *ps, int memorySize);

machine* convertMachine(machine *mach, int *iSet, int *data, int dataSize,
                                                    int memSize, int numInstr);

/*  I/O */
void writeMachineToFile(FILE *fp, machine* mach);
machine* readMachineFromFile(FILE *fp);

/*****************************************************************************/

void
initProgram(int *program, machine *mach){
  int i,
      memorySize;

  memorySize = mach->memSize;

  /* set the first 3 memory locations*/
  mach->memory[mach->pcAddress] = 3;
  mach->memory[mach->irAddress] = 0;
  mach->memory[mach->accAddress] = 0;
  for(i = 3; i < memorySize; i++){
    mach->memory[i] = program[i-3];
  }

  mach->progState = programstate_new(0, program, memorySize);
}

/*****************************************************************************/

void
initInstructionSet(int *is, machine *mach){
  memcpy(mach->instructionSet, is, sizeof(int) * mach->numInstr);
}

/*****************************************************************************/

void
runMachine(machine *mach, int stepLimit, int trace){

  int i,   
      halted = 0,
      memorySize,
      numInstr,
      PCadd,
      IRadd,
      ACCadd;

  memorySize = mach->memSize;
  numInstr = mach->numInstr;
  PCadd = mach->pcAddress;
  IRadd = mach->irAddress;
  ACCadd = mach->accAddress;

  mach->progState->outputCount = 0;
  for(i = 0; i <= stepLimit; i++){
    fetch(mach);
    halted = execute(mach, trace);
    if(halted == 1 || halted == -1){
      break;
    }
  }

  /* Write our data back into the struct. */
  mach->progState->halted = halted;
  mach->progState->stepsRun = i;
  memcpy(mach->progState->processMemory,
         mach->memory, sizeof(int) * memorySize );

}


/*****************************************************************************/

void
runMachineHalting(machine *mach, int trace){

  int i,
      halted,
      memorySize,
      numInstr,
      PCadd,
      IRadd,
      ACCadd;

  rbnode *target;
  rbtree *root;

  valueStruct *v;



  root = rbtree_new();

  halted = 0;
  i = 0;

  memorySize = mach->memSize;
  numInstr = mach->numInstr;
  PCadd = mach->pcAddress;
  IRadd = mach->irAddress;
  ACCadd = mach->accAddress;

  while(halted == 0){

    i++;
    /* Run the program for an instruction */
    fetch(mach);
    halted = execute(mach, trace);

    /* Calculate state enumeration */
    target = node_new();
    v = (valueStruct*) target->value;
    calculateStateEnum(mach, v->value);

    if(rbSearch(root->root, target, &compareValueStruct ) == NULL){
      rbInsert(root, target, &compareValueStruct);
      target = NULL;
    }else {
      halted = 0;
      break;
    }

    if(halted == 1 || halted == -1){
      break;
    }


  }

  /* Write our data back into the struct. */
  mach->progState->halted = halted;
  mach->progState->stepsRun = i;
  memcpy(mach->progState->processMemory,
         mach->memory, sizeof(int) * memorySize );

  rbnode_free(target, &valueStruct_free);
  rbDeleteTree(root->root, &valueStruct_free);
  free(root);
}


/*****************************************************************************/
void
fetch(machine *mach){
  if(mach->memory[mach->pcAddress] >= mach->memSize ||
     mach->memory[mach->pcAddress] < 0){
       mach->memory[mach->irAddress] = -1;
  } else {
    mach->memory[mach->irAddress] = mach->memory[mach->memory[mach->pcAddress]];
  }
}
/*****************************************************************************/

int
execute(machine *mach,
        int trace){

  int instruction,
      memorySize = mach->memSize,
      numInstr = mach->numInstr,
      pc = mach->pcAddress,
      ir = mach->irAddress,
      acc = mach->accAddress;

  instruction = lookup(mach->instructionSet,
                       mach->memory[ir],
                       numInstr);

  if(instruction == -1){
    if(trace){
       fprintf(stdout,"Instruction not found - looking for %d\n",
                                                      mach->memory[ir]);
       fprintf(stdout, "halt due to unrecognised instruction\n");
    }
    return -1;
  }

  switch(instruction){

  case 1: /* increment */
   if(trace)
     fprintf(stderr, "Add ");

   mach->memory[pc]++;
   if(mach->memory[pc] == memorySize ){
     mach->memory[pc] = 0;
   }
   fetch(mach);
   if(trace)   
     fprintf(stderr, "%d to %d \n\t",mach->memory[mach->memory[ir]],mach->memory[acc]);
   mach->memory[acc]+= mach->memory[mach->memory[ir]];

   if(mach->memory[acc] >= memorySize){
     mach->memory[acc] = mach->memory[acc] - memorySize;
   } 
   break;

  case 2: /* decrement */
    if(trace)
      fprintf(stderr, "subtract ");
     
    mach->memory[pc]++;
    if(mach->memory[pc] == memorySize ){
      mach->memory[pc] = 0;
    }
    fetch(mach);

   if(trace)   
     fprintf(stderr, "%d from %d \n\t",mach->memory[mach->memory[ir]],mach->memory[acc]);
    mach->memory[acc]-=mach->memory[mach->memory[ir]];

    if(mach->memory[acc] < 0){
      mach->memory[acc] = memorySize -(1+mach->memory[acc]);
    }
    break; 
 
  case 3: /* load */
    mach->memory[pc]++;
    if(mach->memory[pc] == memorySize ){
      mach->memory[pc] = 0;
    }
    fetch(mach);
    mach->memory[acc] = mach->memory[ir];
    if(trace)
      fprintf(stderr,"load %d\n\t", mach->memory[ir]);
    break;

  case 4: /* store */
    mach->memory[pc]++;
    if(mach->memory[pc] == memorySize ){
      mach->memory[pc] = 0;
    }
    fetch(mach);
    mach->memory[mach->memory[ir]] = mach->memory[acc];
    if(trace)
       fprintf(stderr,"store %d in %d\n\t",mach->memory[acc], mach->memory[ir]);
    break;

  case 5: /* output */
    /*printf("%d\n", mach->memory[acc]);*/
    mach->progState->outputs[mach->progState->outputCount++] =
         mach->memory[acc];
    mach->progState->outputs = realloc(mach->progState->outputs,
                                       sizeof(int) * mach->progState->outputCount + 1);
    mach->progState->outputs[mach->progState->outputCount] = -1;
    if(trace)
      fprintf(stderr,"output\n\t");
    break;

  case 6: /* jump if ACC > 0 */
    mach->memory[pc]++;
    if(mach->memory[pc] == memorySize ){
      mach->memory[pc] = 0;
    }
    fetch(mach);

    if(mach->memory[acc] > 0){
      if(trace){
        fprintf(stderr,"Jump to %d\n\t", mach->memory[ir]);
     //   outputArbitraryBaseNumber(stderr, mach->memory, memorySize);
      //  fprintf(stderr,"\t\tOutputCount: %d\n",
        //        mach->progState->outputCount);
      }

      mach->memory[pc] = mach->memory[ir];
      return 0;
    }
    break;
  case 7: /* CPY */
    mach->memory[pc]++;
    if(mach->memory[pc] == memorySize ){
      mach->memory[pc] = 0;
    }
    fetch(mach);

    mach->memory[acc] = mach->memory[mach->memory[ir]];

    if(trace){
      fprintf(stderr, 
              "Copy %d from location %d to ACC\n\t",
               mach->memory[mach->memory[ir]], mach->memory[ir]);
    }
    break;
  default: /* halt */
    if(trace)
      fprintf(stderr, "halt due to instruction\n");
    return 1;
  }

  if(trace){
   // outputArbitraryBaseNumber(stdout, mach->memory, memorySize);
   // printf("\t\tOutputCount: %d\n",mach->progState->outputCount);
  }

  mach->memory[pc]++;
  if(mach->memory[pc] == memorySize ){
    mach->memory[pc] = 0;
  }


  return 0;
}
/*****************************************************************************/

machine*
machine_new(int memsize, int inssize, int pcAdd, int irAdd, int accAdd){

  machine *m;

  m = xmalloc(sizeof(machine));

  m->memory         = xmalloc(sizeof(int) * memsize);
  m->instructionSet = xmalloc(sizeof(int) * inssize);
  m->memSize = memsize;
  m->pcAddress = pcAdd;
  m->accAddress = accAdd;
  m->irAddress = irAdd;
  m->numInstr = inssize;

  m->progState = NULL;
  return m;

}

/*****************************************************************************/

void
machine_free(machine *m){

  if(m == NULL){
    debug("machine_free(): m was NULL\n");
    return;
  }

  if(m->memory == NULL){
    debug("machine_free(): m->memory was NULL\n");
  }
  else{
    free(m->memory);
  }

  if(m->instructionSet == NULL){
    debug("machine_free(): m->instructionSet was NULL\n");
  }
  else{
    free(m->instructionSet);
  }
if(m->progState == NULL){
    debug("machine_free(): m->progState was NULL\n");
  }else{
    programstate_free(m->progState);
  }

  free(m);

}

/*****************************************************************************/
machine*
machine_deepcopy(machine* mach){

  machine *retMach;
  int memSize,
      insSize;


  if(mach == NULL){
    debug("machine_deepcopy(): machine to be cloned is NULL\n");
    return NULL;
  }
 
  memSize = mach->memSize;
  insSize = mach->numInstr;

  retMach = machine_new(memSize, insSize, mach->pcAddress,
                        mach->irAddress, mach->accAddress);
  
  memcpy(retMach->memory, mach->memory, sizeof(int) * memSize);
  memcpy(retMach->instructionSet, mach->instructionSet,sizeof(int) * insSize);


  if(mach->progState != NULL){
    retMach->progState = programstate_deepcopy(mach->progState, memSize);
  }
  
  return retMach;
}

/*****************************************************************************/

programState*
programstate_new(int halted, int *program, int memorySize){

  programState *p;

  p = xmalloc(sizeof(programState));

  p->processMemory = xmalloc(sizeof(int) * memorySize);
  p->halted = halted;
  p->program = xmalloc(sizeof(int) * memorySize - 3);
  p->stepsRun = 0;
  p->outputCount = 0;
  p->outputs = xmalloc(sizeof(int) * 1);

  memcpy(p->program, program, sizeof(int) * memorySize - 3);

  memset(p->processMemory, 0, sizeof(int) * memorySize);
  
  p->outputs[0] = -1;

  return p;

}

/*****************************************************************************/

void
programstate_free(programState *p){

  if(p == NULL){
    debug("programstate_free(): p is NULL\n");
    return;
  }

  if(p->processMemory == NULL){
    debug("programstate_free(): p->processMemory was NULL\n");
  }else{
    free(p->processMemory);
  }

  if(p->program != NULL){
    free(p->program);
  }
 
  free(p->outputs);

  free(p);

}

/*****************************************************************************/

programState*
programstate_deepcopy(programState *ps, int memSize){

  programState *returnState;

  if(ps == NULL){
    debug("programstate_deepcopy(): ps is NULL\n");
    return NULL;
  }

  returnState = programstate_new(ps->halted, ps->program, memSize);
 
  returnState->outputCount = ps->outputCount;
  returnState->stepsRun = ps->stepsRun;

  returnState->outputs = xmalloc(sizeof(int) * ps->outputCount+1);

  memcpy(returnState->outputs, ps->outputs, sizeof(int) * ps->outputCount+1);
  memcpy(returnState->processMemory, ps->processMemory, sizeof(int) * memSize);
  memcpy(returnState->program, ps->program, sizeof(int) * memSize -3);

  return returnState;

}

/*****************************************************************************/
void
debugMachine(FILE *fp, machine *mach){

 int i,
     instr,
     numInstr,
     memorySize;
     

  char *str;

  memorySize = mach->memSize;
  numInstr = mach->numInstr;

  fprintf(fp, "**MACHINE DEBUG**\n\n");
  fprintf(fp, "instructionSet:\n");
  for(i = 0; i < numInstr; i++){
    switch(i){
      case 0:
        fprintf(fp,"          halt");
        break;
      case 1:
        fprintf(fp,"     increment");
        break;
      case 2:
        fprintf(fp,"     decrement");
        break;
      case 3:
        fprintf(fp,"          load");
        break;
      case 4:
        fprintf(fp,"         store");
        break;
      case 5:
        fprintf(fp,"        output");
        break;
      case 6:
        fprintf(fp,"JMP if ACC > 0");
        break;
      case 7:
        fprintf(fp,"          copy");
        break;

    }
    fprintf(fp, " %d -> %d\n",mach->instructionSet[i], i);
  }
  fprintf(fp, "memory:\n");
  for(i=0;i<memorySize;i++){
    instr = lookup(mach->instructionSet,
                   mach->memory[i],
                   numInstr);
    switch(instr){
      case 0:
        str = "halt";
        break;
      case 1:
        str = "increment";
        break;
      case 2:
        str = "decrement";
        break;
      case 3:
        str = "load";
        break;
      case 4:
        str = "store";
        break;
      case 5:
        str = "output";
        break;
      case 6:
        str = "JMP if ACC > 0";
        break;
      case 7:
        str = "copy";
        break;
      default:
        str = "Memory Address";

    }
    fprintf(fp, "    %d -> %d:   %s\n", i, mach->memory[i], str);
  }
  if(mach->progState != NULL){
    debugProgramState(fp, mach->progState, memorySize);
  }else{
    fprintf(fp, "progState is NULL");
  }
  fprintf(fp,"/***********************************************/\n\n");

}

/*****************************************************************************/
void
debugProgramState(FILE *fp, programState *ps, int memorySize){

  int i;

  fprintf(fp, "PROGRAM DEBUG:\n");
  fprintf(fp,"  halted: %d\n",ps->halted);
  fprintf(fp,"  outputCount: %d\n",ps->outputCount);
  fprintf(fp,"  stepsRun: %lld\n", ps->stepsRun);
  fprintf(fp,"  program: ");
  outputArbitraryBaseNumber(fp, ps->program ,memorySize - 3);
  fprintf(fp,"\n  processMemory:\n");

  for(i=0;i<memorySize;i++){
    fprintf(fp, "    %d -> %d\n", i, ps->processMemory[i]);
  }
}



/*****************************************************************************/

machine*
convertMachine(machine *mach, int *iSet, int *data, int dataSize,
                                                    int memSize, int numInstr){
  /* Creates a new machine with the given iSet and converts the progstate
     to use the new iSet, with the exceptions of the locations provided
     by the data array. */
  int i,
      ins;

  machine *retMach;

  retMach = machine_deepcopy(mach);
  
  if(retMach->progState != NULL){
    if(retMach->progState->program != NULL){
      for(i = 0; i < memSize - 3; i++){
        if(retMach->progState->program[i] < numInstr  &&
          lookup(data,retMach->progState->program[i] ,dataSize) == -1){
            ins = retMach->progState->program[i]; 
            retMach->progState->program[i] 
            = iSet[lookup(retMach->instructionSet, ins, numInstr)];
        }     
      }
    }
  }
  
  initInstructionSet(iSet, retMach);

  return retMach;

}

/*****************************************************************************/
void
calculateStateEnum(machine *mach, mpz_t retVal){

  int exp,
      index,
      exp2,
      memorySize;

  mpz_t power;

  mpz_init(power);

  memorySize = mach->memSize;
  exp = memorySize - 1;
  index = 0;
  

  while(index < memorySize){

    exp2 = exp;
    mpz_set_ui(power, 1);

    while(exp2 > 0){
      mpz_mul_ui(power, power, memorySize);
      exp2 -= 1;
    }
   /*mp_printf("Calc = %Zd + %d * %f ", retVal, mach->memory[index],
                                                   pow(MEMORY_SIZE, exp));
*/
    mpz_mul_ui(power, power, mach->memory[index]);
    mpz_add(retVal, retVal, power);
   /*pz_add_ui(retVal, retVal, (unsigned long int) mach->memory[index] 
                                                    * pow(MEMORY_SIZE, exp));
    */
    index += 1;
    exp -= 1;
  }

  mpz_clear(power);
}


/***************************************************************************/
int*
decodeFromStateEnum(mpz_t value, int memSize){

  int index,
      length,
      base,
      *result,
      unit;

  mpz_t res;

  result = xmalloc(sizeof(int) * memSize);

  index = 0;
  length = memSize - 1;
  base = memSize;
  mpz_init(res);

  while(index < memSize){
    unit = pow(base, length - index);

    mpz_fdiv_q_ui(res, value, unit);
    gmp_printf("%Zd / %d = %Zd\n", value, unit, res);

    result[index] = mpz_get_si(res);

    mpz_sub_ui(value, value, unit* result[index]);

    index += 1;
  }

  mpz_clear(res);
  return result;
}

/***************************************************************************/
rbnode* node_new(){
  rbnode* n;
  valueStruct *v;

  n = rbnode_new();
  v = xmalloc(sizeof(valueStruct));
  mpz_init(v->value);

  n->value = (void*) v; 
 
  return n;
}
  
/***************************************************************************/
void valueStruct_free(void* i){
  valueStruct *v = (valueStruct*) i;
  mpz_clear(v->value);
  free(v); 
}  

/***************************************************************************/
int compareValueStruct(void* a, void* b){
  valueStruct *c,
              *d;
  
  c = (valueStruct*) a;
  d = (valueStruct*) b;

  return mpz_cmp(c->value, d->value);
}

/***************************************************************************/

void
decompile(machine *mach){
  int i,
      prevIns,
      instr,
      mal;

  char *str;
  
  prevIns = 0;
  mal = 0;
  printf("****DISCLAIMER: DECOMPLIATION IS ON A 'BEST EFFORT' BASIS. THE ARRANGEMENT OF THE INSTRUCTIONS PER LINE IS INFERED WHETHER THE LEFT INSTR TAKES A PARAMATER OR NOT. IT IS ENTIRELY POSSIBLE THAT THAT INSTRUCTION IS MERELY DATA AND IS NOT EXECUTED\n");

  for(i = 3;i < mach->memSize; i++){

    if(!prevIns){

      instr = lookup(mach->instructionSet, mach->memory[i], mach->numInstr);

      switch(instr){
        case 0:
          prevIns = 0;
          str = "HALT\n";
          break;
        case 1:
          prevIns = 0;
          str = "INC\n";
          break;
        case 2:
          prevIns = 0;
          str = "DEC\n";
          break;
        case 3:
          prevIns = 1;
          str = "LOAD  ";
          break;
        case 4:
          prevIns = 1;
          str = "STO  ";
          break;
        case 5:
          prevIns = 0;
          str = "OUT\n";
          break;
        case 6:
          prevIns = 1;
          str = "JGZ  ";
          break;
        case 7:
          prevIns = 1;
          str = "CPY  ";
          break;
        default:
          mal = 1;
          str = malloc(sizeof(char) * 40);
          sprintf(str, "%d\n", mach->memory[i]);
          prevIns = 0;
      }
    }else{
      mal = 1;
      str = malloc(sizeof(char) * 40);
      sprintf(str, "%d\n", mach->memory[i]);
      prevIns = 0;
    }
    printf("%s", str);
    
    if(mal){
      free(str);
      mal = 0;
    } 
  }
}

/****************************************************************/


void
writeMachineToFile(FILE *fp, machine* mach){

  int i;

  printf("Saving...\n");
  fprintf(fp,"#Autogenerated comment\n");

  fprintf(fp, "F{%d,%d,%d,%d,%d}\n", mach->memSize, mach->numInstr, mach->pcAddress, mach->irAddress, mach->accAddress);

  fprintf(fp, "I{");
  for(i=0; i< mach->numInstr;i++){
    fprintf(fp,"%d,", mach->instructionSet[i]);
  }
  fprintf(fp,"}\n");

  fprintf(fp, "M{");
  for(i=0;i<mach->memSize-3;i++){
    fprintf(fp, "%d,", mach->progState->program[i]);
  }
  fprintf(fp, "}\n");


}


/*****************************************************/

machine*
readMachineFromFile(FILE *fp){
machine *mach;

  int  currentBits = 3,
       buffp,
       instructionsParsed,
       insCount,
       i,
       x,
       p=0,
       *program;


   char ch,
       *buff;

  int *iset = malloc(sizeof(int) * 8);
  for(i=0;i<8;i++){
    iset[i] =i;
  }


  program = malloc(sizeof(int) * pow(2, currentBits));
  buff = malloc(sizeof(char) * 30);

  memset(program, 0 , sizeof(int) * pow(2,currentBits));
  memset(buff, '\0', 30);

  program[0] = 3;

  buffp = 0;
  insCount = 3;
  instructionsParsed = 0;
  ch = fgetc(fp);

  // Skip the comments
  while(1){
    ch = fgetc(fp);
    if(ch == '#'){
      fgets(buff, sizeof(char) * 300, fp);
    }else{
     break;
    }
  }

  while(ch != '\n' && ch != EOF){
    if(!isdigit(ch)){
      ch = fgetc(fp);
      if(p > 0){
        insCount++;
        printf("Inscount is %d\n", insCount);
        if(insCount == pow(2,currentBits)+1){
     //     printf("inscount is %d compared to %d\n", insCount,pow(2,currentBits)+1);
          currentBits++;
          program = realloc(program, sizeof (int) * pow(2, currentBits));
        }
   //     printf("Number of %d digits going in: %s\n", p, buff);
        program[insCount-1] = atoi(buff);
        memset(buff, '\0', 30);
        instructionsParsed++;
        p = 0;
      }
      continue;
    }else{
      buff[p++] = ch;
      ch = fgetc(fp);
    }

  }
  mach =  machine_new(pow(2,currentBits), 8, 0,1,2);
  printf("Machine\n");
  initProgram(&program[3], mach);
  initInstructionSet(iset, mach);

  //free(iset);
  free(program);

  printf("Read finished\n");

  return mach;
}
 

#endif
